import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of, BehaviorSubject } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { UserRoleService } from './user-role.service';
import { AccessControlItem } from '../models/access-control';
import { UserRoleAccessControl } from '../models/user-role-access-control.model';
import { UserRoleToHubMapping } from '../models/user-role-to-hub-mapping';
import { AuthService } from '@auth0/auth0-angular';
import { UserService } from './user.service';
import { HubService } from '../shared/components/masters/hub/hub.service';

@Injectable({
  providedIn: 'root'
})
export class AccessControlService {
  private accessControls: AccessControlItem[] = [];
  private userRoleAccessControls: UserRoleAccessControl[] = [];
  private controlNames: string[] = [];
  private auth0Id: string | undefined;
  private userId: number | undefined;
  private selectedUserRoleToHubMapping: UserRoleToHubMapping | undefined;
  private controlNamesSubject = new BehaviorSubject<string[]>([]);
  private selectedUserRoleNameSubject = new BehaviorSubject<string>('');
  private selectedHubNameSubject = new BehaviorSubject<string>('');

  controlNames$ = this.controlNamesSubject.asObservable();
  selectedUserRoleName$ = this.selectedUserRoleNameSubject.asObservable();
  selectedHubName$ = this.selectedHubNameSubject.asObservable();
  private accessControlsLoadedSubject = new BehaviorSubject<boolean>(false);
  accessControlsLoaded$ = this.accessControlsLoadedSubject.asObservable();

  constructor(
    private userRoleService: UserRoleService,
    private http: HttpClient,
    private auth: AuthService,
    private userService: UserService,
    private hubService: HubService
  ) {}

  public loadUserAccessControls(): Observable<string[]> {
    if (this.auth0Id && this.userId) {
      this.hubService.getHubs().pipe(
        switchMap(() => this.loadAccessControlsForUser(this.userId!))
      ).subscribe(() => {
        this.accessControlsLoadedSubject.next(true);
      });
      return of(this.controlNames);
    }

    return this.auth.user$.pipe(
      switchMap((profile) => {
        if (profile?.sub) {
          this.auth0Id = profile.sub;
          return this.userService.getLoggedInUser(profile.sub).pipe(
            tap((user) => {
              this.userId = user.id!;
            }),
            switchMap((user) => this.hubService.getHubs().pipe(
              switchMap(() => this.loadAccessControlsForUser(user.id!))
            ))
          );
        } else {
          return of([]);
        }
      }),
      map(() => {
        this.accessControlsLoadedSubject.next(true);
        return this.controlNames;
      })
    );
  }

  private loadAccessControlsForUser(userId: number): Observable<void> {
    return this.userRoleService.getUserRoleToHubMappingForUser(userId).pipe(
      switchMap((mappings: UserRoleToHubMapping[]) => {
        const defaultUserRole = mappings.find(mapping => mapping.default);
        if (defaultUserRole) {
          this.selectedUserRoleToHubMapping = defaultUserRole;
          this.updateSelectedUserRoleName(defaultUserRole.userRoleId!);
          this.updateSelectedHubName(defaultUserRole.hubId!);
          return this.loadAccessControlsByRoleId(defaultUserRole.userRoleId!);
        } else {
          return of(void 0);
        }
      }),
      tap(() => {
        this.accessControlsLoadedSubject.next(true);
      })
    );
  }

  private loadAccessControlsByRoleId(userRoleId: number): Observable<void> {
    return forkJoin({
      accessControls: this.userRoleService.getAccessControls(),
      userRoleAccessControls: this.userRoleService.getUserRoleAccessControlsByUserRoleId(userRoleId)
    }).pipe(
      tap(({ accessControls, userRoleAccessControls }) => {
        this.accessControls = accessControls.map(ac => new AccessControlItem(ac));
        this.userRoleAccessControls = userRoleAccessControls;
        this.setControlNames();
      }),
      catchError(error => {
        console.error('Error fetching access controls:', error);
        return of(undefined);
      }),
      map(() => void 0)
    );
  }

  private setControlNames() {
    const accessControlLookup = this.accessControls.reduce((lookup, control) => {
      lookup[control.id] = control.controlName ?? 'Unknown Control Name';
      return lookup;
    }, {} as Record<number, string>);

    this.controlNames = this.userRoleAccessControls
      .filter(ura => !ura.isObsolete)
      .map(ura => accessControlLookup[ura.accessControlId] ?? 'Unknown Control Name');

    this.controlNamesSubject.next(this.controlNames);
    //console.log('Control Names:', this.controlNames);
  }

  hasAccess(controlName: string): boolean {
    return this.controlNames.includes(controlName);
  }

  public setSelectedUserRole(userRoleId: number, hubId: number): void {
    this.selectedUserRoleToHubMapping = { userRoleId, hubId };
    this.updateSelectedUserRoleName(userRoleId);
    this.updateSelectedHubName(hubId);
    this.loadAccessControlsByRoleId(userRoleId).subscribe(() => {
    });
  }

  private updateSelectedUserRoleName(userRoleId: number): void {
    this.userRoleService.getUserRoleById(userRoleId).subscribe(userRole => {
      this.selectedUserRoleNameSubject.next(userRole.name!);
    });
  }

  public getSelectedUserRoleMapping(): UserRoleToHubMapping | undefined {
    return this.selectedUserRoleToHubMapping;
  }

  private updateSelectedHubName(hubId: number): void {
    const hub = this.hubService.getHubById(hubId);
    this.selectedHubNameSubject.next(hub ? hub.name : 'Unknown Hub');
  }
}
