import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { UserRole } from '../models/user-role';
import { UserRoleToHubMapping } from '../models/user-role-to-hub-mapping';
import { AccessControl } from '../models/access-control';
import { UserRoleAccessControl } from '../models/user-role-access-control';

@Injectable({
  providedIn: 'root'
})
export class UserRoleService {

  apiUrl = environment.apiUrls.authApiUrl;

  constructor(private http: HttpClient) { }

  getUserRoles(): Observable<UserRole[]> {
    return this.http.get<UserRole[]>(`${this.apiUrl}/UserRole`);
  }

  getUserRoleById(id: number): Observable<UserRole> {
    return this.http.get<UserRole>(`${this.apiUrl}/UserRole/` + id);
  }

  addUserRoleToHubMapping(mapping: UserRoleToHubMapping): Observable<any> {
    return this.http.post(`${this.apiUrl}/UserRole/AddUserRoleToHubMapping`, mapping);
  }

  addUserRole(userRole: UserRole): Observable<any> {
    return this.http.post(`${this.apiUrl}/UserRole`, userRole);
  }

  updateUserRole(userRole: UserRole): Observable<any> {
    return this.http.put(`${this.apiUrl}/UserRole`, userRole);
  }

  getAccessControls(): Observable<AccessControl[]> {
    return this.http.get<AccessControl[]>(`${this.apiUrl}/UserRole/AccessControl`);
  }

  addUserRoleAccessControl(userRoleAccessControl: UserRoleAccessControl[]): Observable<any> {
    return this.http.post(`${this.apiUrl}/UserRole/AddUserRoleAccessControl`, userRoleAccessControl);
  }

  getUserRoleAccessControls(): Observable<any> {
    return this.http.get(`${this.apiUrl}/UserRole/UserRoleAccessControl`);
  }

  getUserRoleAccessControlsByUserRoleId(userRoleId: number): Observable<any[]> {
    return this.http.get<UserRoleAccessControl[]>(`${this.apiUrl}/UserRole/UserRoleAccessControls/${userRoleId}`);
  }

  getUserRoleToHubMappingForUser(userId: number): Observable<UserRoleToHubMapping[]> {
    return this.http.get<UserRoleToHubMapping[]>(`${this.apiUrl}/UserRole/UserRoleToHubMappingForUser/${userId}`);
  }

  getUserRoleToHubMappingsForUsers(userIds: number[]): Observable<Record<number, UserRoleToHubMapping[]>> {
    return this.http.get<Record<number, UserRoleToHubMapping[]>>(`${this.apiUrl}/UserRole/UserRoleToHubMappingsForUsers`, { params: { userIds } });
  }

  updateUserRoleAccessControls(update: UserRoleAccessControl[]): Observable<any> {
    return this.http.post(`${this.apiUrl}/UserRole/UpdateUserRoleAccessControls`, update);  
  }
  
  clearUserRoleToHubMappings(userId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/UserRole/ClearUserRoleToHubMappings/${userId}`);
  }

  setDefaultUserRoleToHubMapping(payload: { userId: number, userRoleToHubMappingId: number }): Observable<any> {
    return this.http.post(`${this.apiUrl}/UserRole/SetDefaultUserRoleToHubMapping`, payload);
  }
}
