import {Inject, Injectable} from '@angular/core';
import {DOCUMENT} from "@angular/common";
import {AuthService as Auth0Service} from "@auth0/auth0-angular";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  apiUrl = environment.apiUrls.authApiUrl;

  constructor(
    public auth: Auth0Service,
    @Inject(DOCUMENT) private doc: Document,
    private http: HttpClient
  ) {}
  
  user() {
    return this.auth.user$
  }

  authenticated() {
    return this.auth.isAuthenticated$
  }

  login() {
    this.auth.loginWithRedirect();
  }

  logout() {
    this.auth.logout({ logoutParams: { returnTo: this.doc.location.origin } });
  }

  getToken() {
    return this.auth.getAccessTokenSilently()
  }

  changePassword(userId: string, email: string, currentPassword: string, newPassword: string): Observable<any> {
    const url = `${this.apiUrl}/User/ChangePassword`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http.post(url, { userId, email, currentPassword, newPassword }, { headers, responseType: 'text' });
  }
}
