import { TestBed } from '@angular/core/testing';

import { ActiveItemService } from './active-item.service';

describe('ActiveItemService', () => {
  let service: ActiveItemService;

  beforeEach(() => {
    TestBed.configureTestingModule({
    });
    service = TestBed.inject(ActiveItemService);
  });

  afterEach(() => {
  });

  it('should set active main item', (done) => {
    const testItem = 'Settings';
    let isFirstEmission = true; 
  
    const subscription = service.activeMainItem$.subscribe({
      next: (item) => {
        if (!isFirstEmission) { 
          expect(item).toEqual(testItem);
          done();
        }
        isFirstEmission = false;
      },
      error: done.fail
    });
  
    service.setActiveMainItem(testItem);
    subscription.unsubscribe();
  });
  
  it('should set active sub item and update active main item accordingly', (done) => {
    const testSubItem = 'Manage Depot';
    let isFirstEmission = true;
  
    const subscriptionMainItem = service.activeMainItem$.subscribe({
      next: (mainItem) => {
        if (!isFirstEmission) { 
          expect(mainItem).toEqual('Settings'); 
          done();
        }
        isFirstEmission = false;
      },
      error: done.fail
    });
  
    service.setActiveSubItem(testSubItem);
    subscriptionMainItem.unsubscribe();
  });

  it('should set and get header title correctly', () => {
    const testTitle = 'DASHBOARD';
    service.setHeaderTitle(testTitle);
    expect(service.getHeaderTitle()).toEqual(testTitle);
  });

  it('should emit the correct active sub item', (done) => {
    const testSubItem = 'User Account Settings';
    let isFirstEmission = true;
  
    const subscription = service.activeSubItem$.subscribe({
      next: (subItem) => {
        if (!isFirstEmission) {
          expect(subItem).toEqual(testSubItem);
          done();
        }
        isFirstEmission = false;
      },
      error: done.fail
    });
  
    service.setActiveSubItem(testSubItem);
  
    subscription.unsubscribe();
  });

  it('should emit the correct header title', (done) => {
    const testTitle = 'Dashboard';
    let isFirstEmission = true;
  
    const subscription = service.headerTitle$.subscribe({
      next: (title) => {
        if (!isFirstEmission) {
          expect(title).toEqual(testTitle);
          done();
        }
        isFirstEmission = false;
      },
      error: done.fail
    });
  
    service.setHeaderTitle(testTitle);
    subscription.unsubscribe();
  }); 
  
});
