import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'any'
})
export class ToastrServiceWrapper {
  constructor(private toastr: ToastrService) {}

  success(message: string, title?: string) {
    this.toastr.success(message, title, {
      positionClass: 'toast-bottom-right',
      timeOut: 5000,  
      closeButton: true, 
      progressBar: true,  
      extendedTimeOut: 1000, 
    });
  }

  error(message: string, title?: string) {
    this.toastr.error(message, title, {
      positionClass: 'toast-bottom-right',
      timeOut: 5000,
      closeButton: true,
      progressBar: true,
      extendedTimeOut: 1000,
    });
  }
}
