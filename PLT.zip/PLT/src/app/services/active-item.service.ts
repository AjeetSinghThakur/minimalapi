import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ActiveItemService {
  private activeMainItemSource = new BehaviorSubject<string | null>(null);
  private activeSubItemSource = new BehaviorSubject<string | null>(null);
  private headerTitleSource = new BehaviorSubject<string | null>(null);
  private isSidebarCollapsed = new BehaviorSubject<boolean>(false);

  activeMainItem$ = this.activeMainItemSource.asObservable();
  activeSubItem$ = this.activeSubItemSource.asObservable();
  headerTitle$ = this.headerTitleSource.asObservable();
  isSidebarCollapsed$ = this.isSidebarCollapsed.asObservable();

  private mainItemMapping : MainItemMapping = {
    'Manage Depot': 'Settings',
    'Manage Hub': 'Settings',
    'System Settings': 'Settings',
    'General Settings': 'Settings',
    'Consignment Settings': 'Settings',
  };

  setActiveMainItem(item: string | null) {
    this.headerTitleSource.next(null);
    this.activeSubItemSource.next(null);
    this.activeMainItemSource.next(item);
  }

  setActiveSubItem(item: string) {
    this.headerTitleSource.next(null);
    const parentMainItem = this.mainItemMapping[item];
    if(parentMainItem) {
      this.setActiveMainItem(parentMainItem)
    }
    this.activeSubItemSource.next(item);
  }

  setHeaderTitle(item: string) {
    this.headerTitleSource.next(item);
  }

  getHeaderTitle(): string {
    const headerTitle = this.headerTitleSource.getValue();
    if (headerTitle) {
      return headerTitle.toUpperCase();
    }
  
    const activeSubItem = this.activeSubItemSource.getValue();
    if (activeSubItem) {
      return activeSubItem.toUpperCase();
    }
  
    const activeMainItem = this.activeMainItemSource.getValue();
    return activeMainItem ? activeMainItem.toUpperCase() : ''; 
  }

  toggleSidebar() {
    this.isSidebarCollapsed.next(!this.isSidebarCollapsed.value);
  }

  setSidebarState(isCollapsed: boolean) {
    this.isSidebarCollapsed.next(isCollapsed);
  }
}

interface MainItemMapping {
  [key: string]: string;
}
