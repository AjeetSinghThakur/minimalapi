import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map, tap } from 'rxjs';
import { environment } from '@env/environment';
import { User } from '../shared/components/masters/system-settings/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  apiUrl = environment.apiUrls.authApiUrl;
  private loggedInUserSubject = new BehaviorSubject<User | null>(null);

  loggedInUser$ = this.loggedInUserSubject.asObservable();

  constructor(private http: HttpClient) { }

  resendWelcomeEmail(userId: string) {
    return this.http.post<null>(`${this.apiUrl}/User/ResendWelcomeEmail/${userId}`, null);
  }

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/User`);
  }

  getLoggedInUser(auth0Id: string): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/User/GetUserByAuth0Id/${auth0Id}`).pipe(
      tap(user => this.loggedInUserSubject.next(user))
    );
  }

  addUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/User`, user);
  }

  editUser(user: User): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/User/${user.id}`, user);
  }

  isUserBlocked(auth0UserId: string): Observable<boolean> {
    return this.http.get<{ isBlocked: boolean }>(`${this.apiUrl}/User/IsUserBlocked/${auth0UserId}`).pipe(
      map(response => {
        //console.log('UserService: API response', response);
        return response.isBlocked;
      })
    );
  }

  getCurrentUser(): User | null {
    return this.loggedInUserSubject.value;
  }
}
