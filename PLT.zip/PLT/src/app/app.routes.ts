import { Routes } from '@angular/router';
import { LoginComponent } from './features/login/components/login.component';
import { authGuardFn } from '@auth0/auth0-angular';

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path:'login', component: LoginComponent },
    {
        path: 'hub',
        loadComponent: () => import('./shared/components/masters/hub/hub.component').then(m => m.HubComponent),
        canActivate: [authGuardFn]
    },
    {
        path: 'system-settings',
        loadComponent: () => import('./shared/components/masters/system-settings/system-settings.component').then(m => m.SystemSettingsComponent),
        canActivate: [authGuardFn]
    }
];
