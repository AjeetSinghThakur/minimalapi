import {Component, OnDestroy, OnInit} from '@angular/core';
import {AsyncPipe, NgIf} from "@angular/common";
import {ActivatedRoute, Router, RouterLink} from "@angular/router";
import { AuthService } from '@auth0/auth0-angular';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs/internal/Subject';
import {UserService} from "../../../services/user.service";
import {HttpErrorResponse} from "@angular/common/http";

@Component({
  selector: 'dhms-login',
  standalone: true,
  imports: [ RouterLink, NgIf, AsyncPipe],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit,OnDestroy {

  private destroy$ = new Subject<void>();

  constructor(
    public auth: AuthService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private userService: UserService) {}

  ngOnInit(): void {
    this.auth.isAuthenticated$.pipe(takeUntil(this.destroy$)).subscribe((isAuthenticated) => {
      if (!isAuthenticated) {
        this.auth.loginWithRedirect();
      } else {
        this.router.navigate(['/hub']);
      }
    });
  }
  ngOnDestroy(): void {
    this.destroy$.complete();
  }
}
