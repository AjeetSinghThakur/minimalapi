import {AbstractControl, ValidationErrors, ValidatorFn} from "@angular/forms";

export function LessThanCheck(controlToCheckId: string, controlToCheckAgainstId: string): ValidatorFn {
  return (c: AbstractControl): ValidationErrors | null => {

    //Simple check to see if the value of one field is less than another
    let controlToCheck = c.get(controlToCheckId)!;
    let controlToCheckAgainst = c.get(controlToCheckAgainstId)!;
    let res = parseInt(controlToCheck.value) >= parseInt(controlToCheckAgainst.value) ? { invalidValue: true } : null;

    if(res) {
      controlToCheck.setErrors(res)
    }

    return res
  };
}
