import {AbstractControl, ValidationErrors, ValidatorFn} from "@angular/forms";

const ALPHA_NUMERIC_REGEX = /^[a-zA-Z0-9-\s]*$/;

export function alphanumericValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const alphanumeric = ALPHA_NUMERIC_REGEX.test(control.value);
    return !alphanumeric ? { alphanumeric: false } : null;
  };
}
