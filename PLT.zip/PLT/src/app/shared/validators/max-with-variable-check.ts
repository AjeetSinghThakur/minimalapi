import {AbstractControl, ValidationErrors, ValidatorFn} from "@angular/forms";

export function MaxCheckWithVariable(variable: number, max: number): ValidatorFn {
  return (c: AbstractControl): ValidationErrors | null => {
    let res = +c.value + +variable <= max;
    return !res ? {max: false } : null;
  };
}
