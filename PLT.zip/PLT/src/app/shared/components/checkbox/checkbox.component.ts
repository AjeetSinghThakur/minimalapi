import { Component, EventEmitter, Input, Output, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { UserRoleAccessControl } from 'src/app/models/user-role-access-control';

@Component({
  selector: 'dhms-checkbox',
  standalone: true,
  imports: [],
  templateUrl: './checkbox.component.html',
  styleUrl: './checkbox.component.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CheckboxComponent),
      multi: true,
    },
  ],
})
export class CheckboxComponent implements ControlValueAccessor {
  
  @Input() checked: boolean = false;
  @Input() variant: 'primary' | 'secondary' = 'primary';
  @Input() isDisabled: boolean = false;
  @Input() valueField: number = 0;
  @Output() checkChangedEvent = new EventEmitter<UserRoleAccessControl>();

  private _value: number = this.valueField;

  onChange = (value: any) => {};
  onTouched = () => {};

  get value(): number {
    return this._value;
  }

  set value(val: number) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }
  

  writeValue(value: any): void {
    if (value !== undefined) {
      this.value = value;
    }
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }

  onInputChange(event: Event): void {
    const input = event.target as HTMLInputElement | null;
    if (input) {
      this.value = Number(input.value);
      this.checked = input.checked;

      var checkChangedValues = new UserRoleAccessControl();
      checkChangedValues.accessControlId = this.value;
      checkChangedValues.isObsolete = this.checked ? false : true;
      this.checkChangedEvent.emit(checkChangedValues);
    }
  }
  
}
