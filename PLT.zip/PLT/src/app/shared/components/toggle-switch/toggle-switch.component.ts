import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FormControl, FormsModule, ReactiveFormsModule} from "@angular/forms";
import {Subject} from "rxjs";
import {FormHelperText, FormHelperVisibility, FormInputService} from "../../services/form-input.service";
import {takeUntil} from "rxjs/operators";
import {NgClass, NgIf} from "@angular/common";
import {ToastrService} from "ngx-toastr";

@Component({
  selector: 'dhms-toggle-switch',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    NgClass
  ],
  templateUrl: './toggle-switch.component.html',
  styleUrl: './toggle-switch.component.scss'
})
export class ToggleSwitchComponent implements OnInit, OnDestroy {
  @Input() title: string | undefined;
  @Input() model: boolean = false;
  @Input() inputId: string | undefined

  @Output() bindModelChange: any = new EventEmitter();
  private destroy$: Subject<void>;
  displayTextHelper = false;
  textHelperMessage = '';

  constructor(private formInputService: FormInputService, private toastService: ToastrService) {
    this.destroy$ = new Subject<void>();
  }

  ngOnInit(): void {
    this.formInputService.onTextChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((message: FormHelperText) => this.setMessage(message));

    this.formInputService.onHelperVisibilityChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((visible: FormHelperVisibility) => this.setHelperVisiblity(visible));
  }

  ngOnDestroy() {
    this.destroy$.next()
    this.destroy$.complete()
  }

  private setMessage(frmHelper: FormHelperText)
  {
    if (frmHelper.inputId == this.inputId)
    {
      this.textHelperMessage = frmHelper.message;
    }
  }

  private setHelperVisiblity(visibleHelper: FormHelperVisibility)
  {
    if (visibleHelper.inputId == this.inputId)
    {
      this.displayTextHelper = visibleHelper.visible
    }
  }

  updateData(event: any) {
    this.displayTextHelper = false
    this.model = event;
    this.bindModelChange.emit(event);
    let state = 'enabled'
    if(!event) { state = 'disabled' }
    this.toastService.info(`\`${this.title}\` is ${state}`, undefined, {positionClass:'toast-bottom-right'})
  }
}
