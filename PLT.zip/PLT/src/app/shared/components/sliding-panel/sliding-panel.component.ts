import {
  Component,
  OnInit,
  OnDestroy,
  Type,
  ViewChild,
  ViewContainerRef,
  ComponentRef,
  EventEmitter,
  Output,
  HostListener,
  Input,
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SlidingPanelService } from '../../services/sliding-panel.service';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';
import { NgClass, NgIf, NgTemplateOutlet } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { DisableOverlayService } from '../../services/disable-overlay.service';
import { AuditHistoryComponent } from '../audit-history/audit-history.component';

@Component({
  selector: 'dhms-sliding-panel',
  standalone: true,
  templateUrl: './sliding-panel.component.html',
  styleUrls: ['./sliding-panel.component.scss'],
  imports: [
    SvgIconComponent,
    NgTemplateOutlet,
    ReactiveFormsModule,
    NgIf,
    NgClass,
    AuditHistoryComponent,
  ],
})
export class SlidingPanelComponent implements OnInit, OnDestroy {
  @ViewChild('content', { read: ViewContainerRef })
  public panelContentRef: ViewContainerRef;
  public isPanelVisible!: boolean;
  private destroy$: Subject<void>;
  public title!: string;
  public isAuditHistoryVisible: boolean = false;
  public isFullScreen: boolean = false;
  @Output() sidePanelOpened = new EventEmitter<boolean>();
  @Output() previousPanelViewed = new EventEmitter<any>();
  @Input() auditData: Array<any> = [];
  @Input() previousData: any;
  @Input() auditTitle: string = '';
  @Input() auditMode: string = '';

  constructor(
    private _viewContainerRef: ViewContainerRef,
    private slidingPanelService: SlidingPanelService,
    private overlayService: DisableOverlayService
  ) {
    this.destroy$ = new Subject<void>();
    this.panelContentRef = _viewContainerRef;
  }

  private wasInside = false;

  @HostListener('click')
  clickInside() {
    this.wasInside = true;
  }

  @HostListener('document:click')
  clickOut() {
    if (!this.wasInside) {
      this.slidingPanelService.emitOutsideClick();
    }
    this.wasInside = false;
  }

  ngOnInit(): void {
    this.slidingPanelService
      .onPanelVisibilityChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((visible: boolean) => {
        this.isPanelVisible = visible;
        if (this.isPanelVisible) {
          this.overlayService.show();
        } else {
          this.overlayService.hide();
          this.panelContentRef.clear();
        }
        this.sidePanelOpened.emit(visible);
      });

    this.slidingPanelService
      .onContentChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((component: Type<any>) => {
        this._setPanelContent(component);
      });

    this.slidingPanelService
      .onTitleChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((title: string) => {
        this._setTitle(title);
        var currentTitle = this.title?.toString();
        currentTitle = currentTitle?.trim()?.split(' ')[0];
        if (currentTitle === 'Add') {
          // console.log(this.auditMode);
          // if(this.auditMode === 'Add')
          this.isAuditHistoryVisible = true;
        }
        else if (currentTitle === 'Edit') {
          this.isAuditHistoryVisible = false;
        }
      });

    this.slidingPanelService
      .onContentWithDataChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe((res) => {
        this.panelContentRef.clear();
        let content = this.panelContentRef.createComponent(res.content);
        content.setInput('data', res.data);
      });
  }

  public close(): void {
    this.isAuditHistoryVisible = false;
    var element = document.getElementById('auditHistoryTable');
    var isElementVisible = element?.checkVisibility({
      checkOpacity: true,
      checkVisibilityCSS: true,
    });
    if (isElementVisible === true) {
      this.previousPanelViewed.emit(this.previousData);
    } else {
      if (this.isFullScreen) {
        this.toggleFullScreen(false);
      }
      this.slidingPanelService.closeRequest();
    }
  }

  public displayAuditHistory(): void {
    this.slidingPanelService.close();
    this.slidingPanelService.setTitle(this.auditTitle);
    this.isAuditHistoryVisible = true;
    this.slidingPanelService.setContentWithDataChange({
      content: AuditHistoryComponent,
      data: this.auditData,
    });
    this.slidingPanelService.show();
  }

  private _setTitle(title: string) {
    this.title = title;
  }

  private _setPanelContent(component: Type<any>) {
    this.panelContentRef.clear();
    this.panelContentRef.createComponent(component);
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  toggleFullScreen(set?: boolean) {
    if (!set) {
      this.isFullScreen = !this.isFullScreen;
    } else {
      this.isFullScreen = set;
    }
  }
}
