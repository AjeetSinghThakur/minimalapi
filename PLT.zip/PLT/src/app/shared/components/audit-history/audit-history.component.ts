import { ColDef, ModuleRegistry } from '@ag-grid-community/core';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AgGridAngular } from '@ag-grid-community/angular';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import {SlidingPanelService} from "../../services/sliding-panel.service";
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs/internal/Subject';
import { formatDate } from '@angular/common';

ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
  selector: 'dhms-audit-history',
  standalone: true,
  imports: [
    AgGridAngular
  ],
  templateUrl: './audit-history.component.html',
  styleUrl: './audit-history.component.scss'
})
export class AuditHistoryComponent implements OnInit, OnDestroy {
  @Input() data: Array<any> = [];
  rowData: any[] = [];
  colDefs: ColDef[] = [
    { headerName: 'Date', field: 'updatedDate', width: 127, cellRenderer: (data:any) => {
      return formatDate(data.value, 'd MMM yyyy HH:mm:ss', 'en-GB'); } },
    { headerName: 'User', field: 'updatedByName', width: 127 },
    { headerName: 'Actions', field: 'fieldName', width: 127 },
    { headerName: 'Previous Value', field: 'previousValue', width: 127 },
    { headerName: 'New Value', field: 'newValue', width: 127 }
  ];
  private destroy$ = new Subject<void>;

  constructor(private slidingService: SlidingPanelService){}
    
  ngOnInit(): void {
    this.slidingService.closeRequestListener()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.slidingService.close();
      });

    this.rowData = this.data;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
