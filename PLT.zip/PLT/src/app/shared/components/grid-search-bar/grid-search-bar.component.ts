import { Component } from '@angular/core';
import {GridService} from "../../services/grid.service";
import {SvgIconComponent} from "../svg-icon/svg-icon.component";
import {NgForOf, NgIf} from "@angular/common";
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'dhms-grid-search-bar',
  standalone: true,
  imports: [
    SvgIconComponent,
    NgIf,
    NgForOf,
    FormsModule
  ],
  templateUrl: './grid-search-bar.component.html',
  styleUrl: './grid-search-bar.component.scss'
})
export class GridSearchBarComponent {
  searchTerms: string[] = []
  addSearchTerm = ''

  constructor(private gridService: GridService) {
  }

  onChange(event: any) {
    if(event.data == ',') {
      let searchTerm = (document.getElementById("filter-text-box") as HTMLInputElement).value
        .replace(',','')
        this.applyFilter(searchTerm)
    }
  }

  search(terms: any) {
    if(terms.target.value) {
      this.applyFilter(terms.target.value)
    }
  }

  private applyFilter(searchTerm: string) {
    this.searchTerms.push(searchTerm)
    this.addSearchTerm = ''
    this.gridService.searchGrid(this.searchTerms.join(' '))
  }

  searchTermClick(event: any) {
    this.searchTerms.splice(event, 1)
    this.gridService.searchGrid(this.searchTerms.join(' '))
  }

}
