import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridSearchBarComponent } from './grid-search-bar.component';

describe('GridSearchBarComponent', () => {
  let component: GridSearchBarComponent;
  let fixture: ComponentFixture<GridSearchBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GridSearchBarComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GridSearchBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
