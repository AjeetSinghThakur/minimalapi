import { Component, forwardRef, Input, EventEmitter, Output } from '@angular/core';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';
import { CommonModule } from '@angular/common';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'dhms-select-menu',
  standalone: true,
  imports: [SvgIconComponent, CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './select-menu.component.html',
  styleUrls: ['./select-menu.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SelectMenuComponent),
      multi: true
    }
  ]
})
export class SelectMenuComponent implements ControlValueAccessor {
  @Input() label: string | undefined;
  @Input() icon: string | undefined;
  @Input() isError: boolean = true;
  @Input() isSuccess: boolean = false;
  @Input() isDisabled: boolean = false;
  @Input() options: string[] = [];
  @Input() errorMessage: string = 'Something went wrong...';
  @Input() required = false

  value: string = '';
  onChange: any = () => {};
  onTouched: any = () => {};

  writeValue(value: any): void {
    this.value = value;
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }

  onSelectionChange(event: Event): void {
    const selectElement = event.target as HTMLSelectElement | null;
    if (selectElement) {
      this.value = selectElement.value;
      this.onChange(selectElement.value);
      this.onTouched();
    }
  }

  getArrowBackgroundColor(): string {
    if (this.isSuccess) {
      return '#f0f9f6';
    } else if (this.isError) {
      return '#fcf3f2';
    } else if (this.isDisabled) {
      return '#F2F4F5';
    } else {
      return '#e8ebf3';
    }
  }
}
