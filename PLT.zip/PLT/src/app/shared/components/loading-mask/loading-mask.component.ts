import {Component, OnDestroy, OnInit} from '@angular/core';
import {LoadingMaskService} from "../../services/loading-mask.service";
import {Subject} from "rxjs/internal/Subject";
import {takeUntil} from "rxjs/operators";
import {NgIf} from "@angular/common";

@Component({
  selector: 'dhms-loading-mask',
  standalone: true,
  imports: [
    NgIf
  ],
  templateUrl: './loading-mask.component.html',
  styleUrl: './loading-mask.component.scss'
})
export class LoadingMaskComponent implements OnInit, OnDestroy{
  message = ""
  show = false
  private destroy$ = new Subject<void>

  constructor(private loadMaskService: LoadingMaskService) {
  }

  ngOnInit(): void {
    this.loadMaskService.onVisibilityChange()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.show = res
      })

    this.loadMaskService.onSetMessage()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.message = res
      })
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }

}
