import { AgGridAngular } from '@ag-grid-community/angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  ModuleRegistry,
} from '@ag-grid-community/core';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges, OnDestroy, OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { CustomGridConstants } from './custom-grid-constants';
import { NgIf } from '@angular/common';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CheckboxComponent } from '../checkbox/checkbox.component';
import {GridService} from "../../services/grid.service";
import {Subject} from "rxjs/internal/Subject";
import {takeUntil} from "rxjs/operators";
import {SvgIconComponent} from "../svg-icon/svg-icon.component";

ModuleRegistry.registerModules([ClientSideRowModelModule]);

export interface GridActionEvent {
  type: 'checkboxChange' | 'edit' | 'delete' | 'unarchive' | 'gridReady' | 'resendEmail';
  data?: any;
  gridApi?: GridApi;
}

@Component({
  selector: 'dhms-grid',
  standalone: true,
  templateUrl: './grid.component.html',
  styleUrl: './grid.component.scss',
  imports: [AgGridAngular, NgIf, MatCheckboxModule, CheckboxComponent, SvgIconComponent],
})
export class GridComponent implements OnChanges, OnInit, OnDestroy {
  private gridApi!: GridApi;
  private destroy$ = new Subject<void>;
  noRowsTemplate: string = '<span>No data to display</span>';
  @Input() context: GridContext | undefined;
  @Input() components?: any;

  constructor(private gridService: GridService) {}

  ngOnInit() {
    this.initColumnsFromConfig();
    this.gridRowData = this.rowData;
    this.gridOptions = {
      ...this.gridOptions,
      context: { componentParent: this.context },
    };

    this.gridService.onSearchGrid().pipe(takeUntil(this.destroy$))
      .subscribe(x => this.onFilterTextBoxChanged(x))
  }

  defaultColDef = {
    resizable: true,
    sortable: true,
    wrapText: true,
    autoHeight: true,
    wrapHeaderText: true,
    autoHeaderHeight: true,
  };

  public gridOptions: GridOptions = {
    getRowStyle: (params) => {
      if (params.data.level === 0) {
        return { backgroundColor: 'rgba(0, 184, 149, 0.05)' };
      } else if (params.data.children && params.data.children.length > 0) {
        return { backgroundColor: 'rgba(22, 34, 136, 0.05)' };
      }
      return undefined;
    },
  };

  @Input() rowData: any[] = [];
  @Input() gridConfig: GridColumnConfig[] = [];
  @Input() disableGrid = false;

  gridRowData: any[] = [];
  @Output() hubSelected = new EventEmitter<string>();
  @Output() action = new EventEmitter<GridActionEvent | any>();

  colDefs: ColDef[] = [];

  ngOnChanges(changes: SimpleChanges) {
    for (const change in changes) {
      if (changes.hasOwnProperty(change)) {
        switch (change) {
          case 'disableGrid': {
            this.disableGrid = changes['disableGrid'].currentValue;
          }
        }
      }
    }
  }

  statusCellRenderer(params: any) {
    const value = params.value;
    let cellValue = '';
    let backgroundColor = '';
    let textColor = '';
    let textValue = '';

    switch (value) {
      case false:
        backgroundColor = '#00B89533';
        textColor = '#00B895';
        textValue = 'ACTIVE';
        break;
      case true:
        backgroundColor = '#FBD9D3';
        textColor = 'red';
        textValue = 'INACTIVE';
        break;
      default:
        break;
    }

    cellValue = `<div style=""><span style="font-size:10px; font-weight:500; padding:2px 5px; background-color: ${backgroundColor}; color: ${textColor};">${textValue}</span></div>`;
    return cellValue;
  }

  booleanCellRenderer(params: any) {
    const value = params.value;
    let cellValue = '';
    let textValue = '';

    switch (value) {
      case false:
        textValue = 'No';
        break;
      case true:
        textValue = 'Yes';
        break;
      default:
        break;
    }

    cellValue = `<div style=""><span>${textValue}</span></div>`;
    return cellValue;
  }

  checkBoxCellRenderer(params: any) {
    const checked = params.data.rolePermissions[params.colDef.field]
      ? 'checked'
      : '';
    return `<input type="checkbox"
                 ${checked}
                 onchange="this.dispatchEvent(new CustomEvent('gridCheckboxChange', {detail: {
                      rowIndex: ${params.node.rowIndex},
                      field: '${params.colDef.field}',
                      checked: this.checked,
                      accessControlId: ${params.data.accessControlId}
                  }, bubbles: true}))"/>`;
  }

  actionCellRenderer = (params: any) => {
    const isActive = params.data.isObsolete;

    if (isActive) {
      if (params.data.name !== undefined) {
        return '<div class="flex justify-between items-center gap-1"><div class="ml-auto mr-auto flex gap-4"><button style="visibility: hidden;" class="edit-btn" title="Edit"><img class="" src="../../../../assets/icons/grid-edit.svg" /></button> <button style="visibility: hidden;" class="delete-btn" title="Deactivate"><img class="" src="../../../../assets/icons/grid-delete.svg" /></button></div><button class="flex justify-center items-center h-9 w-9 rounded-[4px] bg-table-iconBackground unarchive-btn" title="Reactivate '+ params.data.name +'"><img src="../../../../assets/icons/grid-archive.svg" /></button>'
      }
      return CustomGridConstants.inactiveGridRowButton;
    } else {
      return CustomGridConstants.activeGridRowButton;
    }
  };

  emailVerifiedRenderer(params: any) {
    const email = params.value;
    const isVerified = params.data.isVerified;
    const iconPath = isVerified
      ? '../../../../assets/icons/verified-email.svg'
      : '../../../../assets/icons/unverified-email.svg';
    return `<span>${email} <img src="${iconPath}" style="display: inline-block; vertical-align: middle;" /></span>`;
  }

  functionColumnRenderer = (params: any) => {
    const basePadding = 30;
    const additionalPaddingPerLevel = 20;
    const totalPadding =
      basePadding + params.data.level * additionalPaddingPerLevel;

    return `<span style="display: block; text-align: left; padding-left: ${totalPadding}px;">${params.value}</span>`;
  };

  collapseExpandRenderer = (params: any) => {
    if (params.data.children && params.data.children.length > 0) {
      const isExpanded = params.data.showChildren;
      const buttonImage = '../../../../assets/icons/grid-down-chevron.svg';
      return `<button class="collapse-expand-btn"><img src="${buttonImage}" class="${
        isExpanded ? 'expanded' : ''
      }" /></button>`;
    }
    return '';
  };

  YesNoRenderer(params: any): string {
    return `
    <div class="boolean-cell-value text-xs font-medium leading-4 text-center ${
      params.data.rolePermissions[params.colDef.field]
        ? 'text-teal-600 bg-teal-600 bg-opacity-20'
        : 'text-rose-500 bg-rose-500 bg-opacity-20'
    } whitespace-nowrap rounded-sm">
      ${params.data.rolePermissions[params.colDef.field] ? 'YES' : 'NO'}
    </div>
  `;
  }

  ngAfterViewInit() {
    document.addEventListener('gridCheckboxChange', (event) =>
      this.handleCheckboxChange(event as CustomEvent)
    );
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  handleCheckboxChange(event: CustomEvent) {
    const detail = event.detail;
    const { rowIndex, field, checked, accessControlId } = detail;
    this.action.emit({
      type: 'checkboxChange',
      data: { rowIndex, field, checked, accessControlId },
    });
  }

  onGridReady(params: any): void {
    this.gridApi = params.api;
    this.action.emit({ type: 'gridReady', gridApi: this.gridApi });
  }

  private initColumnsFromConfig() {
    this.colDefs = this.gridConfig.map((config) => {
      const colDef: ColDef = {
        headerName: config.headerName,
        field: config.field,
        checkboxSelection: config.checkboxSelection,
        suppressHeaderMenuButton: config.suppressHeaderMenuButton,
        pinned: config.pinned,
        minWidth: config.minWidth,
        maxWidth: config.maxWidth,
        width: config.width,
      };

      if (config.useRenderer) {
        colDef.cellRenderer = this.resolveRenderer(config.useRenderer);
      }

      return colDef;
    });
  }

  private resolveRenderer(rendererKey: string): any {
    switch (rendererKey) {
      case 'userAction':
        return this.userActionRenderer;
      case 'boolean':
        return this.booleanCellRenderer;
      case 'status':
        return this.statusCellRenderer;
      case 'action':
        return this.actionCellRenderer;
      case 'emailVerified':
        return this.emailVerifiedRenderer;
      case 'collapseExpand':
        return this.collapseExpandRenderer;
      case 'checkBoxCellRenderer':
        return this.checkBoxCellRenderer;
      case 'functionColumnRenderer':
        return this.functionColumnRenderer;
      case 'yesNo':
        return this.YesNoRenderer;
      default:
        return null;
    }
  }

  onGridCellClicked(event: any) {
    const clickedElement = event.event.target;

    if (clickedElement.closest('.edit-btn')) {
      this.action.emit({ type: 'edit', data: event.data });
    } else if (clickedElement.closest('.delete-btn')) {
      this.action.emit({ type: 'delete', data: event.data });
    } else if (clickedElement.closest('.unarchive-btn')) {
      this.action.emit({ type: 'unarchive', data: event.data });
    } else if (clickedElement.closest('.collapse-expand-btn')) {
      const rowData = event.data;
      rowData.showChildren = !rowData.showChildren;
      this.refresh();
    } else if(event.type == "rowDoubleClicked") {
      this.action.emit({ type: 'rowDoubleClicked', data: event.data})
    } else if(clickedElement.closest('.email-btn')) {
      this.action.emit({type: 'sendEmail', data: event.data})
    }
  }

  handleGridAction(event: any) {
    if (event.type === 'checkboxChange') {
      const { rowIndex, field, checked } = event.data;
    }
  }

  public refreshGrid(data: any[]): void {
    if (this.gridApi && data) {
      this.gridApi.updateGridOptions({ rowData: data });
    }
  }

  public refresh() {
    const flattenChildren = (item: GridRow): GridRow[] => {
      if (!item.children || !item.showChildren) {
        return [item];
      }
      return [item, ...item.children.flatMap(flattenChildren)];
    };

    const newData = this.rowData.flatMap(flattenChildren);

    this.gridApi.setRowData(newData);
  }

  public getGridApi() {
    return this.gridApi;
  }

  public refreshGridCells(): void {
    if (this.gridApi) {
      this.gridApi.refreshCells({ force: true });
    }
  }

  public userActionRenderer = (params: any) => {
    const isActive = params.data.isObsolete;
    const resendEmailBtn = ''

    if (isActive) {
      if (params.data.name !== undefined) {
        return '<div class="flex justify-between items-center gap-1"><div class="ml-auto mr-auto flex gap-2"><button class="email-btn" title="Email"><img class="" src="../../../../assets/icons/email.svg" /></button><button style="visibility: hidden;" class="edit-btn" title="Edit"><img class="" src="../../../../assets/icons/grid-edit.svg" /></button> <button style="visibility: hidden;" class="delete-btn" title="Deactivate"><img class="" src="../../../../assets/icons/grid-delete.svg" /></button></div><button class="flex justify-center items-center h-9 w-9 rounded-[4px] bg-table-iconBackground unarchive-btn" title="Reactivate '+ params.data.name +'"><img src="../../../../assets/icons/grid-archive.svg" /></button>'
      }
      return CustomGridConstants.inactiveGridRowButtonForUser;
    } else {
      return CustomGridConstants.activeGridRowButtonForUser;
    }
  };

  public switchToCheckboxRenderer(): void {
    this.colDefs = this.colDefs.map((colDef) => {
      if (colDef.cellRenderer === this.YesNoRenderer) {
        return { ...colDef, cellRenderer: this.checkBoxCellRenderer };
      }
      return colDef;
    });
    if (this.gridApi) {
      this.gridApi.setColumnDefs(this.colDefs);
      this.gridApi.refreshCells();
    }
  }

  public switchToBooleanRenderer(): void {
    this.colDefs = this.colDefs.map((colDef) => {
      if (colDef.cellRenderer === this.checkBoxCellRenderer) {
        return { ...colDef, cellRenderer: this.YesNoRenderer };
      }
      return colDef;
    });
    if (this.gridApi) {
      this.gridApi.setColumnDefs(this.colDefs);
      this.gridApi.refreshCells();
    }
  }

  onFilterTextBoxChanged(searchText: string) {
    this.gridApi.setGridOption(
      "quickFilterText",
      searchText,
    );
  }

  onFilterChanged(event: any) {
    if(this.gridApi.isQuickFilterPresent() && this.gridApi.getDisplayedRowCount() == 0) {
      this.gridApi.showNoRowsOverlay()
    } else {
      this.gridApi.hideOverlay()
    }
  }
}

export interface GridColumnConfig {
  headerName: string;
  field: string;
  useRenderer?:
    | 'status'
    | 'boolean'
    | 'action'
    | 'emailVerified'
    | 'collapseExpand'
    | 'checkBoxCellRenderer'
    | 'functionColumnRenderer'
    | 'userAction'
    | 'yesNo';
  cellRendererFramework?: any;
  cellRendererParams?: { [key: string]: any };
  headerComponentParams?: { [key: string]: any };
  suppressHeaderMenuButton?: boolean;
  pinned?: 'left' | 'right';
  editable?: boolean;
  checkboxSelection?: boolean;
  cellClass?: (params: any) => string | string[];
  minWidth?: number;
  maxWidth?: number;
  width?: number;
}

interface GridRow {
  [key: string]: any;
  children?: GridRow[];
  showChildren?: boolean;
}

export interface GridContext {
  toggleEditStandardUserRoles(): void;
}
