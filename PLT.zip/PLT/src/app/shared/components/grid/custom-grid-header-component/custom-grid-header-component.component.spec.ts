import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomGridHeaderComponent } from './custom-grid-header-component.component';

describe('CustomGridHeaderComponentComponent', () => {
  let component: CustomGridHeaderComponent;
  let fixture: ComponentFixture<CustomGridHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomGridHeaderComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomGridHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
