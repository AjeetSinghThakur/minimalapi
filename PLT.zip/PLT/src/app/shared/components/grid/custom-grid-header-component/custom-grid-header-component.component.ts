import { IHeaderAngularComp } from '@ag-grid-community/angular';
import { IHeaderParams } from '@ag-grid-community/core';
import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'dhms-custom-grid-header-component',
  standalone: true,
  imports: [CommonModule, NgIf],
  template: `
    <div class="header-container">
      <span class="header-label">{{ params.displayName }}</span>
      <img *ngIf="showEditIcon" src="../../../../assets/icons/edit-pen.svg" class="edit-icon" (click)="onIconClicked()" />
    </div>
  `,
  styleUrl: './custom-grid-header-component.component.scss'
})
export class CustomGridHeaderComponent implements IHeaderAngularComp {
  public params!: IHeaderParams;
  public showEditIcon: boolean = false;

  refresh(params: IHeaderParams): boolean {
    this.params = params;
    this.updateIconVisibility();
    return true;
  }

  agInit(params: IHeaderParams): void {
    this.params = params;
    this.updateIconVisibility();
  }

  updateIconVisibility(): void {
    this.showEditIcon = this.params.column.getColDef().cellRenderer.name === 'checkBoxCellRenderer';
  }

  onIconClicked(): void {
    if (this.params.context && this.params.context.componentParent) {
      this.params.context.componentParent.editUserRoleAccess(this.params.displayName);
    } else {
      console.error("Component parent or context not set correctly.");
    }
  }
}