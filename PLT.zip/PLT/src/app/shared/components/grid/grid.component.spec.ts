import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GridComponent, GridColumnConfig } from './grid.component';

describe('GridComponent', () => {
  let component: GridComponent;
  let fixture: ComponentFixture<GridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GridComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(GridComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  describe('Initialization and Input Handling', () => {
    it('should initialize colDefs based on gridConfig input', () => {
      const testGridConfig: GridColumnConfig[] = [
        { headerName: 'Name', field: 'name', checkboxSelection: true },
        { headerName: 'Status', field: 'status', useRenderer: 'status' }
      ];

      // Simulate input setting
      component.gridConfig = testGridConfig;
      component.ngOnInit(); 

      // Verify colDefs are initialized as expected
      expect(component.colDefs.length).toBe(testGridConfig.length);
      expect(component.colDefs[0].field).toEqual('name');
      expect(component.colDefs[1].cellRenderer).toBeDefined();
    });
  });
  
});
