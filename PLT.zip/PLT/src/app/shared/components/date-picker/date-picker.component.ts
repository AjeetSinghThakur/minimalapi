import { Component, Input } from '@angular/core';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';

@Component({
  selector: 'dhms-date-picker',
  standalone: true,
  imports: [SvgIconComponent],
  templateUrl: './date-picker.component.html',
  styleUrl: './date-picker.component.scss'
})
export class DatePickerComponent {
  @Input() label: string | undefined;
  @Input() icon: string | undefined;
}
