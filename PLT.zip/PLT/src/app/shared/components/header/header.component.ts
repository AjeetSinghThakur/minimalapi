import { Component } from '@angular/core';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';
import { ActiveItemService } from 'src/app/services/active-item.service';
import { Subscription, combineLatest, map } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'dhms-header',
  standalone: true,
  imports: [SvgIconComponent, CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  headerTitle: string | null = '';
  subscription: Subscription;
  isSidebarCollapsed: boolean = false;

  constructor(private activeItemService: ActiveItemService) {
    this.subscription = combineLatest([
      this.activeItemService.activeMainItem$,
      this.activeItemService.activeSubItem$,
      this.activeItemService.headerTitle$
    ])
    .pipe(
      map(() => {
        return this.activeItemService.getHeaderTitle();
      })
    )
    .subscribe((title: string) => {
      this.headerTitle = title;
    });

    this.subscription.add(
      this.activeItemService.isSidebarCollapsed$.subscribe(isCollapsed => {
        this.isSidebarCollapsed = isCollapsed;
      })
    );
  }

  collapse() {
    this.activeItemService.toggleSidebar();
  }
  
}
