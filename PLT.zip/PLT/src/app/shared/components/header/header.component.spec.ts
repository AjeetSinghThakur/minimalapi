import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HeaderComponent] 
    })
    .compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display message and notification icons', () => {
    const icons = fixture.debugElement.queryAll(By.css('.header-button'));
    expect(icons.length).toBe(2); 
  
    expect(icons[0].query(By.css('span'))).toBeTruthy();
    expect(icons[1].query(By.css('span'))).toBeTruthy();
  });
  
  it('should have a toggle switch for md screens and above', () => {
    const toggle = fixture.debugElement.query(By.css('.toggle'));
    expect(toggle).toBeTruthy();
  });

  it('should change state when toggle is pressed', () => {
    const toggleInput = fixture.debugElement.query(By.css('.toggle input')).nativeElement;
    expect(toggleInput.checked).toBeFalsy();
  
    // Simulate click event on toggle
    toggleInput.click();
    fixture.detectChanges();
  
    expect(toggleInput.checked).toBeTruthy(); // Verify the toggle is now in the checked state
  });
  
});
