import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';
import { AuthService } from '@auth0/auth0-angular';
import { takeUntil } from 'rxjs/internal/operators/takeUntil';
import { Subject, Subscription } from 'rxjs';
import { ActiveItemService } from 'src/app/services/active-item.service';
import { Router } from '@angular/router';
import { ConfirmationModalComponent } from "../masters/hub/confirmation-modal/confirmation-modal.component";
import { AsyncPipe, NgIf } from "@angular/common";
import { AddHubSectionModalComponent } from "../masters/hub/add-hub/add-hub-section-modal/add-hub-section-modal.component";
import { SlidingPanelService } from '../../services/sliding-panel.service';
import { UpdateProfilePanelComponent } from '../masters/profile/update-profile-panel/update-profile-panel.component';
import { User } from '../masters/system-settings/user.model';
import { UserService } from 'src/app/services/user.service';
import { AccessControlService } from 'src/app/services/access-control.service';
import { ModalService } from '../../services/modal.service';
import { ChangeRoleModalComponent } from '../masters/change-role-modal/change-role-modal.component';

@Component({
  selector: 'dhms-sidebar',
  standalone: true,
  imports: [SvgIconComponent, ConfirmationModalComponent, NgIf, AddHubSectionModalComponent, AsyncPipe, ChangeRoleModalComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent implements OnInit, OnDestroy {
  private subscriptions = new Subscription();

  @Output() logOut = new EventEmitter();
  @Output() changeRole = new EventEmitter();
  @Input() initiateLogOut = false;

  isSidebarCollapsed: boolean = false;
  activeMainItem: string | null = "Dashboard";
  activeSubItem: string | null = null;

  showRoleChangeModal: boolean = false;

  userName: string | undefined;
  profileImageUrl: string | undefined;
  private destroy$ = new Subject<void>();

  user: User | undefined;
  auth0Id: string | undefined;
  selectedUserRoleName: string = '';
  selectedHubName: string = '';

  constructor(
    public auth: AuthService,
    private activeItemService: ActiveItemService,
    private slidingPanelService: SlidingPanelService,
    private userService: UserService,
    private accessControlService: AccessControlService,
    private router: Router,
    public modalService: ModalService
  ) { }

  ngOnInit(): void {
    this.accessControlService.loadUserAccessControls().subscribe();
    this.activeItemService.isSidebarCollapsed$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isCollapsed => {
        this.isSidebarCollapsed = isCollapsed;
      });

    this.auth.user$.pipe(
      takeUntil(this.destroy$)
    ).subscribe((profile) => {
      this.userName = profile?.nickname;
      this.profileImageUrl = profile?.picture;
      this.auth0Id = profile?.sub;
      this.userService.getLoggedInUser(this.auth0Id!).subscribe();
    });

    this.userService.loggedInUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe(user => {
        if (user) {
          this.user = user;
        }
      });

    this.accessControlService.selectedUserRoleName$
      .pipe(takeUntil(this.destroy$))
      .subscribe(roleName => {
        this.selectedUserRoleName = roleName;
      });

    this.accessControlService.selectedHubName$
      .pipe(takeUntil(this.destroy$))
      .subscribe(hubName => {
        this.selectedHubName = hubName;
      });

    this.subscriptions.add(
      this.activeItemService.activeMainItem$.subscribe(item => {
        this.activeMainItem = item;
      })
    );

    this.subscriptions.add(
      this.activeItemService.activeSubItem$.subscribe(subItem => {
        this.activeSubItem = subItem;
      })
    );
  }

  setActiveMainItem(itemName: string) {
    this.activeItemService.setActiveMainItem(itemName);
  }

  setActiveSubItem(subItemName: string, parentItemName?: string) {
    this.activeItemService.setActiveSubItem(subItemName);
  }

  logout() {
    this.logOut.emit();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }

  navigate(route: string): void {
    this.router.navigate([route]);
  }

  updateProfile() {
    this.slidingPanelService.setTitle('Update Profile');
    this.slidingPanelService.setContentWithDataChange({
      content: UpdateProfilePanelComponent,
      data: this.user,
    });
    this.slidingPanelService.show();
  }

  hasAccess(controlName: string): boolean {
    return this.accessControlService.hasAccess(controlName);
  }

  openChangeRoleModal() {
    this.changeRole.emit();
  }
}
