import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser'; 

import { SidebarComponent } from './sidebar.component';
import { of } from 'rxjs';
import { AuthService } from '@auth0/auth0-angular';
import { HttpClientModule } from '@angular/common/http';

// Mock AuthService
const mockAuthService = {
  user$: of({ nickname: 'TestUser', picture: 'test-picture-url' }),
  logout: jasmine.createSpy('logout')
};

describe('SidebarComponent', () => {
  let component: SidebarComponent;
  let fixture: ComponentFixture<SidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SidebarComponent, HttpClientModule],
      providers: [{ provide: AuthService, useValue: mockAuthService }]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should display the logo in the correct place', () => {
    const logoElement = fixture.debugElement.query(By.css('.app-l-sidebar__logo img'));
    expect(logoElement).toBeTruthy(); // Check if the logo element exists
    expect(logoElement.nativeElement.src).toContain('palletline-logo.png'); // Check if the logo's src contains the correct file name
  });
});
