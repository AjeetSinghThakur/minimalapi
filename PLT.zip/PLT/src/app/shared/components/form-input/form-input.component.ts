import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {FormControl, ReactiveFormsModule} from "@angular/forms";
import {JsonPipe, KeyValuePipe, NgClass, NgForOf, NgIf} from "@angular/common";
import {FormHelperText, FormHelperVisibility, FormInputService} from "../../services/form-input.service";
import {takeUntil} from "rxjs/operators";
import {Subject} from "rxjs";

@Component({
  selector: 'dhms-form-input',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgForOf,
    NgIf,
    KeyValuePipe,
    JsonPipe,
    NgClass
  ],
  templateUrl: './form-input.component.html',
  styleUrl: './form-input.component.scss'
})
export class FormInputComponent implements OnInit, OnDestroy {
  @Input() inputId = '';
  @Input() control = new FormControl;
  @Input() label = '';
  @Input() errors: Record<string,string> = {};
  @Input() type = "text";
  @Input() maxlength = '';
  @Input() required: boolean = false;
  @Input() disabled: boolean = false;

  displayValidation = false;
  displayCustomTextHelper = false;
  textHelperMessage = '';
  private _formInputServiceSubject$: Subject<void>;

  constructor(private _formInputService: FormInputService) {
    this._formInputServiceSubject$ = new Subject<void>();
  }

  ngOnInit(): void {
    this._formInputService.onTextChange()
      .pipe(takeUntil(this._formInputServiceSubject$))
      .subscribe((message: FormHelperText) => this.setMessage(message));

    this._formInputService.onHelperVisibilityChange()
      .pipe(takeUntil(this._formInputServiceSubject$))
      .subscribe((visible: FormHelperVisibility) => this.setHelperVisiblity(visible));

    this._formInputService.onShowValidationChange()
      .pipe(takeUntil(this._formInputServiceSubject$))
      .subscribe( res => this.setValidationVisibility(res))

    this._formInputService.onShowValidationForInputChange()
      .pipe(takeUntil(this._formInputServiceSubject$))
      .subscribe(res => this.setValidationVisibilityForInput(res))
  }

  private setMessage(frmHelper: FormHelperText)
  {
    if (frmHelper.inputId == this.inputId)
    {
      this.textHelperMessage = frmHelper.message;
    }
  }

  private setHelperVisiblity(visibleHelper: FormHelperVisibility)
  {
    if (visibleHelper.inputId == this.inputId)
    {
      this.displayCustomTextHelper = visibleHelper.visible
    }
  }

  private setValidationVisibility(visible: boolean)
  {
    if(this.control.invalid) {
      this.displayValidation = visible
    }
  }

  private setValidationVisibilityForInput(formHelper: FormHelperVisibility) {
    if(this.inputId == formHelper.inputId)
    {
      this.displayValidation = formHelper.visible
    }
  }

  ngOnDestroy() {
    this._formInputServiceSubject$.next();
    this._formInputServiceSubject$.complete();
  }

  onChange() {
    if(this.displayCustomTextHelper) {
      this.displayCustomTextHelper = false;
    }
    if(this.displayValidation) {
      this.displayValidation = false;
    }
  }
}
