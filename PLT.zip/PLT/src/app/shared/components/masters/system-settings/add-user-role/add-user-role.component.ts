import {Component, OnDestroy, OnInit} from '@angular/core';
import { SvgIconComponent } from '../../../svg-icon/svg-icon.component';
import { ToggleSwitchComponent } from '../../../toggle-switch/toggle-switch.component';
import { InputTextComponent } from '../../../input-text/input-text.component';
import { SelectMenuComponent } from '../../../select-menu/select-menu.component';
import { DatePickerComponent } from '../../../date-picker/date-picker.component';
import { AccordionComponent } from '../../../accordion/accordion.component';
import { CheckboxComponent } from '../../../checkbox/checkbox.component';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { FormInputComponent } from '../../../form-input/form-input.component';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { UserRoleService } from 'src/app/services/user-role.service';
import { ToastrService } from 'ngx-toastr';
import { SlidingPanelService } from 'src/app/shared/services/sliding-panel.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { UserRole } from 'src/app/models/user-role';
import { UserRoleAccessControl } from 'src/app/models/user-role-access-control';
import { HttpErrorResponse } from '@angular/common/http';
import { ModuleRegistry, ValueCache } from '@ag-grid-community/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { AccessControl, AccessControlItem } from 'src/app/models/access-control';
import {FormInputService} from "../../../../services/form-input.service";
import {alphanumericValidator} from "../../../../validators/alphanumeric-validator";
import {skip} from "rxjs/operators";
import {ConfirmationModalComponent} from "../../hub/confirmation-modal/confirmation-modal.component";

ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
  selector: 'dhms-slider',
  standalone: true,
  imports: [SvgIconComponent,
    ToggleSwitchComponent,
    InputTextComponent,
    SelectMenuComponent,
    DatePickerComponent,
    AccordionComponent,
    CheckboxComponent,
    ReactiveFormsModule,
    NgIf,
    FormInputComponent,
    CommonModule, ConfirmationModalComponent],
  templateUrl: './add-user-role.component.html',
  styleUrl: './add-user-role.component.scss'
})
export class AddUserRoleComponent implements OnInit, OnDestroy {
  isSlidingMenuOpen: boolean = true;
  isAccordionOpen: boolean = false;
  isPopupVisible: boolean = false;
  isRotateIcon: boolean = false;
  accessControls: AccessControlItem[] = [];
  accessControlsLevel1: AccessControlItem[] = [];
  userRoleAccessControlsData: UserRoleAccessControl[] = [];
  showClosingModal = false

  private subscriptions = new Subscription();
  private destroy$ = new Subject<void>();

  manageRoles = new FormGroup({
      roleName: new FormControl('',[Validators.required, Validators.maxLength(50), alphanumericValidator()]),
      roleType: new FormControl('', [Validators.required]),
      roleAppliedTo: new FormControl('', [Validators.required]),
      roleStatus: new FormControl('active'),
      roleAccessControl: new FormControl(''),
    });

    constructor(private userRoleService: UserRoleService,
      private formInputService: FormInputService,
      private toastService: ToastrService,
      private slidingService: SlidingPanelService,
      private modalService: ModalService,
      ) {
        this.subscriptions.add(
          this.userRoleService.getAccessControls().pipe(takeUntil(this.destroy$)).subscribe((data: AccessControl[]) => {
            this.accessControls = data.map(ac => new AccessControlItem(ac));
            var tempAccessControls = this.accessControls;
            this.accessControls.forEach(function(item){
              item.childControlsLevel2 = [];
              item.childControlsLevel3 = [];
              item.childControlsLevel4 = [];
              var filteredLevel2 = tempAccessControls.filter((value) => value.parentControlId===item.id
                && value.controlLevelId===2)
              var filteredLevel3 = tempAccessControls.filter((value) => value.parentControlId===item.id
              && value.controlLevelId===3)
              var filteredLevel4 = tempAccessControls.filter((value) => value.parentControlId===item.id
              && value.controlLevelId===4)
              item.childControlsLevel2= filteredLevel2;
              item.childControlsLevel3=filteredLevel3;
              item.childControlsLevel4=filteredLevel4;
            });
            this.accessControlsLevel1 = this.accessControls.filter((value) =>
              value.parentControlId===null && value.controlLevelId===1);
          })
        );
      }

  ngOnInit() {
    this.slidingService.closeRequestListener()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.cancel()
      })

    this.slidingService.onOutsideClick()
      .pipe(takeUntil(this.destroy$), skip(1))
      .subscribe( res => {
        this.cancel()
      })
    }

  roleNameErrors: Record<string, string> = {
    required: `Role Name is required`,
    maxlength: `Max length of Role Name is 50 characters`,
    alphanumeric: `Role Name must be alphanumeric`
  }

  rotateIcon() {
    this.isRotateIcon = !this.isRotateIcon;
  }
  togglePopupVisibility() {
    this.isPopupVisible = !this.isPopupVisible;
  }
  toggleslidingMenu() {
    this.isSlidingMenuOpen = !this.isSlidingMenuOpen;
  }

  toggleAccordion() {
    this.isAccordionOpen = !this.isAccordionOpen;
  }

  cancel() {
      if(this.manageRoles.dirty) {
        this.showClosingModal = true
        this.modalService.openModal({
          message: 'You have unsaved changes in the screen. Do you wish to continue without saving?',
          confirmText: 'Yes',
          cancelText: 'No',
          show: true,
          onConfirm: () => this.slidingService.close(),
          onCancel: () => this.showClosingModal = false
        });
      } else {
        this.slidingService.close()
      }
  }

  print(data:any){
    console.log(data);
  }

  save() {

    this.userRoleAccessControlsData = [];

    this.accessControlsLevel1.forEach((item) => {
      if(item.isSelected===true){
        var checkChangedValues1 = new UserRoleAccessControl();
        checkChangedValues1.accessControlId =item.id;
        checkChangedValues1.isObsolete = item.isSelected ? false : true;
        this.userRoleAccessControlsData.push(checkChangedValues1);
      }
      if(item.childControlsLevel2?.length !== 0) {
        item.childControlsLevel2?.forEach((itemChild2) => {
          if(itemChild2.isSelected===true) {
            var checkChangedValues2 = new UserRoleAccessControl();
            checkChangedValues2.accessControlId =itemChild2.id;
            checkChangedValues2.isObsolete = itemChild2.isSelected ? false : true;
            this.userRoleAccessControlsData.push(checkChangedValues2);
          }
          if(itemChild2.childControlsLevel3?.length !== 0) {
            itemChild2.childControlsLevel3?.forEach((itemChild3) => {
              if(itemChild3.isSelected===true) {
                var checkChangedValues3 = new UserRoleAccessControl();
                checkChangedValues3.accessControlId =itemChild3.id;
                checkChangedValues3.isObsolete = itemChild3.isSelected ? false : true;
                this.userRoleAccessControlsData.push(checkChangedValues3);
              }
              if(itemChild3.childControlsLevel4?.length !== 0){
                itemChild3.childControlsLevel4?.forEach((itemChild4) => {
                  if(itemChild4.isSelected===true) {
                    var checkChangedValues4 = new UserRoleAccessControl();
                    checkChangedValues4.accessControlId =itemChild4.id;
                    checkChangedValues4.isObsolete = itemChild4.isSelected ? false : true;
                    this.userRoleAccessControlsData.push(checkChangedValues4);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (this.manageRoles.invalid) {
      this.markFormFieldsAsTouched(this.manageRoles);
      this.formInputService.showValidation(true);
      this.toastService.error("Please fill in all required fields correctly.");
      return;
    }
      const userRole : UserRole = {
        name: this.manageRoles.get('roleName')!.value!,
        typeIdRef: Number(this.manageRoles.get('roleType')!.value!),
        appliedToRef: Number(this.manageRoles.get('roleAppliedTo')!.value!),
        isObsolete: this.manageRoles.get('roleStatus')!.value === 'inactive'
      }

      this.userRoleService.addUserRole(userRole).subscribe({
          next: (res) => {
            if (this.userRoleAccessControlsData.length>0)
            {
              this.userRoleAccessControlsData.forEach(item => item.userRoleId = res.id);
              this.addPermissions(res.id!);
            }
            else{
              this.toastService.success("User Role saved successfully")
              this.slidingService.close()
            }

          },
          error: (err: HttpErrorResponse) => {
            if(err.status === 400 && err.error.includes('User Role already exists.')) {
              this.toastService.error("Role Name already exists.");
            }
            else {
              this.toastService.error("HTTP Error: " + err.status);
            }
          }
        }
      )
  }

  addPermissions(userRoleId: number) {
    this.userRoleService.addUserRoleAccessControl(this.userRoleAccessControlsData).subscribe({
      next: (res) => {
        this.toastService.success("User Role and permissions saved successfully");
        this.slidingService.close();
      },
      error: (err: HttpErrorResponse) => {
        this.toastService.error("HTTP Error: " + err.status);
      }
    }
  )
  }

  markFormFieldsAsTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markFormFieldsAsTouched(control);
      }
    });
  }

  receiveCheckChangedEvent(userRoleAccessControl: UserRoleAccessControl) {

    const accessControl = this.accessControls.find(x => x.id === userRoleAccessControl.accessControlId);
    accessControl?.toggleSelection(userRoleAccessControl.isObsolete ?? false);
  }

  handleConfirm(){
    this.modalService.closeModal();
  }

  handleCancel(){
    this.modalService.closeModal();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }
}
