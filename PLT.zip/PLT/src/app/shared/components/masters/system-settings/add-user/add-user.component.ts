import {Component, OnDestroy, OnInit} from '@angular/core';
import { AgGridAngular } from '@ag-grid-community/angular';
import { ColDef, ModuleRegistry } from '@ag-grid-community/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { SvgIconComponent } from '../../../svg-icon/svg-icon.component';
import { ToggleSwitchComponent } from '../../../toggle-switch/toggle-switch.component';
import { InputTextComponent } from '../../../input-text/input-text.component';
import { SelectMenuComponent } from '../../../select-menu/select-menu.component';
import { DatePickerComponent } from '../../../date-picker/date-picker.component';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { FormInputComponent } from '../../../form-input/form-input.component';
import { ToastrService } from 'ngx-toastr';
import { SlidingPanelService } from '../../../../services/sliding-panel.service';
import { ModalService } from '../../../../services/modal.service';
import { HttpErrorResponse } from '@angular/common/http';
import { UserService } from '../../../../../services/user.service';
import { User } from '../user.model';
import { HubService } from '../../hub/hub.service';
import { Observable, Subject, Subscription, forkJoin, takeUntil } from 'rxjs';
import { Hub } from '../../hub/hub.model';
import { UserRole } from 'src/app/models/user-role';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserRoleToHubMapping } from 'src/app/models/user-role-to-hub-mapping';
import { FormInputService } from '../../../../services/form-input.service';
import { alphanumericValidator } from '../../../../validators/alphanumeric-validator';
import {skip} from "rxjs/operators";
import {ConfirmationModalComponent} from "../../hub/confirmation-modal/confirmation-modal.component";
import { AccessControlService } from 'src/app/services/access-control.service';

ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
  selector: 'dhms-slider',
  standalone: true,
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.scss',
  imports: [
    AgGridAngular,
    SvgIconComponent,
    ToggleSwitchComponent,
    InputTextComponent,
    SelectMenuComponent,
    DatePickerComponent,
    ReactiveFormsModule,
    NgIf,
    FormInputComponent,
    CommonModule,
    ConfirmationModalComponent,
  ],
})
export class AddUserComponent implements OnInit, OnDestroy {
  hubs: Hub[] = [];
  userRoleOptions: UserRole[] = [];
  userRoles: UserRole[] = [];
  private subscriptions = new Subscription();
  private destroy$ = new Subject<void>();
  showDepotHubSelect: boolean = false;
  showClosingModal = false
  isAddButtonEnabled: boolean = false;

  validateContactNumber: ValidatorFn = (
    control: AbstractControl
  ): ValidationErrors | null => {
    const value = control.value;
    if (
      value &&
      (value.length < 10 || value.length > 15 || !/^\+?\d+$/.test(value))
    ) {
      return { invalidContactNumber: true };
    }
    return null;
  };

  userDetailsForm = new FormGroup({
    firstName: new FormControl('', [
      Validators.required,
      Validators.maxLength(50),
      alphanumericValidator(),
    ]),
    surname: new FormControl('', [
      Validators.required,
      Validators.maxLength(50),
      alphanumericValidator(),
    ]),
    emailAddress: new FormControl('', [Validators.required, Validators.email, Validators.pattern('[a-zA-Z0-9._%+-]{1,}@[a-zA-Z0-9.-]{2,}[.]{1}[a-zA-Z]{2,}')]),
    contactNumber: new FormControl('', [this.validateContactNumber]),
    status: new FormControl('active'),
  });

  userRoleForm = new FormGroup({
    userRole: new FormControl('', [Validators.required]),
    depotHubId: new FormControl('', [Validators.required]),
  });

  nameErrors: Record<string, string> = {
    required: `First Name is required`,
    maxlength: `Max length of First Name is 50 characters`,
    alphanumeric: `First Name must be alphanumeric`,
  };

  surnameErrors: Record<string, string> = {
    required: `Surname is required`,
    maxlength: `Max length of Surname is 50 characters`,
    alphanumeric: `Surname must be alphanumeric`,
  };

  constructor(
    private userService: UserService,
    private hubService: HubService,
    private toastService: ToastrService,
    private slidingService: SlidingPanelService,
    private modalService: ModalService,
    private userRoleService: UserRoleService,
    private formService: FormInputService,
    public accessControlService: AccessControlService
  ) {}

  handleConfirm(){
    this.modalService.closeModal();
  }

  handleCancel(){
    this.modalService.closeModal();
  }

  actionCellRenderer: (params: any) => HTMLElement = (params: any) => {
    const removeButton = document.createElement('button');
    removeButton.innerHTML =
      '<img class="mt-2" src="../../../../assets/icons/grid-delete.svg" />';
    removeButton.onclick = () => {
      this.removeUserRole(params.node.rowIndex);
    };

    const div = document.createElement('div');
    div.classList.add('flex', 'justify-center', 'items-center');
    div.appendChild(removeButton);
    return div;
  };

  rowData: any[] = [];
  colDefs: ColDef[] = [
    { headerName: 'User Role', field: 'User Role', flex: 1 },
    { headerName: 'Depot / Hub Name', field: 'Hub Name', flex: 1 },
    {
      headerName: 'Status',
      field: 'Status',
      cellRenderer: this.statusCellRenderer,
      flex: 1,
    },
    {
      headerName: 'Action',
      field: 'Action',
      cellRenderer: this.actionCellRenderer,
      width: 110,
    },
  ];

  nameId = 'name';
  aliasId = 'alias';
  descriptionId = 'description';

  statusCellRenderer(params: any) {
    const value = params.value;
    let cellValue = '';
    let backgroundColor = '';
    let textColor = '';
    let textValue = '';

    switch (value) {
      case true:
        backgroundColor = '#00B89533';
        textColor = '#00B895';
        textValue = 'ACTIVE';
        break;
      case false:
        backgroundColor = '#FBD9D3';
        textColor = 'red';
        textValue = 'INACTIVE';
        break;
      default:
        break;
    }

    cellValue = `<div style=""><span style="font-size:10px; font-weight:500; padding:2px 5px; background-color: ${backgroundColor}; color: ${textColor};">${textValue}</span></div>`;
    return cellValue;
  }

  ngOnInit(): void {
    this.subscriptions.add(
      this.hubService
        .getHubs()
        .pipe(takeUntil(this.destroy$))
        .subscribe((data: Hub[]) => {
          this.hubs = data;
        })
    );

    this.subscriptions.add(
      this.userRoleService
        .getUserRoles()
        .pipe(takeUntil(this.destroy$))
        .subscribe((data: UserRole[]) => {
          this.userRoleOptions = data;
        })
    );

    this.slidingService.closeRequestListener()
    .pipe(takeUntil(this.destroy$))
    .subscribe(res => {
      this.cancel()
    })

    this.slidingService.onOutsideClick()
      .pipe(takeUntil(this.destroy$), skip(1))
      .subscribe(res => {
        this.cancel()
      })
      
    this.subscribeToUserRoleChanges();
  }

  subscribeToUserRoleChanges() {
    this.userRoleForm
      .get('userRole')
      ?.valueChanges.subscribe((selectedRoleName) => {
        const selectedRole = this.userRoleOptions.find(
          (role) => role.name! === selectedRoleName
        );
        if (selectedRole && selectedRole.appliedToRef === 1) {
          this.showDepotHubSelect = true;
        } else {
          this.showDepotHubSelect = false;
          this.userRoleForm.get('depotHubName')?.reset();
        }
      });
  }

  cancel() {
    if(this.userRoleForm.dirty || this.userDetailsForm.dirty) {
    this.showClosingModal = true
    this.modalService.openModal({
      message: 'You have unsaved changes in the screen. Do you wish to continue without saving?',
      confirmText: 'Yes',
      cancelText: 'No',
      show: true,
      onConfirm: () => this.slidingService.close(),
      onCancel: () => { this.showClosingModal = false },
    });
  } else {
    this.slidingService.close()
  }
  }

  addRole() {
    const userRoleId = this.userRoleForm.get('userRole')?.value;
    const depotHubId = this.userRoleForm.get('depotHubId')?.value;

    // Check if the mapping already exists
    const mappingExists = this.userRoles.some(role =>
      role.name === userRoleId && role.depotHubName === depotHubId
    );

    if (mappingExists) {
      this.toastService.error('This role is already assigned to the selected hub.');
      return;
    }

    if (this.userRoleForm.valid) {
      const selectedHub = this.hubs.find(hub => hub.name === this.userRoleForm.get('depotHubId')?.value);
      const selectedUserRole = this.userRoleOptions.find(role => role.name === userRoleId);

      if (selectedHub && selectedUserRole) {
        const newUserRole: UserRole = {
          name: selectedUserRole.name,
          depotHubName: selectedHub.name,
          depotHubId: selectedHub.id,
          id: selectedUserRole.id,
        };

        this.userRoles.push(newUserRole);
        this.updateGridData();

        // Clear the form fields
        this.userRoleForm.reset({
          userRole: '',
          depotHubId: ''
        });
      }
    }
  }

  addUserRoles(userId: number) {
    const mappings: Observable<any>[] = this.userRoles.map((userRole) => {
      const userRoleHubMapping: UserRoleToHubMapping = {
        userId: userId,
        userRoleId: userRole.id,
        hubId: userRole.depotHubId,
        isObsolete: false,
      };

      return this.userRoleService.addUserRoleToHubMapping(userRoleHubMapping);
    });

    if (mappings.length > 0) {
      forkJoin(mappings).subscribe({
        next: (responses) => {
          this.toastService.success('User roles saved successfully');
          this.slidingService.close();
        },
        error: (error) => {
          this.toastService.error('An error occurred while saving user roles');
        },
      });
    }
  }

  removeUserRole(index: number) {
    this.userRoles.splice(index, 1);
    this.updateGridData();
  }

  updateGridData() {
    this.rowData = this.userRoles.map((role) => ({
      'User Role': role.name,
      'Hub Name': role.depotHubName,
      Status: true,
      Actions: 'No',
    }));
  }

  save() {
    if (this.userDetailsForm.invalid) {
      this.markFormFieldsAsTouched(this.userDetailsForm);
      this.formService.showValidation(true);

      this.toastService.error('Please fill in all required fields correctly.');
      return;
    }
    const user: User = {
      firstName: this.userDetailsForm.get('firstName')!.value!,
      surname: this.userDetailsForm.get('surname')!.value!,
      email: this.userDetailsForm.get('emailAddress')!.value!,
      contactNumber: this.userDetailsForm.get('contactNumber')!.value!,
      isObsolete: this.userDetailsForm.get('status')!.value === 'inactive',
      auth0Id: '0',
      username: 'username',
    };

    this.userService.addUser(user).subscribe({
      next: (res: User) => {
        if (this.userRoles.length > 0) {
          this.addUserRoles(res.id!);
        } else {
          this.toastService.success('User saved successfully');
          this.slidingService.close();
        }
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 409) {
          this.toastService.error('Email address already in use');
        }
      },
    });
  }


  markFormFieldsAsTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markFormFieldsAsTouched(control);
      }
    });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }
}
