import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditUserRoleComponent } from './edit-user-role.component';
import { HttpClientModule } from '@angular/common/http';

describe('EditUserRoleComponent', () => {
  let component: EditUserRoleComponent;
  let fixture: ComponentFixture<EditUserRoleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditUserRoleComponent, HttpClientModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EditUserRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
