import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemSettingsComponent } from './system-settings.component';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { UserService } from '../../../../services/user.service';
import { ToastrServiceWrapper } from 'src/app/services/toastr-wrapper.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

  // Mock UserService
  const mockUserService = {
    getUsers: jasmine.createSpy('getUsers').and.returnValue(of([{ firstName: 'John', surname: 'Doe', email: 'john.doe@example.com' }]))
  };

describe('SystemSettingsComponent', () => {
  let component: SystemSettingsComponent;
  let fixture: ComponentFixture<SystemSettingsComponent>;
  let mockUserRoleService: any;

  beforeEach(async () => {
    mockUserRoleService = jasmine.createSpyObj('UserRoleService', ['getUserRoles', 'getAccessControls', 'getUserRoleAccessControls']);

    mockUserRoleService.getUserRoles.and.returnValue(of([]));
    mockUserRoleService.getAccessControls.and.returnValue(of([]));
    mockUserRoleService.getUserRoleAccessControls.and.returnValue(of([]));

    await TestBed.configureTestingModule({
      imports: [SystemSettingsComponent, HttpClientModule, ToastrModule.forRoot(), BrowserAnimationsModule],
      providers: [{ provide: UserService, useValue: mockUserService }, { provide: UserRoleService, useValue: mockUserRoleService }, ToastrServiceWrapper]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SystemSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should fetch user roles and settings on init', () => {
    expect(mockUserRoleService.getUserRoles).toHaveBeenCalled();
    expect(mockUserRoleService.getAccessControls).toHaveBeenCalled();
    expect(mockUserRoleService.getUserRoleAccessControls).toHaveBeenCalled();
    expect(component.userRoles).toEqual([]);
  });


});
