import { Component, OnInit, ViewChild } from '@angular/core';
import { ActiveItemService } from 'src/app/services/active-item.service';
import { SvgIconComponent } from '../../svg-icon/svg-icon.component';
import {
  GridColumnConfig,
  GridComponent,
  GridContext,
} from '../../grid/grid.component';
import { UserService } from '../../../../services/user.service';
import { CommonModule } from '@angular/common';
import { ToastrServiceWrapper } from 'src/app/services/toastr-wrapper.service';
import { SlidingPanelService } from 'src/app/shared/services/sliding-panel.service';
import { AddUserComponent } from './add-user/add-user.component';
import { SlidingPanelComponent } from '../../sliding-panel/sliding-panel.component';
import {
  Subject,
  Subscription,
  forkJoin,
  map,
  of,
  switchMap,
  takeUntil,
} from 'rxjs';
import { AddUserRoleComponent } from './add-user-role/add-user-role.component';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ConfirmationModalComponent } from '../hub/confirmation-modal/confirmation-modal.component';
import { MatTabsModule } from '@angular/material/tabs';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserRole } from 'src/app/models/user-role';
import { UserRoleAccessControl } from 'src/app/models/user-role-access-control.model';
import { AccessControl } from 'src/app/models/access-control';
import { HubService } from '../hub/hub.service';
import { Hub } from '../hub/hub.model';
import { CustomGridHeaderComponent } from '../../grid/custom-grid-header-component/custom-grid-header-component.component';
import { GridApi } from '@ag-grid-community/core';
import { EditUserRoleComponent } from './edit-user-role/edit-user-role.component';
import { UserRoleToHubMapping } from 'src/app/models/user-role-to-hub-mapping';
import { EditUserComponent } from './edit-user/edit-user.component';
import { User } from './user.model';
import { GridService } from "../../../services/grid.service";
import { GridSearchBarComponent } from "../../grid-search-bar/grid-search-bar.component";
import { AccessControlService } from 'src/app/services/access-control.service';

@Component({
  selector: 'dhms-system-settings',
  standalone: true,
  templateUrl: './system-settings.component.html',
  styleUrl: './system-settings.component.scss',
  providers: [ToastrServiceWrapper],
  imports: [
    SvgIconComponent,
    GridComponent,
    CommonModule,
    SlidingPanelComponent,
    MatTabsModule,
    ConfirmationModalComponent,
    CustomGridHeaderComponent,
    GridSearchBarComponent,
  ],
})
export class SystemSettingsComponent implements OnInit, GridContext {
  isSidebarCollapsed: boolean = false;
  private subscriptions = new Subscription();
  private destroy$ = new Subject<void>();
  activeItem: string = '';
  data: any[] = [];
  isPopupVisible: boolean = false;
  userRoles: UserRole[] = [];
  standardUserRolesGridConfigReady: boolean = false;
  dataReady: boolean = false;
  accessControls: AccessControl[] = [];
  userRoleAccessControls: UserRoleAccessControl[] = [];
  editingStandardUserRoles: boolean = false;
  @ViewChild('gridRef') gridComponent!: GridComponent;

  private gridApi!: GridApi;
  private rolePermissionsMapping: { [key: number]: { [field: string]: boolean } } = {};
  private expandedRowsMap: Map<number, boolean> = new Map();

  userAccountSettingsGridConfig: GridColumnConfig[] = [
    {
      headerName: 'First Name',
      field: 'firstName',
      suppressHeaderMenuButton: true,
    },
    { headerName: 'Surname', field: 'surname', suppressHeaderMenuButton: true },
    {
      headerName: 'Email Address',
      field: 'email',
      useRenderer: 'emailVerified',
      suppressHeaderMenuButton: true,
      minWidth: 300,
    },
    {
      headerName: 'Contact Number',
      field: 'contactNumber',
      suppressHeaderMenuButton: true,
    },
    {
      headerName: 'Assigned To',
      field: 'assignedTo',
      suppressHeaderMenuButton: true,
    },
    {
      headerName: 'Status',
      field: 'isObsolete',
      useRenderer: 'status',
      suppressHeaderMenuButton: true,
      pinned: 'right',
    },
    {
      headerName: 'Actions',
      field: 'Actions',
      useRenderer: 'userAction',
      suppressHeaderMenuButton: true,
      pinned: 'right',
      minWidth: 150,
      maxWidth: 150,
    },
  ];

  standardUserRolesGridConfig: GridColumnConfig[] = [];
  standardTabData: GridRow[] = [];
  originalStandardDataSnapshot: GridRow[] = [];
  userRoleAccessControlMap = new Map<number, UserRoleAccessControl[]>();

  public components: { [p: string]: any } = {
    agColumnHeader: CustomGridHeaderComponent,
  };

  constructor(
    public activeItemService: ActiveItemService,
    private userService: UserService,
    private toastr: ToastrServiceWrapper,
    private slidingPanelService: SlidingPanelService,
    public modalService: ModalService,
    private userRoleService: UserRoleService,
    private hubService: HubService,
    private gridService: GridService,
    public accessControlService: AccessControlService
  ) {}

  public toggleEditStandardUserRoles = (): void => {
    this.editingStandardUserRoles = !this.editingStandardUserRoles;
    this.editingStandardUserRoles
      ? this.gridComponent.switchToCheckboxRenderer()
      : this.gridComponent.switchToBooleanRenderer();

    if (this.gridApi) {
      this.gridApi.refreshHeader();
    }
  };

  async ngOnInit(): Promise<void> {
    this.activeItemService.setActiveSubItem('System Settings');
    this.setActiveItem('User Roles and Permissions');
    this.fetchDataAndUpdateConfig();
    this.observePanelVisibility();

    this.subscriptions.add(
      this.activeItemService.isSidebarCollapsed$.subscribe((isCollapsed) => {
        this.isSidebarCollapsed = isCollapsed;
      })
    );

    this.subscriptions.add(
      this.accessControlService.accessControlsLoaded$.pipe(
        takeUntil(this.destroy$),
        switchMap(loaded => {
          if (loaded && this.accessControlService.hasAccess('List Standard Roles')) {
            return of(true);
          } else {
            return of(false);
          }
        })
      ).subscribe(hasAccess => {
        if (hasAccess) {
          this.loadStandardTabData();
        } else {
          this.toastr.error('You do not have permission to list standard roles');
        }
      })
    );
  }

  loadStandardTabData() {
    this.subscriptions.add(
      forkJoin({
        accessControls: this.userRoleService.getAccessControls(),
        userRoleAccessControls: this.userRoleService.getUserRoleAccessControls(),
      })
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: ({ accessControls, userRoleAccessControls }) => {
            this.accessControls = accessControls;
            this.userRoleAccessControls = userRoleAccessControls;
            this.standardTabData = this.populateStandardTabData(
              this.accessControls,
              this.userRoleAccessControls
            );
            this.originalStandardDataSnapshot = JSON.parse(
              JSON.stringify(this.standardTabData)
            );
            this.dataReady = true;
            this.refreshGrid();
          },
          error: (error) => {
            this.toastr.error('Failed to load user roles', '');
            console.error('Error fetching data: ', error);
          },
        })
    );
  }

  private observePanelVisibility(): void {
    this.subscriptions.add(
      this.slidingPanelService.onPanelVisibilityChange().subscribe((isVisible) => {
        if (!isVisible) {
          this.onSlidingPanelClosed();
        }
      })
    );
  }

  private onSlidingPanelClosed(): void {
    this.loadStandardTabData();
    this.populateUserAccountSettings();
  }

  private captureExpandedStates() {
    this.expandedRowsMap.clear();
    this.traverseAndProcessRows(this.standardTabData, (row) => {
      this.expandedRowsMap.set(row.accessControlId, !!row.showChildren);
    });
  }

  private traverseAndProcessRows(rows: GridRow[], process: (row: GridRow) => void) {
    rows.forEach((row) => {
      process(row);
      if (row.children && row.children.length > 0) {
        this.traverseAndProcessRows(row.children, process);
      }
    });
  }

  fetchDataAndUpdateConfig() {
    this.userRoleService.getUserRoles().pipe(takeUntil(this.destroy$)).subscribe((data: UserRole[]) => {
      this.userRoles = data;
      this.updateGridConfig();
    });
  }

  setActiveItem(itemName: string) {
    this.activeItem = itemName;
    this.activeItemService.setHeaderTitle(itemName);
    if (itemName == 'User Account Settings') {
      this.populateUserAccountSettings();
    }
  }

  populateUserAccountSettings() {
    forkJoin({
      hubs: this.fetchHubs(),
      users: this.fetchUsers(),
    })
      .pipe(
        switchMap(({ hubs, users }) => {
          const hubMap = this.createHubMap(hubs);
          const userIds = users.map((user) => user.id!);
          return this.userRoleService.getUserRoleToHubMappingsForUsers(userIds).pipe(
            map((mappings) =>
              users.map((user) => ({
                ...user,
                assignedTo: this.getHubAssignmentsForUser(mappings[user.id!], hubMap),
              }))
            )
          );
        })
      )
      .subscribe((finalUsers) => {
        this.data = finalUsers;
      });
  }

  fetchHubs() {
    return this.hubService.getHubs();
  }

  fetchUsers() {
    return this.userService.getUsers();
  }

  getHubAssignmentsForUser(mapping: UserRoleToHubMapping[] | undefined, hubMap: Map<number, string>): string {
    if (!mapping) {
      return 'None';
    }
    const assignedHubs = mapping
      .map((mapping) => hubMap.get(mapping.hubId!))
      .filter((name) => !!name)
      .join(', ');
    return assignedHubs || 'None';
  }

  createHubMap(hubs: Hub[]) {
    return new Map(hubs.map((hub) => [hub.id, hub.name]));
  }

  togglePopupVisibility() {
    if (this.activeItem == 'User Roles and Permissions') {
      this.isPopupVisible = !this.isPopupVisible;
    } else {
      this.addUser();
    }
  }

  addUser() {
    if (this.accessControlService.hasAccess('Create a new User')) {
      this.slidingPanelService.setTitle('Add User');
      this.slidingPanelService.setContent(AddUserComponent);
      this.slidingPanelService.show();
    } else {
      this.toastr.error('You do not have permission to create a new user.');
    }
  }

  addUserRole() {
    if (this.accessControlService.hasAccess('Create a new Role')) {
      this.slidingPanelService.setTitle('Add User Role & Permissions');
      this.slidingPanelService.setContent(AddUserRoleComponent);
      this.slidingPanelService.show();
    } else {
      this.toastr.error('You do not have permission to create a new role.');
    }
  }

  editUser(user: User) {
    if (this.accessControlService.hasAccess('Edit User')) {
      this.slidingPanelService.setTitle('Edit User Account Settings');
      this.slidingPanelService.setContentWithDataChange({
        content: EditUserComponent,
        data: user,
      });
      this.slidingPanelService.show();
    } else {
      this.toastr.error('You do not have permission to edit user.');
    }
  }

  editUserRoleAccess(headerName: string): void {
    const userRole = this.userRoles.find((role) => role.name === headerName);
    if (!userRole) {
      console.error('No user role found with the name:', headerName);
      return;
    }

    const accessControls = this.userRoleAccessControlMap.get(userRole.id!);
    if (!accessControls) {
      console.error('No access controls found for the user role:', headerName);
      return;
    }

    if (this.accessControlService.hasAccess('Edit Standard Roles')) {
      this.slidingPanelService.setTitle(`Edit Roles and Permissions`);
      this.slidingPanelService.setContentWithDataChange({
        content: EditUserRoleComponent,
        data: { userRole, accessControls },
      });
      this.slidingPanelService.show();
    } else {
      this.toastr.error('You do not have permission to edit standard roles.');
    }
  }

  handleConfirm() {
    this.modalService.close();
  }

  handleCancel() {
    this.modalService.close();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  handleGridAction(event: any) {
    const { type, data, gridApi } = event;

    switch (type) {
      case 'sendEmail':
        this.userService.resendWelcomeEmail(data.id).subscribe({
          next: () => {
            this.toastr.success('Welcome email sent successfully', '');
          },
          error: (error) => {
            this.toastr.error('Failed to send welcome email', '');
          }
        });
        break;

      case 'checkboxChange':
        this.handleCheckboxChange(data);
        break;

      case 'edit':
        this.handleEdit(data);
        break;

      case 'gridReady':
        this.handleGridReady(gridApi);
        break;

      case 'rowDoubleClicked':
        this.handleRowDoubleClicked(data);
        break;

      case 'delete':
        this.handleDelete(data);
        break;

      case 'unarchive':
        this.handleUnarchive(data);
        break;
    }
  }

  handleCheckboxChange(data: any) {
    const { accessControlId, field, checked } = data;
    const id = parseInt(accessControlId);

    const updateSuccess = this.updateRolePermissions(this.standardTabData, id, field, checked);

    if (updateSuccess) {
      this.refreshGrid();
    }
  }

  handleEdit(data: any) {
    if (this.activeItem === 'User Account Settings') {
      this.editUser(data);
    }
  }

  handleGridReady(gridApi: any) {
    if (gridApi) {
      this.gridApi = gridApi;
    }
  }

  handleRowDoubleClicked(data: any) {
    if (this.activeItem === 'User Account Settings') {
      this.editUser(data);
    }
  }

  handleDelete(data: any) {
    if (this.activeItem === 'User Account Settings') {
      this.showConfirmationModal('Are you sure you want to deactivate this User?', () => this.deactivateUser(data));
    }
  }

  handleUnarchive(data: any) {
    if (this.activeItem === 'User Account Settings') {
      this.showConfirmationModal('Are you sure you want to reactivate this User?', () => this.reactivateUser(data));
    }
  }

  showConfirmationModal(message: string, onConfirm: () => void) {
    this.modalService.show();
    this.modalService.openModal({
      message,
      confirmText: 'Yes',
      cancelText: 'No',
      show: true,
      onConfirm,
      onCancel: () => this.handleCancel(),
    });
  }

  updateRolePermissions(data: GridRow[], accessControlId: number, field: string, checked: boolean): boolean {
    for (let row of data) {
      if (row.accessControlId === accessControlId) {
        if (!row.rolePermissions.hasOwnProperty(field)) {
          row.rolePermissions[field] = false;
        }
        row.rolePermissions[field] = checked;
        return true;
      }

      if (row.children && row.children.length > 0) {
        if (this.updateRolePermissions(row.children, accessControlId, field, checked)) {
          return true;
        }
      }
    }
    return false;
  }

  private refreshGrid() {
    this.captureExpandedStates();

    this.traverseAndProcessRows(this.standardTabData, (row) => {
      row.showChildren = this.expandedRowsMap.get(row.accessControlId) || false;
    });

    if (this.gridApi) {
      this.gridApi.refreshCells({ force: true });
    }
  }

  cancelChanges(): void {
    this.toggleEditStandardUserRoles();
    this.standardTabData = JSON.parse(JSON.stringify(this.originalStandardDataSnapshot));
    this.gridComponent.refreshGrid(this.standardTabData);
  }

  saveUserAccessControls(): void {
    const updatePayload: {
      userRoleId: number;
      accessControlId: number;
      isObsolete: boolean;
      createdDate: Date;
      updatedDate: Date;
    }[] = [];

    const processRows = (rows: GridRow[]) => {
      for (const row of rows) {
        Object.entries(row.rolePermissions).forEach(([userRoleId, isActive]) => {
          const dataModel = {
            userRoleId: parseInt(userRoleId),
            accessControlId: row.accessControlId,
            isObsolete: !isActive,
            createdDate: new Date(),
            updatedDate: new Date(),
          };
          updatePayload.push(dataModel);
        });

        if (row.children && row.children.length > 0) {
          processRows(row.children);
        }
      }
    };

    processRows(this.standardTabData);

    this.userRoleService.updateUserRoleAccessControls(updatePayload).subscribe({
      next: (response) => {
        this.toastr.success('User Roles Updated Successfully', '');
        this.toggleEditStandardUserRoles();
        this.originalStandardDataSnapshot = JSON.parse(JSON.stringify(this.standardTabData));
        this.accessControlService.loadUserAccessControls();
      },
      error: (error) => {
        this.toastr.error('Failed to save user roles', '');
        console.error('Error updating user access controls:', error);
      },
    });

  }

  public updateGridConfig() {
    this.standardUserRolesGridConfigReady = false;

    this.standardUserRolesGridConfig = [
      {
        headerName: 'Screens/Function',
        field: 'function',
        useRenderer: 'functionColumnRenderer' as const,
        minWidth: 400,
        width: 400,
      },
      ...this.userRoles.map((role) => ({
        headerName: role.name || 'Unnamed Role',
        field: role.id?.toString() || 'defaultField',
        useRenderer: this.editingStandardUserRoles ? ('checkBoxCellRenderer' as 'checkBoxCellRenderer') : ('yesNo' as 'yesNo'),
        headerComponentParams: { showEditIcon: true },
        //cellRendererFramework : CheckboxComponent, - TODO - implement custom checkbox to change colour
        minWidth: 100,
      })),
      {
        headerName: '',
        field: 'action',
        useRenderer: 'collapseExpand' as const,
        maxWidth: 50,
        headerComponentParams: { showEditIcon: false },
        pinned: 'right',
      },
    ];
    this.standardUserRolesGridConfigReady = true;
  }

  populateStandardTabData(accessControls: AccessControl[], userRoleAccessControls: UserRoleAccessControl[]): GridRow[] {
    const gridRows: GridRow[] = [];
    const accessControlMap = new Map<number, GridRow>();

    accessControls.forEach((ac) => {
      const gridRow: GridRow = {
        function: ac.controlName ?? 'Unnamed',
        showChildren: false,
        children: [],
        level: ac.controlLevelId!,
        accessControlId: ac.id,
        rolePermissions: {},
      };
      accessControlMap.set(ac.id, gridRow);
      if (!ac.parentControlId) {
        gridRows.push(gridRow);
      } else {
        let parentRow = accessControlMap.get(ac.parentControlId);
        if (parentRow && parentRow.children) {
          parentRow.children.push(gridRow);
        }
      }
    });

    userRoleAccessControls.forEach((ura) => {
      const gridRow = accessControlMap.get(ura.accessControlId);
      if (gridRow) {
        gridRow.rolePermissions[ura.userRoleId.toString()] = !ura.isObsolete;
      }

      if (!this.userRoleAccessControlMap.has(ura.userRoleId)) {
        this.userRoleAccessControlMap.set(ura.userRoleId, []);
      }
      this.userRoleAccessControlMap.get(ura.userRoleId)?.push(ura);
    });
    return gridRows;
  }

  private assignLevelToRow(row: GridRow, level: number) {
    row.level = level;
    if (row.children) {
      row.children.forEach((child) => this.assignLevelToRow(child, level + 1));
    }
  }

  public onCheckboxChange = (id: number, field: string, isChecked: boolean) => {
    const rowNode = this.gridApi.getRowNode(id.toString());
    if (rowNode) {
      rowNode.setDataValue(field, isChecked);
      this.gridApi.refreshCells();
    }

    if (!this.rolePermissionsMapping[id]) {
      this.rolePermissionsMapping[id] = {};
    }
    this.rolePermissionsMapping[id][field] = isChecked;
  };

  refreshGridCells(): void {
    if (this.gridApi) {
      this.gridApi.refreshCells({ force: true });
    }
  }

  updateRolePermissionsMapping(id: number, field: string, isChecked: boolean) {
    if (!this.rolePermissionsMapping[id]) {
      this.rolePermissionsMapping[id] = {};
    }
    this.rolePermissionsMapping[id][field] = isChecked;
  }

  deactivateUser(user: User) {
    user.isObsolete = true;
    this.userService.editUser(user).subscribe({
      next: () => {
        this.refreshGrid();
        this.toastr.success('User deactivated successfully', '');
        this.modalService.close();
      },
      error: (error) => {
        this.toastr.error('Failed to deactivate user', '');
        this.modalService.close();
      },
    });
  }

  reactivateUser(user: User) {
    user.isObsolete = false;
    this.userService.editUser(user).subscribe({
      next: () => {
        this.refreshGrid();
        this.toastr.success('User reactivated successfully', '');
        this.modalService.close();
      },
      error: (error) => {
        this.toastr.error('Failed to reactivate user', '');
        this.modalService.close();
      },
    });
  }
}

interface GridRow {
  function: string;
  children?: GridRow[];
  showChildren?: boolean;
  level: number;
  accessControlId: number;
  rolePermissions: { [roleId: string]: boolean };
  [key: string]: any;
}
