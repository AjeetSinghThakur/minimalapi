import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import { SvgIconComponent } from '../../../svg-icon/svg-icon.component';
import { ToggleSwitchComponent } from '../../../toggle-switch/toggle-switch.component';
import { InputTextComponent } from '../../../input-text/input-text.component';
import { SelectMenuComponent } from '../../../select-menu/select-menu.component';
import { DatePickerComponent } from '../../../date-picker/date-picker.component';
import { AccordionComponent } from '../../../accordion/accordion.component';
import { CheckboxComponent } from '../../../checkbox/checkbox.component';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { FormInputComponent } from '../../../form-input/form-input.component';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { UserRoleService } from 'src/app/services/user-role.service';
import { ToastrService } from 'ngx-toastr';
import { SlidingPanelService } from 'src/app/shared/services/sliding-panel.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { UserRole } from 'src/app/models/user-role';
import { UserRoleAccessControl } from 'src/app/models/user-role-access-control';
import { HttpErrorResponse } from '@angular/common/http';
import { ModuleRegistry, ValueCache } from '@ag-grid-community/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { AccessControl, AccessControlItem } from 'src/app/models/access-control';
import {FormInputService} from "../../../../services/form-input.service";
import {alphanumericValidator} from "../../../../validators/alphanumeric-validator";
import {skip} from "rxjs/operators";
import {ConfirmationModalComponent} from "../../hub/confirmation-modal/confirmation-modal.component";

ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
  selector: 'dhms-edit-user-role',
  standalone: true,
  imports: [SvgIconComponent, ToggleSwitchComponent, InputTextComponent,
    SelectMenuComponent,
    DatePickerComponent,
    AccordionComponent,
    CheckboxComponent,
    ReactiveFormsModule,
    NgIf,
    FormInputComponent,
    CommonModule, ConfirmationModalComponent],
  templateUrl: './edit-user-role.component.html',
  styleUrl: './edit-user-role.component.scss'
})
export class EditUserRoleComponent implements OnInit, OnDestroy {
  isSlidingMenuOpen: boolean = true;
  isAccordionOpen: boolean = false;
  isPopupVisible: boolean = false;
  isRotateIcon: boolean = false;
  accessControls: AccessControlItem[] = [];
  accessControlsLevel1: AccessControlItem[] = [];
  userRoleAccessControlsData: UserRoleAccessControl[] = [];
  userRole: UserRole | undefined;
  showClosingModal = false;

  private subscriptions = new Subscription();
  private destroy$ = new Subject<void>();

  @Input() data: any

  manageRoles = new FormGroup({
    roleName: new FormControl('',[Validators.required, Validators.maxLength(50), alphanumericValidator()]),
    roleType: new FormControl('', [Validators.required]),
    roleAppliedTo: new FormControl('', [Validators.required]),
    roleStatus: new FormControl('Active'),
    roleAccessControl: new FormControl(''),
  });


  constructor(
    private userRoleService: UserRoleService,
    private toastService: ToastrService,
    private slidingService: SlidingPanelService,
    private modalService: ModalService,
    private formInputService: FormInputService,
  ) {
    this.manageRoles = new FormGroup({
      roleName: new FormControl('', [Validators.required, Validators.maxLength(50), alphanumericValidator()]),
      roleType: new FormControl('', [Validators.required]),
      roleAppliedTo: new FormControl('', [Validators.required]),
      roleStatus: new FormControl('active'),
      roleAccessControl: new FormControl(''),
    });

    this.subscriptions.add(
      this.userRoleService.getAccessControls().pipe(takeUntil(this.destroy$)).subscribe((data: AccessControl[]) => {
        this.accessControls = data.map(ac => new AccessControlItem(ac));
        this.userRole = this.data.userRole;
        this.mapAccessControls(this.data.accessControls)

        this.prefillForm(this.userRole!);
        this.accessControlsLevel1 = this.accessControls.filter((value) =>
          value.parentControlId===null && value.controlLevelId===1);

        var tempAccessControls = this.accessControls;
        this.accessControls.forEach(function(item){
          item.childControlsLevel2 = [];
          item.childControlsLevel3 = [];
          item.childControlsLevel4 = [];
          var filteredLevel2 = tempAccessControls.filter((value) => value.parentControlId===item.id
            && value.controlLevelId===2)
          var filteredLevel3 = tempAccessControls.filter((value) => value.parentControlId===item.id
          && value.controlLevelId===3)
          var filteredLevel4 = tempAccessControls.filter((value) => value.parentControlId===item.id
          && value.controlLevelId===4)
          item.childControlsLevel2= filteredLevel2;
          item.childControlsLevel3=filteredLevel3;
          item.childControlsLevel4=filteredLevel4;
        });

        this.initializeAccessControls();
      })
    );


  }

  ngOnInit() {
    this.slidingService.closeRequestListener()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.cancel()
      })

    this.slidingService.onOutsideClick()
      .pipe(takeUntil(this.destroy$), skip(1))
      .subscribe( res => {
        this.cancel()
      })
    }

    private mapAccessControls(accessControlsData: UserRoleAccessControl[]) {
      this.userRoleAccessControlsData = accessControlsData;
      const accessControlStatusMap = new Map(accessControlsData.map(ac => [ac.accessControlId, !ac.isObsolete]));

      this.accessControlsLevel1.forEach(ac => {
          ac.isSelected = accessControlStatusMap.get(ac.id) || false;
      });

      this.accessControls.forEach(ac => {
        ac.isSelected = accessControlStatusMap.get(ac.id) || false;
      });
  }

    roleNameErrors: Record<string, string> = {
      required: `Role Name is required`,
      maxlength: `Max length of Role Name is 50 characters`,
      alphanumeric: `Role Name must be alphanumeric`
    }

  handleConfirm(){
    this.modalService.closeModal();
  }

  handleCancel(){
    this.modalService.closeModal();
  }

    rotateIcon() {
      this.isRotateIcon = !this.isRotateIcon;
    }
    togglePopupVisibility() {
      this.isPopupVisible = !this.isPopupVisible;
    }
    toggleslidingMenu() {
      this.isSlidingMenuOpen = !this.isSlidingMenuOpen;
    }

    toggleAccordion() {
      this.isAccordionOpen = !this.isAccordionOpen;
    }

    cancel() {
      if(this.manageRoles.dirty) {
        this.showClosingModal = true
      this.modalService.openModal({
        message: 'You have unsaved changes in the screen. Do you wish to continue without saving?',
        confirmText: 'Yes',
        cancelText: 'No',
        show: true,
        onConfirm: () => this.slidingService.close(),
        onCancel: () => {this.showClosingModal = false}
      }); } else {
        this.slidingService.close();
      }
    }

  private prefillForm(userRole: UserRole): void {
    if (userRole) {
      this.manageRoles.patchValue({
        roleName: userRole.name,
        roleType: userRole.typeIdRef?.toString(),
        roleAppliedTo: userRole.appliedToRef?.toString(),
        roleStatus: userRole.isObsolete ? 'inactive' : 'active'
      });
    }
  }

  private initializeAccessControls(): void {
    const existingControlsMap = new Map<number, AccessControlItem>();
    const flattenAccessControls = (items: AccessControlItem[]) => {
      items.forEach(item => {
        existingControlsMap.set(item.id, item);
        if (item.childControlsLevel2) {
          flattenAccessControls(item.childControlsLevel2);
        }
        if (item.childControlsLevel3) {
          flattenAccessControls(item.childControlsLevel3);
        }
        if (item.childControlsLevel4) {
          flattenAccessControls(item.childControlsLevel4);
        }
      });
    };

    flattenAccessControls(this.accessControls);

    this.userRoleService.getAccessControls().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data: AccessControl[]) => {
        const mergeAccessControls = (newData: AccessControl[]): AccessControlItem[] => {
          return newData.map(ac => {
            const existing = existingControlsMap.get(ac.id);
            const newItem = new AccessControlItem({
              ...ac,
              isObsolete: existing ? existing.isObsolete : false,
              isSelected: existing ? existing.isSelected : false,
              childControlsLevel2: existing && existing.childControlsLevel2 ? mergeAccessControls(existing.childControlsLevel2) : [],
              childControlsLevel3: existing && existing.childControlsLevel3 ? mergeAccessControls(existing.childControlsLevel3) : [],
              childControlsLevel4: existing && existing.childControlsLevel4 ? mergeAccessControls(existing.childControlsLevel4) : [],
            });
            return newItem;
          });
        };

        this.accessControls = mergeAccessControls(data);
      },
      error: () => {
        this.toastService.error('Failed to load access controls');
        console.error('Failed to load access controls');
      }
    });
  }

  save() {
    this.userRoleAccessControlsData = [];
    this.accessControls.forEach((item) => {

      if(item) {
        var checkChangedValues = new UserRoleAccessControl();
        checkChangedValues.accessControlId =item.id;
        checkChangedValues.isObsolete = !item.isSelected;
        this.userRoleAccessControlsData.push(checkChangedValues);
      }
    })

    if (this.manageRoles.invalid) {
      this.markFormFieldsAsTouched(this.manageRoles);
      this.formInputService.showValidation(true);
      this.toastService.error("Please fill in all required fields correctly.");
      return;
    }
      const userRole : UserRole = {
        id: this.userRole?.id,
        name: this.manageRoles.get('roleName')!.value!,
        typeIdRef: Number(this.manageRoles.get('roleType')!.value!),
        appliedToRef: Number(this.manageRoles.get('roleAppliedTo')!.value!),
        isObsolete: this.manageRoles.get('roleStatus')!.value === 'inactive'
      }

      this.userRoleService.updateUserRole(userRole).subscribe({
          next: (res) => {
            if (this.userRoleAccessControlsData.length>0)
            {
              this.userRoleAccessControlsData.forEach(item => item.userRoleId = res.id);
              this.addPermissions(res.id!);
            }
            else{
              this.toastService.success("User Role updated successfully")
              this.slidingService.close()
            }

          },
          error: (err: HttpErrorResponse) => {
              this.toastService.error("HTTP Error: " + err.status);
          }
        }
      )
  }

  addPermissions(userRoleId: number) {
    this.userRoleService.updateUserRoleAccessControls(this.userRoleAccessControlsData).subscribe({
      next: (res) => {
        this.toastService.success("User Role and permissions updated successfully");
        this.slidingService.close();
      },
      error: (err: HttpErrorResponse) => {
        this.toastService.error("HTTP Error: " + err.status);
      }
    }
  )
  }

  markFormFieldsAsTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markFormFieldsAsTouched(control);
      }
    });
  }

  receiveCheckChangedEvent(userRoleAccessControl: UserRoleAccessControl) {
    const accessControl = this.accessControls.find(x => x.id === userRoleAccessControl.accessControlId);
    if(!accessControl) return;

    accessControl?.toggleSelection(userRoleAccessControl.isObsolete ?? false);

    this.synchronizeAccessControls();
  }

  updateAccessControlState(sourceItem: AccessControlItem, targetItems: AccessControlItem[]) {
    if (!targetItems) return;

    const targetItem = this.findItemById(targetItems, sourceItem.id);

    if (targetItem) {
        targetItem.isSelected = sourceItem.isSelected;
        targetItem.isObsolete = sourceItem.isObsolete;
    }
}

findItemById(items: AccessControlItem[], id: number) : AccessControlItem | null {
  for (const item of items) {
      if (item.id === id) {
          return item;
      }
      if (item.childControlsLevel2) {
          const found = this.findItemById(item.childControlsLevel2, id);
          if (found) return found;
      }
      if (item.childControlsLevel3) {
          const found = this.findItemById(item.childControlsLevel3, id);
          if (found) return found;
      }
      if (item.childControlsLevel4) {
          const found = this.findItemById(item.childControlsLevel4, id);
          if (found) return found;
      }
  }
  return null;
}


 synchronizeAccessControls() {
    this.accessControls.forEach(item => {
        this.updateAccessControlState(item, this.accessControlsLevel1);
    });
}

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }

}

