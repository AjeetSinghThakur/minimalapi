export class User {
    id?: number;
    auth0Id?: string;
    email!: string;
    username?: string;
    firstName!: string;
    surname!: string;
    isObsolete?: boolean;
    contactNumber?: string;
    isVerified?: boolean;
}
