import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Subject, Subscription, lastValueFrom, skip, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { SlidingPanelService } from 'src/app/shared/services/sliding-panel.service';
import { ColDef, GridApi, GridReadyEvent } from '@ag-grid-community/core';
import { ModuleRegistry } from '@ag-grid-community/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { AgGridAngular } from '@ag-grid-community/angular';
import { CommonModule, NgIf } from '@angular/common';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserService } from 'src/app/services/user.service';
import { AccordionComponent } from '../../../accordion/accordion.component';
import { CheckboxComponent } from '../../../checkbox/checkbox.component';
import { FormInputComponent } from '../../../form-input/form-input.component';
import { InputTextComponent } from '../../../input-text/input-text.component';
import { SelectMenuComponent } from '../../../select-menu/select-menu.component';
import { SvgIconComponent } from '../../../svg-icon/svg-icon.component';
import { ConfirmationModalComponent } from '../../hub/confirmation-modal/confirmation-modal.component';
import { HubService } from '../../hub/hub.service';
import { UserRole } from 'src/app/models/user-role';
import { Hub } from '../../hub/hub.model';
import { UserRoleToHubMapping } from 'src/app/models/user-role-to-hub-mapping';
import { User } from '../../system-settings/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ModalService } from 'src/app/shared/services/modal.service';
import { environment } from '@env/environment';
import { AuthService as Auth0AuthService } from '@auth0/auth0-angular';

ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
    selector: 'app-update-profile-panel',
    templateUrl: './update-profile-panel.component.html',
    styleUrls: ['./update-profile-panel.component.scss'],
    standalone: true,
    imports: [
        ReactiveFormsModule,
        CommonModule,
        AccordionComponent,
        CheckboxComponent,
        FormInputComponent,
        SvgIconComponent,
        NgIf,
        AgGridAngular,
        ConfirmationModalComponent,
        InputTextComponent,
        SelectMenuComponent
    ]
})
export class UpdateProfilePanelComponent implements OnInit, OnDestroy {
    @Input() data: User | undefined;
    private destroy$ = new Subject<void>();
    private subscriptions = new Subscription();
    private gridApi!: GridApi;

    userDetailsForm: FormGroup;
    resetPasswordForm: FormGroup;

    userRoles: UserRole[] = [];
    hubs: Hub[] = [];
    userRoleOptions: UserRole[] = [];
    initialFormValues: any;
    initialUserRoles: UserRole[] = [];
    initialDefaultUserRoleToHubMappingId: number | null = null;

    showClosingModal = false;
    user: User = new User();

    isUpdateDetailsAccordionOpen = true;
    isRolesAssignedAccordionOpen = true;
    isResetPasswordAccordionOpen = false;
    updated = false;

    rowData: any[] = [];

    columnDefs: ColDef[] = [
        { headerName: 'Role', field: 'roleName', flex: 1 },
        { headerName: 'Depot/Hub Name', field: 'depotHubName', flex: 1 },
        {
            headerName: 'Mark as Default',
            field: 'default',
            cellRenderer: (params: { value: boolean; node: any; }) => {
                const input = document.createElement('input');
                input.type = 'checkbox';
                input.checked = params.value;
                input.addEventListener('click', (event) => {
                    event.stopPropagation();
                    this.onDefaultCheckboxChange(params.node, input.checked);
                });
                return input;
            },
            cellClass: 'ag-center-cell'
        }
    ];

    nameErrors: Record<string, string> = {
        required: "First Name is required",
        maxlength: "Max length of First Name is 50 characters",
        alphanumeric: "First Name must be alphanumeric"
    };

    surnameErrors: Record<string, string> = {
        required: "Surname is required",
        maxlength: "Max length of Surname is 50 characters",
        alphanumeric: "Surname must be alphanumeric"
    };

    passwordErrors: Record<string, string> = {
        required: "Password is required",
        minlength: "Password must be at least 8 characters long",
        pattern: "Password must include uppercase letters, numbers, and special characters",
        notMatching: "New Password and Confirm Password do not match"
    };

    validateContactNumber: ValidatorFn = (
        control: AbstractControl
    ): ValidationErrors | null => {
        const value = control.value;
        if (
            value &&
            (value.length < 10 || value.length > 15 || !/^\+?\d+$/.test(value))
        ) {
            return { invalidContactNumber: true };
        }
        return null;
    };

    confirmPasswordValidator: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
        const newPassword = group.get('newPassword')?.value;
        const confirmPassword = group.get('confirmPassword')?.value;
        const confirmPasswordControl = group.get('confirmPassword');
        if (newPassword !== confirmPassword) {
            confirmPasswordControl?.setErrors({ notMatching: true });
            return { notMatching: true };
        } else {
            const errors = confirmPasswordControl?.errors;
            if (errors) {
                delete errors['notMatching'];
                if (!Object.keys(errors).length) {
                    confirmPasswordControl?.setErrors(null);
                } else {
                    confirmPasswordControl?.setErrors(errors);
                }
            }
            return null;
        }
    };

    passwordGroupValidator: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
        const currentPassword = group.get('currentPassword')?.value;
        const newPassword = group.get('newPassword')?.value;
        const confirmPassword = group.get('confirmPassword')?.value;

        if (!currentPassword && !newPassword && !confirmPassword) {
            return null;
        }
    
        const errors: ValidationErrors = {};
    
        if (!currentPassword) {
            group.get('currentPassword')?.setErrors({ required: true });
            errors['currentPassword'] = { required: true };
        }
        if (!newPassword) {
            group.get('newPassword')?.setErrors({ required: true });
            errors['newPassword'] = { required: true };
        } else if (!/^((?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])).{8,}$/.test(newPassword)) {
            group.get('newPassword')?.setErrors({ pattern: true });
            errors['newPassword'] = { pattern: true };
        }
        if (!confirmPassword) {
            group.get('confirmPassword')?.setErrors({ required: true });
            errors['confirmPassword'] = { required: true };
        }
    
        if (newPassword && confirmPassword && newPassword !== confirmPassword) {
            group.get('confirmPassword')?.setErrors({ notMatching: true });
            errors['confirmPassword'] = { notMatching: true };
        }

        if (newPassword === confirmPassword) {
            const confirmPasswordErrors = group.get('confirmPassword')?.errors;
            if (confirmPasswordErrors) {
                delete confirmPasswordErrors['notMatching'];
                if (Object.keys(confirmPasswordErrors).length === 0) {
                    group.get('confirmPassword')?.setErrors(null);
                } else {
                    group.get('confirmPassword')?.setErrors(confirmPasswordErrors);
                }
            }
        }
    
        return Object.keys(errors).length ? errors : null;
    };
    currentDefaultMapping: any;

    constructor(
        private userService: UserService,
        private userRoleService: UserRoleService,
        private hubService: HubService,
        private toastService: ToastrService,
        private slidingService: SlidingPanelService,
        private auth: AuthService,
        private modalService: ModalService,
        private oAuthService: Auth0AuthService
    ) {
        this.userDetailsForm = new FormGroup({
            firstName: new FormControl('', Validators.required),
            surname: new FormControl('', Validators.required),
            emailAddress: new FormControl('', [Validators.required, Validators.email]),
            contactNumber: new FormControl('', [this.validateContactNumber]),
        });

        this.resetPasswordForm = new FormGroup({
            currentPassword: new FormControl(''),
            newPassword: new FormControl(''),
            confirmPassword: new FormControl(''),
        }, { validators: this.passwordGroupValidator });
    }

    ngOnInit() {
        this.subscriptions.add(
            this.hubService
                .getHubs()
                .pipe(takeUntil(this.destroy$))
                .subscribe((data: Hub[]) => {
                    this.hubs = data;
                    if (this.data) {
                        this.prePopulateForm(this.data);
                    }
                })
        );

        this.subscriptions.add(
            this.userRoleService
                .getUserRoles()
                .pipe(takeUntil(this.destroy$))
                .subscribe((data: UserRole[]) => {
                    this.userRoleOptions = data;
                })
        );

        this.slidingService.closeRequestListener()
            .pipe(takeUntil(this.destroy$))
            .subscribe(() => this.cancel());

        this.slidingService.onOutsideClick()
            .pipe(
                skip(1),
                takeUntil(this.destroy$)
            )
            .subscribe(() => this.cancel());
    }

    prePopulateForm(user: User) {
        this.user = user;
        this.userDetailsForm.patchValue({
            firstName: user.firstName,
            surname: user.surname,
            emailAddress: user.email,
            contactNumber: user.contactNumber,
            status: user.isObsolete ? 'inactive' : 'active'
        });

        this.userDetailsForm.markAsPristine();

        this.initialFormValues = this.userDetailsForm.value;

        this.userRoleService.getUserRoleToHubMappingForUser(user.id!).subscribe((mappings: UserRoleToHubMapping[]) => {
            mappings.forEach((mapping) => {
                const userRole = this.userRoleOptions.find(role => role.id === mapping.userRoleId);
                const hub = this.hubs.find(hub => hub.id === mapping.hubId);

                if (userRole && hub) {
                    this.userRoles.push({
                        id: mapping.id,
                        name: userRole.name,
                        depotHubId: hub.id,
                        depotHubName: hub.name,
                        default: mapping.default
                    });

                    if (mapping.default) {
                        this.initialDefaultUserRoleToHubMappingId = mapping.id!;
                    }
                }
            });
            this.initialUserRoles = [...this.userRoles];
            this.updateGridData();
        });
    }

    updateGridData() {
        this.rowData = this.userRoles.map((role) => ({
            'id': role.id,
            'roleName': role.name,
            'depotHubName': role.depotHubName,
            'default': role.default
        }));
    }

    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }

    getFormControl(name: string): FormControl {
        return this.userDetailsForm.get(name) as FormControl;
    }

    getPasswordFormControl(name: string): FormControl {
        return this.resetPasswordForm.get(name) as FormControl;
    }

    cancel() {
        if (this.userDetailsForm.dirty || this.resetPasswordForm.dirty) {
            this.showClosingModal = true
            this.modalService.openModal({
                message: 'You have unsaved changes in the screen. Do you wish to continue without saving?',
                confirmText: 'Yes',
                cancelText: 'No',
                show: true,
                onConfirm: () => this.slidingService.close(),
                onCancel: () => { this.showClosingModal = false },
            });
        } else {
            this.slidingService.close()
        }
    }

    undo() {
        this.userDetailsForm.reset(this.initialFormValues);
        this.resetPasswordForm.reset({
            currentPassword: '',
            newPassword: '',
            confirmPassword: ''
        });
    }

    async saveDetails() {
        this.updated = false;
        if (this.isFormUnchanged() && !this.resetPasswordForm.dirty) {
            this.slidingService.close();
            return;
        }

        if (this.userDetailsForm.dirty && this.userDetailsForm.invalid) {
            this.toastService.error('Please fill in all required user detail fields correctly.');
            return;
        }

        if (this.resetPasswordForm.dirty && this.resetPasswordForm.invalid) {
            this.toastService.error('Please fill in all required password fields correctly.');
            return;
        }

        const user: User = {
            id: this.data!.id,
            username: this.user.username,
            surname: this.user.surname,
            email: this.user.email,
            contactNumber: this.userDetailsForm.get('contactNumber')!.value!,
            isObsolete: this.user.isObsolete,
            auth0Id: this.user.auth0Id,
            firstName: this.user.firstName,
        };

        try {
            if (!this.isFormUnchanged()) {
                this.updated = true;
                await lastValueFrom(this.userService.editUser(user));
            }

            this.currentDefaultMapping = this.rowData.find((row) => row.default);
            if (this.currentDefaultMapping && this.currentDefaultMapping.id !== this.initialDefaultUserRoleToHubMappingId) {
                this.updated = true;
                await lastValueFrom(this.userRoleService.setDefaultUserRoleToHubMapping({
                    userId: this.data!.id!,
                    userRoleToHubMappingId: this.currentDefaultMapping.id
                }));
            }

            if (this.resetPasswordForm.dirty) {
                await this.savePassword(this.resetPasswordForm.value.currentPassword, this.resetPasswordForm.value.newPassword);
            } else {
                this.slidingService.close();
            }

            if (this.updated) {
                this.toastService.success('Changes successfully saved');
                this.initialFormValues = this.userDetailsForm.value;
                if (this.currentDefaultMapping) {
                    this.initialDefaultUserRoleToHubMappingId = this.currentDefaultMapping.id;
                }
                this.userDetailsForm.markAsPristine();
            }
        } catch (error) {
            this.toastService.error('An error occurred while saving the user');
        }
    }

    async savePassword(currentPassword: string, newPassword: string) {
        if (!this.isResetPasswordAccordionOpen) return;
        if (!this.resetPasswordForm.dirty) return;

        const userId = this.data?.auth0Id;
        const email = this.data?.email;

        if (userId && email) {
            try {
                await lastValueFrom(this.auth.changePassword(userId, email, currentPassword, newPassword));
                this.toastService.success('Password updated successfully');
                this.slidingService.close();
                this.oAuthService.logout({ logoutParams: { returnTo: environment.auth0Config.logoutUrl } });
            } catch (error) {
                this.toastService.error('Failed to update password.');
            }
        }
    }

    toggleUpdateDetailsAccordion() {
        this.isUpdateDetailsAccordionOpen = !this.isUpdateDetailsAccordionOpen;
    }

    toggleRolesAssignedAccordion() {
        this.isRolesAssignedAccordionOpen = !this.isRolesAssignedAccordionOpen;
    }

    toggleResetPasswordAccordion() {
        this.isResetPasswordAccordionOpen = !this.isResetPasswordAccordionOpen;
    }

    onDefaultCheckboxChange(node: { data: { default: any; id: number; }; }, checked: boolean) {
        this.rowData.forEach((row) => {
            if (row.id === node.data.id) {
                row.default = checked;
            } else {
                row.default = false;
            }
        });
        this.refreshGridData();
    }

    onGridReady(params: GridReadyEvent) {
        this.gridApi = params.api;
    }

    refreshGridData() {
        if (this.gridApi) {
            this.gridApi.applyTransaction({ update: this.rowData });
        }
    }

    handleConfirm() {
        this.modalService.closeModal();
    }

    handleCancel() {
        this.modalService.closeModal();
    }

    isFormUnchanged(): boolean {
        return (JSON.stringify(this.userDetailsForm.value) === JSON.stringify(this.initialFormValues) && (this.currentDefaultMapping && this.currentDefaultMapping.id !== this.initialDefaultUserRoleToHubMappingId));
    }
}
