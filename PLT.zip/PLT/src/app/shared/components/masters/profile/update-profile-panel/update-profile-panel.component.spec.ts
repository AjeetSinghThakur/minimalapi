import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { SlidingPanelService } from 'src/app/shared/services/sliding-panel.service';
import { UserService } from 'src/app/services/user.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { AuthService } from '@auth0/auth0-angular';
import { ModalService } from 'src/app/shared/services/modal.service';
import { EMPTY, of, skip } from 'rxjs';
import { UpdateProfilePanelComponent } from './update-profile-panel.component';
import { HubService } from '../../hub/hub.service';
import { AccessControlService } from 'src/app/services/access-control.service';

describe('UpdateProfilePanelComponent', () => {
  let component: UpdateProfilePanelComponent;
  let fixture: ComponentFixture<UpdateProfilePanelComponent>;
  let toastrService: jasmine.SpyObj<ToastrService>;
  let slidingPanelService: jasmine.SpyObj<SlidingPanelService>;
  let userService: jasmine.SpyObj<UserService>;
  let userRoleService: jasmine.SpyObj<UserRoleService>;
  let hubService: jasmine.SpyObj<HubService>;
  let authService: jasmine.SpyObj<AuthService>;
  let modalService: jasmine.SpyObj<ModalService>;
  let accessControlService: AccessControlService;

  beforeEach(async () => {
    toastrService = jasmine.createSpyObj('ToastrService', ['success', 'error', 'info']);
    slidingPanelService = jasmine.createSpyObj('SlidingPanelService', ['close', 'closeRequestListener', 'onOutsideClick']);
    userService = jasmine.createSpyObj('UserService', ['editUser']);
    userRoleService = jasmine.createSpyObj('UserRoleService', ['getUserRoles', 'getUserRoleToHubMappingForUser', 'setDefaultUserRoleToHubMapping']);
    hubService = jasmine.createSpyObj('HubService', ['getHubs']);
    authService = jasmine.createSpyObj('AuthService', ['changePassword']);
    modalService = jasmine.createSpyObj('ModalService', ['openModal', 'closeModal']);

    slidingPanelService.closeRequestListener.and.returnValue(EMPTY);
    slidingPanelService.onOutsideClick.and.returnValue(EMPTY);
    userRoleService.getUserRoles.and.returnValue(of([]));
    hubService.getHubs.and.returnValue(of([]));

    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule, 
        HttpClientModule,
        UpdateProfilePanelComponent
      ],
      providers: [
        { provide: ToastrService, useValue: toastrService },
        { provide: SlidingPanelService, useValue: slidingPanelService },
        { provide: UserService, useValue: userService },
        { provide: UserRoleService, useValue: userRoleService },
        { provide: HubService, useValue: hubService },
        { provide: AuthService, useValue: authService },
        { provide: ModalService, useValue: modalService },
        AccessControlService,
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(UpdateProfilePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialise userDetailsForm and resetPasswordForm with default values', () => {
    expect(component.userDetailsForm).toBeDefined();
    expect(component.resetPasswordForm).toBeDefined();
  });

  it('should populate the form with user data on prePopulateForm call', () => {
    const user = { id: 1, firstName: 'John', surname: 'Doe', email: 'john.doe@example.com', contactNumber: '+1234567890', isObsolete: false };
    component.data = user;
    spyOn(component, 'updateGridData').and.callThrough();
    userRoleService.getUserRoleToHubMappingForUser.and.returnValue(of([]));

    component.prePopulateForm(user);

    expect(component.userDetailsForm.get('firstName')!.value).toEqual('John');
    expect(component.userDetailsForm.get('surname')!.value).toEqual('Doe');
    expect(component.userDetailsForm.get('emailAddress')!.value).toEqual('john.doe@example.com');
    expect(component.userDetailsForm.get('contactNumber')!.value).toEqual('+1234567890');
    expect(component.updateGridData).toHaveBeenCalled();
  });

  it('should reset forms on undo call', () => {
    component.userDetailsForm.get('firstName')!.setValue('Jane');
    component.resetPasswordForm.get('newPassword')!.setValue('NewPassword123!');
    component.initialFormValues = { firstName: 'John', surname: 'Doe', emailAddress: 'john.doe@example.com', contactNumber: '+1234567890' };

    component.undo();

    expect(component.userDetailsForm.get('firstName')!.value).toEqual('John');
    expect(component.resetPasswordForm.get('newPassword')!.value).toEqual('');
    expect(toastrService.info).toHaveBeenCalledWith('Changes have been undone.');
  });

  it('should display an error message when saving details with invalid form', () => {
    component.userDetailsForm.get('firstName')!.setValue('');

    component.saveDetails();

    expect(toastrService.error).toHaveBeenCalledWith('Please fill in all required fields correctly.');
  });

  it('should handle outside click properly', () => {
    component.ngOnInit();
    slidingPanelService.onOutsideClick().pipe(skip(1)).subscribe(() => {
      expect(component.cancel).toHaveBeenCalled();
    });
  });

  it('should toggle accordions properly', () => {
    component.isUpdateDetailsAccordionOpen = true;
    component.toggleUpdateDetailsAccordion();
    expect(component.isUpdateDetailsAccordionOpen).toBeFalse();

    component.isRolesAssignedAccordionOpen = true;
    component.toggleRolesAssignedAccordion();
    expect(component.isRolesAssignedAccordionOpen).toBeFalse();

    component.isResetPasswordAccordionOpen = true;
    component.toggleResetPasswordAccordion();
    expect(component.isResetPasswordAccordionOpen).toBeFalse();
  });

  it('should update the grid data correctly', () => {
    component.userRoles = [{ id: 1, name: 'Admin', depotHubId: 1, depotHubName: 'Hub1', default: false }];
    component.updateGridData();
    expect(component.rowData).toEqual([{ id: 1, roleName: 'Admin', depotHubName: 'Hub1', default: false }]);
  });
});
