import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgIf } from '@angular/common';
import { SvgIconComponent } from '../../svg-icon/svg-icon.component';
import { SelectMenuComponent } from '../../select-menu/select-menu.component';
import { CheckboxComponent } from '../../checkbox/checkbox.component';
import { ModalService } from 'src/app/shared/services/modal.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { ToastrService } from 'ngx-toastr';
import { HubService } from '../hub/hub.service';
import { Hub } from '../hub/hub.model';
import { UserRole } from 'src/app/models/user-role';
import { UserRoleToHubMapping } from 'src/app/models/user-role-to-hub-mapping';
import { UserService } from 'src/app/services/user.service';
import { AccessControlService } from 'src/app/services/access-control.service';
import { Subject, lastValueFrom, takeUntil } from 'rxjs';

@Component({
  selector: 'dhms-change-role-modal',
  templateUrl: './change-role-modal.component.html',
  styleUrls: ['./change-role-modal.component.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SvgIconComponent, NgIf, SelectMenuComponent, CheckboxComponent]
})
export class ChangeRoleModalComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private onConfirm: (() => void) | undefined;
  private onCancel: (() => void) | undefined;

  userRoles: UserRole[] = [];
  userRoleOptions: UserRole[] = [];
  depotHubs: Hub[] = [];
  depotHubsOptions: Hub[] = [];
  assignedRoles: UserRoleToHubMapping[] = [];
  iconPath?: string;
  userId: number | undefined;

  roleForm = new FormGroup({
    userRole: new FormControl<number | null>({ value: null, disabled: true }, Validators.required),
    depotHub: new FormControl<number | null>({ value: null, disabled: true }, Validators.required),
    defaultRole: new FormControl<boolean | null>({ value: false, disabled: true }),
  });

  constructor(
    private modalService: ModalService,
    private userRoleService: UserRoleService,
    private hubService: HubService,
    private toastService: ToastrService,
    private userService: UserService,
    private accessControlService: AccessControlService
  ) {}

  async ngOnInit(): Promise<void> {
    await this.fetchUserRoles();

    this.modalService.showModal$.subscribe(config => {
      if (config.show) {
        this.onConfirm = config.onConfirm;
        this.onCancel = config.onCancel;
      }
    });

    this.roleForm.controls['userRole'].valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(selectedUserRoleId => {
        this.updateDepotHubOptions(selectedUserRoleId);
      });
  }

  async fetchUserRoles() {
    this.userRoleService.getUserRoles().subscribe({
      next: (roles: UserRole[]) => {
        this.userRoles = roles;
        this.fetchDepotHubs();
      },
      error: () => {
        this.toastService.error('Failed to load user roles');
      }
    });
  }

  async fetchDepotHubs() {
    this.hubService.getHubs().subscribe({
      next: (hubs: Hub[]) => {
        this.depotHubs = hubs;
        this.userService.loggedInUser$
          .pipe(takeUntil(this.destroy$))
          .subscribe(async user => {
            if (user) {
              this.userId = user.id;
              this.fetchAssignedRoles();
            }
          });
      },
      error: () => {
        this.toastService.error('Failed to load depot hubs');
      }
    });
  }

  fetchAssignedRoles() {
    if (this.userId) {
      this.userRoleService.getUserRoleToHubMappingForUser(this.userId).subscribe({
        next: (assignedRoles: UserRoleToHubMapping[]) => {
          this.assignedRoles = assignedRoles;
          this.prefillForm();
        },
        error: () => {
          this.toastService.error('Failed to load assigned roles');
        }
      });
    }
  }

  prefillForm() {
    const selectedRoleMapping = this.accessControlService.getSelectedUserRoleMapping();
    if (selectedRoleMapping) {
      const assignedRoleIds = this.assignedRoles.map(role => role.userRoleId);
      this.userRoleOptions = this.userRoles.filter(role => assignedRoleIds.includes(role.id));
      this.updateDepotHubOptions(selectedRoleMapping.userRoleId!);

      this.roleForm.setValue({
        userRole: selectedRoleMapping.userRoleId!,
        depotHub: selectedRoleMapping.hubId!,
        defaultRole: selectedRoleMapping.default || false
      });

      // Enable the form controls after prefill
      this.roleForm.controls['userRole'].enable();
      this.roleForm.controls['depotHub'].enable();
      this.roleForm.controls['defaultRole'].enable();
    }
  }

  updateDepotHubOptions(selectedUserRoleId: number | null) {
    if (selectedUserRoleId) {
      const assignedHubsForRole = this.assignedRoles
        .filter(role => role.userRoleId === +selectedUserRoleId)
        .map(role => role.hubId);

      this.depotHubsOptions = this.depotHubs.filter(hub => assignedHubsForRole.includes(hub.id));

      if (this.depotHubsOptions.length > 0) {
        this.roleForm.controls['depotHub'].setValue(this.depotHubsOptions[0].id);
      } else {
        this.roleForm.controls['depotHub'].setValue(null);
      }
    } else {
      this.depotHubsOptions = [];
    }
  }

  updateAccessControls(selectedUserRoleId: number | null) {
    const selectedHubId = this.roleForm.controls['depotHub'].value;
    if (selectedUserRoleId && selectedHubId) {
      this.accessControlService.setSelectedUserRole(+selectedUserRoleId, +selectedHubId);
    }
  }

  async handleUpdate() {
    if (!this.userId) return;
    const { userRole, depotHub, defaultRole } = this.roleForm.value;
    const selectedRole = this.assignedRoles.find(role => role.userRoleId === +userRole! && role.hubId === +depotHub!);
    
    if (!selectedRole) {
      this.toastService.error('Selected role and hub combination is not valid.');
      return;
    }
      
    if (defaultRole) {
      try {
        await lastValueFrom(this.userRoleService.setDefaultUserRoleToHubMapping({
          userId: this.userId,
          userRoleToHubMappingId: selectedRole.id!
        }));
        this.toastService.success('Default role updated successfully.');
      } catch (error) {
        this.toastService.error('Failed to update default role.');
        console.error(error);
        return;
      }
    }
    this.updateAccessControls(selectedRole.userRoleId!);
  
    if (this.onConfirm) {
      this.onConfirm();
    }
  }
  
  handleCancel() {
    if (this.onCancel) {
      this.onCancel();
    }
    this.modalService.closeModal();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
