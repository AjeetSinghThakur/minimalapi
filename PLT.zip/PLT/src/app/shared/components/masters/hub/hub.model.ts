import {HubSection} from "./hub-section.model";

export class Hub {
    id!: number;
    name!: string;
    description!: string;
    earlyVariance!: number;
    lateVariance!: number;
    aliasName!: string;
    isObsolete!: boolean;
    isLateTrunkFeeEnabled!: boolean;
    isDirectTrunkHub!: boolean;
    fltScanning!: boolean;
    isVirtualHub!: boolean;
    isFLTEnabled!: boolean;
    createdDate!: string;
    updatedDate!: string;
    hubSections!: HubSection[];
}
