import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HubService } from './hub.service';
import { Hub } from './hub.model';

describe('HubService', () => {
  let service: HubService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [HubService]
    });
    service = TestBed.inject(HubService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify(); 
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getHubs', () => {
    it('should make a GET request to fetch hubs', () => {
      const mockHubs: Array<Hub> = [{
        id: 1, name: 'Hub 1', description: 'Hub 1', earlyVariance: 5,
        lateVariance: 15, aliasName: 'Hub 1', isObsolete: false, isLateTrunkFeeEnabled: false,
        isDirectTrunkHub: false, fltScanning: false, isVirtualHub: false, isFLTEnabled: false,
        createdDate: '',
        updatedDate: '',
        hubSections: []
      }
      , {
        id: 2, name: 'Hub 2', description: 'Hub 2', earlyVariance: 5,
        lateVariance: 15, aliasName: 'Hub 2', isObsolete: false, isLateTrunkFeeEnabled: false,
        isDirectTrunkHub: false, fltScanning: false, isVirtualHub: false, isFLTEnabled: false,
        createdDate: '',
        updatedDate: '',
        hubSections: []
      }];

      service.getHubs().subscribe(hubs => {
        expect(hubs).toEqual(mockHubs);
      });

      const req = httpTestingController.expectOne(`${service.apiUrl}/Hub`);
      expect(req.request.method).toEqual('GET');
      req.flush(mockHubs);
    });
  });

  describe('setHubActiveOrInactive', () => {
    it('should make a PATCH request to toggle the active state of a hub', () => {
      const hubId = 1;
      const mockResponse = { id: hubId, active: false }; 

      service.setHubActiveOrInactive(hubId).subscribe(response => {
        expect(response).toEqual(mockResponse);
      });

      const req = httpTestingController.expectOne(`${service.apiUrl}/Hub/${hubId}/toggle-active`);
      expect(req.request.method).toEqual('PATCH');
      req.flush(mockResponse);
    });
  });
});
