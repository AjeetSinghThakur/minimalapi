import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { SvgIconComponent } from '../../svg-icon/svg-icon.component';
import { GridColumnConfig, GridComponent } from "../../grid/grid.component";
import { ActiveItemService } from 'src/app/services/active-item.service';
import { CommonModule } from '@angular/common';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ConfirmationModalComponent } from './confirmation-modal/confirmation-modal.component';
import { HubService } from './hub.service';
import { Hub } from './hub.model';
import { Subject, Subscription, of, switchMap, takeUntil} from 'rxjs';
import { ToastrServiceWrapper } from 'src/app/services/toastr-wrapper.service';
import { SlidingPanelService} from "../../../services/sliding-panel.service";
import {WriteHubComponent} from "./add-hub/write-hub.component";
import {SlidingPanelComponent} from "../../sliding-panel/sliding-panel.component";
import {AddHubSectionModalComponent} from "./add-hub/add-hub-section-modal/add-hub-section-modal.component";
import {GridService} from "../../../services/grid.service";
import {GridSearchBarComponent} from "../../grid-search-bar/grid-search-bar.component";
import { AccessControlService } from 'src/app/services/access-control.service';

@Component({
    selector: 'dhms-hub',
    standalone: true,
    templateUrl: './hub.component.html',
    styleUrl: './hub.component.scss',
  imports: [SvgIconComponent, GridComponent, CommonModule, ConfirmationModalComponent, SlidingPanelComponent, AddHubSectionModalComponent, GridSearchBarComponent],
    providers: [ToastrServiceWrapper]
})

export class HubComponent implements OnInit, OnDestroy {
  @ViewChild(GridComponent) private gridComponent!: GridComponent;
  activeItem: string = 'Hub Listing';
  data: Array<Hub> = [];
  isSidebarCollapsed: boolean = false;
  isSidePanelCollapsed = true
  showCloseModal = false
  auditHubData: Array<any> = [];
  actionEventData: any;
  auditTitle: string = 'Hub Audit';
  mode: string = '';

  private subscriptions = new Subscription();
  private destroy$ = new Subject<void>();

  gridConfig: GridColumnConfig[] = [
    { headerName: 'Name', field: 'name', checkboxSelection: false },
    { headerName: 'Description', field: 'description', suppressHeaderMenuButton: true },
    { headerName: 'Gatehouse Early Variance', field: 'earlyVariance', suppressHeaderMenuButton: true },
    { headerName: 'Gatehouse Late Variance', field: 'lateVariance', suppressHeaderMenuButton: true },
    { headerName: 'Is late trunk fee enabled', field: 'isLateTrunkFeeEnabled', useRenderer: 'boolean', suppressHeaderMenuButton: true },
    { headerName: 'Is Virtual Hub', field: 'isVirtualHub', useRenderer: 'boolean', suppressHeaderMenuButton: true },
    { headerName: 'Is Direct Trunk', field: 'isDirectTrunkHub', useRenderer: 'boolean', suppressHeaderMenuButton: true },
    { headerName: 'FLT Scanning', field: 'fltScanning', useRenderer: 'boolean', suppressHeaderMenuButton: true },
    { headerName: 'FLT Enabled', field: 'isFLTEnabled', useRenderer: 'boolean', suppressHeaderMenuButton: true },
    { headerName: 'Alias', field: 'aliasName', suppressHeaderMenuButton: true },
    { headerName: 'Status', field: 'isObsolete', useRenderer: 'status', suppressHeaderMenuButton: true, pinned: 'right' },
    {
      headerName: 'Actions',
      field: 'actions',
      useRenderer: 'action',
      suppressHeaderMenuButton: true,
      pinned: 'right',
    },
  ];

  constructor(private activeItemService: ActiveItemService,
              private hubService: HubService,
              public modalService: ModalService,
              private toastr: ToastrServiceWrapper,
              private slidingPanelService: SlidingPanelService,
              private gridService: GridService,
              public accessControlService: AccessControlService) {}

  setActiveItem(itemName: string) {
    this.activeItem = itemName;
    this.activeItemService.setHeaderTitle(itemName);
  }

  ngOnInit(): void {
    this.subscriptions.add(
      this.activeItemService.isSidebarCollapsed$.subscribe(isCollapsed => {
        this.isSidebarCollapsed = isCollapsed;
      })
    );
    this.activeItemService.setActiveSubItem("Manage Hub");
    this.setActiveItem(this.activeItem);
  
    this.subscriptions.add(
      this.accessControlService.accessControlsLoaded$.pipe(
        takeUntil(this.destroy$),
        switchMap(loaded => {
          if (loaded && this.accessControlService.hasAccess('Hub Listing')) {
            return this.hubService.getHubs();
          } else {
            return of([]);
          }
        })
      ).subscribe((data: Array<Hub>) => {
        this.data = data;
        this.data = this.sortHubs(data);
      })
    );
  
    this.subscriptions.add(
      this.hubService.refreshGrid().pipe(takeUntil(this.destroy$)).subscribe(() => {
        this.refreshGridDataWithDateSorting();
      })
    );
  
    this.accessControlService.loadUserAccessControls().subscribe();
  }
  
  private sortHubs(hubs: any[]): any[] {
    return hubs.sort((a, b) => {
      if (a.isObsolete === b.isObsolete) return 0;
      return a.isObsolete ? 1 : -1;
    });
  }

  private sortHubsByCreateDate(hubs: any[]): any[] {
    return hubs.sort((a, b) => {
      return <any>new Date(b.createdDate) - <any>new Date(a.createdDate);
    });
  }

  onAction(actionEvent: any) {
    switch (actionEvent.type) {
      case 'edit':
        if (this.accessControlService.hasAccess('Edit Hub')) {
          this.subscriptions.add(this.hubService.getHubAudit(actionEvent.data.id).pipe(takeUntil(this.destroy$)).subscribe((data: Array<any>) => {
            this.auditHubData = data;
          }));
          this.actionEventData = actionEvent.data;
          this.editHub(actionEvent.data);
        } else {
          this.toastr.error('You do not have permission to edit hubs.');
        }
        break;
      case 'delete':
        if (this.accessControlService.hasAccess('Activate or Deactivate Hub')) {
          this.showCloseModal = true;
          this.modalService.openModal({
            message: 'Are you sure you want to deactivate this Hub?',
            confirmText: 'Yes',
            cancelText: 'No',
            show: true,
            onConfirm: () => this.deactivateHub(actionEvent.data.id),
            onCancel: () => this.showCloseModal = false
          });
        } else {
          this.toastr.error('You do not have permission to deactivate hubs.');
        }
        break;
      case 'unarchive':
        if (this.accessControlService.hasAccess('Activate or Deactivate Hub')) {
          this.showCloseModal = true;
          this.modalService.openModal({
            message: 'Are you sure you want to reactivate this Hub?',
            confirmText: 'Yes',
            cancelText: 'No',
            show: true,
            onConfirm: () => this.reactivateHub(actionEvent.data.id),
            onCancel: () => this.showCloseModal = false
          });
        } else {
          this.toastr.error('You do not have permission to reactivate hubs.');
        }
        break;
    }
  }

  deactivateHub(id: number) {
    this.showCloseModal = false;
    this.hubService.setHubActiveOrInactive(id).subscribe(() => {
      this.refreshGridData();
      this.toastr.success('Hub deactivated successfully', '');
    });
  }

  reactivateHub(id: number) {
    this.showCloseModal = false;
    this.hubService.setHubActiveOrInactive(id).subscribe(() => {
      this.refreshGridData();
      this.toastr.success('Hub reactivated successfully', '');
    });
  }

  refreshGridData() {
    this.hubService.getHubs().subscribe((data: any[]) => {
      this.data = data;
      this.data = this.sortHubs(data);
      this.gridComponent.refreshGrid(this.data);
    });
  }

  refreshGridDataWithDateSorting() {
    this.hubService.getHubs().subscribe((data: any[]) => {
      this.data = data;
      this.data = this.sortHubsByCreateDate(data);
      this.gridComponent.refreshGrid(this.data);
    });
  }

  handleConfirm() {
    this.modalService.closeModal();
  }

  handleCancel() {
    this.modalService.closeModal();
  }

  previousEditHubView($event: any) {
    this.editHub($event);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }

  addHub() {
    if (this.accessControlService.hasAccess('Add Hub')) {
      this.isSidePanelCollapsed = false;
      this.slidingPanelService.setTitle("Add Hub");
      this.slidingPanelService.setContent(WriteHubComponent);
      this.slidingPanelService.show();
    } else {
      this.toastr.error('You do not have permission to add hubs.');
    }
  }

  editHub(params: any) {
    this.isSidePanelCollapsed = false;
    this.slidingPanelService.setTitle("Edit Hub");
    this.slidingPanelService.setContentWithDataChange({ content: WriteHubComponent, data: params });
    this.slidingPanelService.show();
  }
}
