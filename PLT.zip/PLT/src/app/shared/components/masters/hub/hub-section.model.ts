export class HubSection {
  id!: number;
  hubId!: number;
  number!: number;
  name!: string;
  isObsolete!: boolean;
  createdDate!: string;
  updatedDate!: string;
}
