import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteSectionButtonComponent } from './delete-section-button.component';

describe('DeleteSectionButtonComponent', () => {
  let component: DeleteSectionButtonComponent;
  let fixture: ComponentFixture<DeleteSectionButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteSectionButtonComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteSectionButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
