import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHubSectionModalComponent } from './add-hub-section-modal.component';

describe('AddHubSectionModalComponent', () => {
  let component: AddHubSectionModalComponent;
  let fixture: ComponentFixture<AddHubSectionModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddHubSectionModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddHubSectionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
