import { BehaviorSubject } from 'rxjs';
import { ConfirmationModalComponent } from './confirmation-modal.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalService } from 'src/app/shared/services/modal.service';

describe('ConfirmationModalComponent', () => {
  let component: ConfirmationModalComponent;
  let fixture: ComponentFixture<ConfirmationModalComponent>;
  let mockModalService: Partial<ModalService>; 

  beforeEach(async () => {
    mockModalService = {
      showModal$: new BehaviorSubject({
        message: 'Test Message',
        confirmText: 'Confirm',
        cancelText: 'Cancel',
        show: true,
        onConfirm: () => {},
        onCancel: () => {}
      })
    };

    await TestBed.configureTestingModule({
      declarations: [],
      imports: [ConfirmationModalComponent],
      providers: [{ provide: ModalService, useValue: mockModalService }]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConfirmationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('updates content based on ModalService', () => {
    const newConfig = {
      message: 'New Test Message',
      confirmText: 'New Confirm',
      cancelText: 'New Cancel',
      show: true,
      onConfirm: () => {},
      onCancel: () => {}
    };
  
    (mockModalService.showModal$ as BehaviorSubject<any>).next(newConfig);
  
    fixture.detectChanges();
  
    expect(component.message).toEqual(newConfig.message);
  });

  it('should update content dynamically based on ModalService changes', () => {
    let initialConfig = {
      message: 'Initial Message',
      confirmText: 'Initial Confirm',
      cancelText: 'Initial Cancel',
      show: true,
      onConfirm: () => console.log('Initial Confirm'),
      onCancel: () => console.log('Initial Cancel')
    };
  
    (mockModalService.showModal$ as BehaviorSubject<any>).next(initialConfig);
  
    fixture.detectChanges();
  
    expect(component.message).toEqual(initialConfig.message);
    expect(component.confirmText).toEqual(initialConfig.confirmText);
    expect(component.cancelText).toEqual(initialConfig.cancelText);
  
    let newConfig = {
      message: 'Updated Message',
      confirmText: 'Updated Confirm',
      cancelText: 'Updated Cancel',
      show: true,
      onConfirm: () => console.log('Updated Confirm'),
      onCancel: () => console.log('Updated Cancel')
    };
  
    (mockModalService.showModal$ as BehaviorSubject<any>).next(newConfig);
  
    fixture.detectChanges();
  
    expect(component.message).toEqual(newConfig.message);
    expect(component.confirmText).toEqual(newConfig.confirmText);
    expect(component.cancelText).toEqual(newConfig.cancelText);
  });
  
});
