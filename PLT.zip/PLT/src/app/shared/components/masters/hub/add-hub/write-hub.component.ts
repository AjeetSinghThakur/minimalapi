import {Component, Input, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { AgGridAngular } from '@ag-grid-community/angular';
import {ColDef, GridApi, GridOptions, ModuleRegistry, ValueParserParams} from '@ag-grid-community/core';
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import {SvgIconComponent} from "../../../svg-icon/svg-icon.component";
import {ToggleSwitchComponent} from "../../../toggle-switch/toggle-switch.component";
import {InputTextComponent} from "../../../input-text/input-text.component";
import {SelectMenuComponent} from "../../../select-menu/select-menu.component";
import {DatePickerComponent} from "../../../date-picker/date-picker.component";
import {HubService} from "../hub.service";
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators
} from "@angular/forms";
import {AsyncPipe, NgForOf, NgIf} from "@angular/common";
import {FormInputComponent} from "../../../form-input/form-input.component";
import {ToastrService} from "ngx-toastr";
import {Hub} from "../hub.model";
import {SlidingPanelService} from "../../../../services/sliding-panel.service";
import {ModalService} from "../../../../services/modal.service";
import {HttpErrorResponse} from "@angular/common/http";
import {FormInputService} from "../../../../services/form-input.service";
import {ResponseError} from "../../../../../models/response-error";
import {LessThanCheck} from "../../../../validators/less-than-check";
import {Subject} from "rxjs/internal/Subject";
import {skip, takeUntil} from "rxjs/operators";
import {HubSection} from "../hub-section.model";

import {alphanumericValidator} from "../../../../validators/alphanumeric-validator";
import {AddHubSectionModalComponent} from "./add-hub-section-modal/add-hub-section-modal.component";
import {ConfirmationModalComponent} from "../confirmation-modal/confirmation-modal.component";
import {
  DeleteSectionButtonComponent
} from "./add-hub-section-modal/delete-section-button/delete-section-button.component";


ModuleRegistry.registerModules([ClientSideRowModelModule]);

@Component({
  selector: 'dhms-slider',
  standalone: true,
  imports: [
    AgGridAngular,
    SvgIconComponent,
    ToggleSwitchComponent,
    InputTextComponent,
    SelectMenuComponent,
    DatePickerComponent,
    ReactiveFormsModule,
    NgIf,
    FormInputComponent,
    FormsModule,
    AddHubSectionModalComponent,
    AsyncPipe,
    ConfirmationModalComponent,
    NgForOf
  ],
  templateUrl: './write-hub.component.html',
  styleUrl: './write-hub.component.scss',
})

export class WriteHubComponent implements OnInit, OnDestroy {
  @ViewChild('myGrid') grid!: AgGridAngular;
  private gridApi!: GridApi;
  private destroy$ = new Subject<void>;

  nameId = "name"
  aliasId = "alias"
  descriptionId = "description"
  earlyVarianceId = "earlyVariance"
  lateVarianceId = "lateVariance"
  editingHub = false
  hubToEdit!: Hub
  hubSections: HubSection[] = []
  showClosingModal = false
  showSectionModal = false

  constructor(private hubService: HubService,
              private toastService: ToastrService,
              private slidingService: SlidingPanelService,
              private modalService: ModalService,
              private formInputService: FormInputService) {}
  @Input() data: any

  isDetailsAccordionOpen: boolean = false;
  isSettingsAccordionOpen: boolean = true;
  rowData: any[] = [];
  colDefs: ColDef[] = [
    { headerName: 'Number', field: 'Number' },
    { headerName: 'Name', field: 'Name', editable: true,
      valueGetter: (params) => params.data['Name'].value,
      valueSetter: (params) => this.sectionNameSetter(params),
      cellRenderer: this.nameCellRenderer.bind(this),
      tooltipValueGetter: (params) => {
        let isFieldValid = params.value.lastValidation === true;
        if (isFieldValid) return "";
        return params.data['Name'].lastValidationMessage},
      cellStyle: function(params) {
        if (!params.data['Name'].lastValidation) {
          return {'background-color': '#FEF2F2', 'border-color': '#C62828'};
        } else {
          return {'background-color': '', 'border-color': ''};
        }
      }
    },
    { headerName: 'Actions', field: 'Actions',cellRenderer: DeleteSectionButtonComponent,width:227 },
  ];

  private sectionNameValidator(name: string, number: number): string {
    if(name == '') {
      return "Name is required"
    } else if(name.length > 2) {
      return "Only 2 characters allowed"
    } else if(this.containsSpecialCharacters(name)){
      return "No special characters allowed"
    } else if(!this.uniqueSectionName(name, number)) {
      return "Name must be unique"
    }
    return ""
  }

  nameCellRenderer(params: any): string {
    let content = `<span style="flex-grow: 1; text-align: center;">${params.value}</span>`;
    if (!params.data['Name'].lastValidation) {
      content += `<img src="/assets/icons/alert-circle.svg" style="width: 16px; height: 16px; margin-left: 5px" />`;
    }
    return `<div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100%;">${content}</div>`;
  }

  private uniqueSectionName(name: string, number: number): boolean {
    let originalName =
      this.hubSections.filter(x => x.number == number && !x.isObsolete)[0].name
    if(name == originalName) {return true}
    return !(this.hubSections.filter(x => x.name == name && !x.isObsolete).length > 0)
  }

  private sectionNameSetter(params: ValueParserParams) {
    // If we want to stop section name validating occurring immediately we need to check at this point if the cell has been edited
    let validationMessage = this.sectionNameValidator(params.newValue, params.data.Number)
    if(validationMessage == '')
    {
      params.data['Name'].lastValidation = true
      params.data['Name'].value = params.newValue
      params.data['Name'].lastValidationMessage = ""
    } else {
      params.data['Name'].lastValidation = false
      params.data['Name'].value = params.newValue
      params.data['Name'].lastValidationMessage = validationMessage
    }
    return true
  }

  private containsSpecialCharacters(str: string): boolean {
    const regex: RegExp = /[!@#£$%^&*()\-+={}[\]:;"'<>,.?\/|\\]/;
    return regex.test(str);
  }

  handleConfirm(){
    this.modalService.closeModal();
  }

  handleCancel(){
    this.modalService.closeModal();
  }

  addHubForm = new FormGroup({
      name: new FormControl('', {
        validators: [Validators.required, Validators.maxLength(50), alphanumericValidator()],

      }),
      alias: new FormControl('', {
        validators: [Validators.maxLength(50), alphanumericValidator()],

      }),
      description: new FormControl('', {
        validators: [Validators.required, Validators.maxLength(50), alphanumericValidator()],

      }),
      earlyVariance: new FormControl('', {
        validators: [Validators.required, Validators.min(0), Validators.max(1440)],

      }),
      lateVariance: new FormControl('', {
        validators: [Validators.required, Validators.min(0), Validators.max(1440)],

      }),
      isVirtual: new FormControl(false),
      isDirect: new FormControl(false),
      fltScanning: new FormControl(false),
      fltEnabled: new FormControl(false),
      lateTrunk: new FormControl(false),
      isObsolete: new FormControl(false)
    },
    {
      validators: LessThanCheck(this.earlyVarianceId, this.lateVarianceId)
    }
  )

  nameErrors: Record<string, string> = {
    required: `Name is required`,
    maxlength: `Max length of Name is 50 characters`,
    alphanumeric: `No special characters allowed`
  }

  aliasErrors: Record<string, string> = {
    maxlength: `Max length of Alias is 50 characters`,
    alphanumeric: `No special characters allowed`
  }

  descriptionErrors: Record<string, string> = {
    required: `Description is required`,
    maxlength: `Max length of Description is 50 characters`,
    alphanumeric: `No special characters allowed`
  }

  earlyVarianceErrors: Record<string, string> = {
    required: `Gatehouse early variance cannot be empty`,
    max:  `Maximum variance is 1440`,
    min: `Minimum variance is 0`,
    invalidValue: `Early variance must not be equal to or exceed late variance`,
  }

  lateVarianceErrors: Record<string, string> = {
    required: `Gatehouse late variance cannot be empty`,
    max:  `Maximum variance is 1440`,
    min: `Minimum variance is 0`,
  }

  ngOnInit() {
    if(this.data != null) {
      //Edit mode
      this.editingHub = true
      this.prePopulateForm(this.data)
      this.hubToEdit = JSON.parse(JSON.stringify(this.data));
      this.addHubForm.controls.name.disable()
      this.hubSections = this.hubToEdit.hubSections
    }

    this.addHubForm.controls.lateVariance.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.addHubForm.controls.earlyVariance.updateValueAndValidity()
      })

    this.slidingService.closeRequestListener()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.cancel()
      })

    if(this.editingHub) {
      this.slidingService.onOutsideClick()
        .pipe(takeUntil(this.destroy$))
        .subscribe(res => {
          this.closeDialogueCheck()
        })
    } else {
      this.slidingService.onOutsideClick()
        .pipe(takeUntil(this.destroy$), skip(1))
        .subscribe(res => {
          this.closeDialogueCheck()
        })
    }
  }

  private closeDialogueCheck() {
    if(!this.showSectionModal)
    {
      this.cancel()
    }
  }

  updateHubSections(sections: HubSection[]) {
    this.hubSections = sections
    this.createRowData()
    this.showSectionModal = false
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  gridOptions: GridOptions = {
    onRowDataUpdated: function(){ }
  }

  sectionNameChanged(event: any) {
    if(event.colDef.field === 'Name') {
      let index = this.hubSections.findIndex(i => i.number == event.data.Number)
      this.hubSections[index].name = event.data.Name.value
    }
  }

  deactivateSectionModal(event: any) {
    if (event.colDef.field === 'Actions') {
      if(this.editingHub)
      {
        this.showClosingModal = true
        this.modalService.openModal({
          message: 'Are you sure you want to deactivate ' + event.data.Name.value + '?',
          confirmText: 'Yes',
          cancelText: 'No',
          show: true,
          onConfirm: () => {
            this.showClosingModal = false
            this.deactivateHubSection(event.data.Number)
          },
          onCancel: () => {
            this.showClosingModal = false
          }
        })
      } else {
        this.deactivateHubSection(event.data.Number)
      }
    }
  }

  private deactivateHubSection(sectionNumber: number) {
    // Delete the selected section
    let selectedSection = this.hubSections.find(section =>
      section.number === sectionNumber && !section.isObsolete)!
    if(selectedSection.id > 0)
    {
      //If it has an ID then it has already been created and needs to be set to obsolete
      selectedSection.isObsolete = true
    } else {
      // Else it isn't on the database and therefor can be yeeted
      this.hubSections = this.hubSections.filter(i => i.number !== sectionNumber)
    }

    let key = 0
    // Renumber the remaining sections
    let activeSections = this.hubSections.filter(x => !x.isObsolete)
      for (let i = 1; i <= activeSections.length; i++) {
        if(!activeSections[key].isObsolete)
        {
          activeSections[key].number = i
          key++
        }
      }
      this.createRowData()
  }

  private prePopulateForm(hub: Hub) {
    this.setSectionsTable(hub)
    this.setFormInputs(hub)
    this.setToggleSwitches(hub)
  }

  private setSectionsTable(hub: Hub) {
    this.rowData = []
    if (Array.isArray(hub.hubSections) && hub.hubSections.length > 0) {
      hub.hubSections.forEach(item => {
        if(!item.isObsolete) {
          this.rowData.push({'Number': item.number,
            Name: {value: item.name, lastValidation: true, lastValidationMessage: 'Name is required'},
            'Actions': 'No'
          })
        }
      });
    }
  }

  private setFormInputs(hub: Hub) {
    this.addHubForm.setValue({
      name: hub.name,
      alias: hub.aliasName,
      description: hub.description,
      earlyVariance: hub.earlyVariance.toString(),
      fltEnabled: hub.isFLTEnabled,
      fltScanning: hub.fltScanning,
      isDirect: hub.isDirectTrunkHub,
      isVirtual: hub.isVirtualHub,
      lateTrunk: hub.isLateTrunkFeeEnabled,
      lateVariance: hub.lateVariance.toString(),
      isObsolete: hub.isObsolete
    })
  }

  private setToggleSwitches(hub: Hub) {
    this.isFltEnabledChecked = hub.isFLTEnabled
    this.isFltScanningChecked = hub.fltScanning
    this.isDirectChecked = hub.isDirectTrunkHub
    this.isVirtualChecked = hub.isVirtualHub
    this.isLateFeeEnabledChecked = hub.isLateTrunkFeeEnabled
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  toggleDetailsAccordion() {
    this.isDetailsAccordionOpen = !this.isDetailsAccordionOpen;
  }

  toggleSettingsAccordion() {
    this.isSettingsAccordionOpen = !this.isSettingsAccordionOpen;
  }

  cancel() {
    if(this.addHubForm.dirty)
    {    this.showClosingModal = true
      this.modalService.openModal({
        message: 'You have unsaved changes in the screen. Do you wish to continue without saving?',
        confirmText: 'Yes',
        cancelText: 'No',
        show: true,
        onConfirm: () => {
          this.showClosingModal = false
          this.slidingService.close()
        },
        onCancel: () => { this.showClosingModal = false }
      })} else {
      this.slidingService.close()
    }
  }

  undo() {
    this.showClosingModal = true
    this.modalService.openModal({
      message: 'Are you sure you want to discard the changes made?',
      confirmText: 'Yes',
      cancelText: 'No',
      show: true,
      onConfirm: () => {
        this.hubToEdit = JSON.parse(JSON.stringify(this.data));
        this.hubSections = this.hubToEdit.hubSections
        this.prePopulateForm(this.data)
        this.showClosingModal = false
      },
      onCancel: () => { this.showClosingModal = false }
    });
  }

  save() {
    this.gridApi.stopEditing()
    this.hubSectionError()
    if (!this.addHubForm.invalid && !this.hubSectionError())
    {
      if(this.editingHub)
      {
        this.editHub()
      } else {
        this.addHub()
      }
    }
    else {
      this.validateAllFormFields(this.addHubForm)

    }
  }



  private addHub() {
    this.hubService.addHub(this.buildHub()).subscribe({
      next: (res) => {
        this.writeHubSuccess()
      },
      error: (err: HttpErrorResponse) => {
        this.handleHttpError(err)
      }
    })
  }

  private editHub() {
    this.hubService.editHub(this.buildHub()).subscribe({
      next: (res) => {
        this.writeHubSuccess()
      },
      error: (err: HttpErrorResponse) => {
        this.handleHttpError(err)
      }
    })
  }

  private writeHubSuccess() {
    this.hubService.sendRefresh();
    this.toastService.success("Hub saved successfully");
    this.slidingService.close()
  }

  private handleHttpError(err: HttpErrorResponse) {
    const jsonAsString = JSON.stringify(err.error)
    const responseError = JSON.parse(jsonAsString) as ResponseError

    if(err.status == 409)
    {
      if(err.status == 409 && responseError.error == "Hub already exists")
      {
        this.formInputService.setText({message: "Name already in use",
          inputId: this.nameId})
        this.formInputService.setHelperVisibility({visible: true, inputId: this.nameId})
      }
      else if(err.status == 409 && responseError.error.includes("Only one hub can be Direct Trunk"))
      {
        this.formInputService.setText({message: responseError.error, inputId: "isDirectTrunk"})
        this.formInputService.setHelperVisibility({visible: true, inputId: "isDirectTrunk"})
      }
      else if(err.status == 409 && responseError.error.includes("Only one hub can be Virtual Hub"))
      {
        this.formInputService.setText({message: responseError.error, inputId: "virtualHub"})
        this.formInputService.setHelperVisibility({visible: true, inputId: "virtualHub"})
      }
      else {
        //this.toastService.error("HTTP ResponseError: " + err.status)
      }
    }
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      }
    });
    this.formInputService.showValidation(true);
  }

  // Toggle switches can be handled better and refined
  isVirtualChecked = false
  getVirtualChecked(event: boolean) {
    this.isVirtualChecked = event
  }
  isDirectChecked = false
  getDirectChecked(event: boolean) {
    this.isDirectChecked = event
  }
  isFltScanningChecked = false
  getFltScanningChecked(event: boolean) {
    this.isFltScanningChecked = event
  }
  isFltEnabledChecked = false
  getFltEnabledChecked(event: boolean) {
    this.isFltEnabledChecked = event
  }
  isLateFeeEnabledChecked = false
  getLateFeeEnabledChecked(event: boolean) {
    this.isLateFeeEnabledChecked = event
  }

  private hubSectionError(): boolean {
    let validations: boolean[] = []
    this.gridApi.forEachNode(node => {
      if (!node.data.Name.value) {
        validations.push(false)
        node.setData({
          'Number': node.data.Number,
          Name: {value: '', lastValidation: false, lastValidationMessage: 'Name is required'},
          'Actions': 'No'
        })
      }
    });
    return validations.includes(false);
  }

  private buildHub() {
    const hub = new Hub();
    hub.aliasName = this.addHubForm.value.alias!
    hub.description = this.addHubForm.value.description!
    hub.name = this.addHubForm.value.name!
    hub.earlyVariance = Number(this.addHubForm.value.earlyVariance!)
    hub.lateVariance = Number(this.addHubForm.value.lateVariance!)
    hub.isObsolete = this.isObsolete

    hub.isVirtualHub = this.isVirtualChecked
    hub.isDirectTrunkHub = this.isDirectChecked
    hub.fltScanning = this.isFltScanningChecked
    hub.isFLTEnabled = this.isFltEnabledChecked
    hub.isLateTrunkFeeEnabled = this.isLateFeeEnabledChecked

    hub.hubSections = this.hubSections

    if(this.editingHub)
    {
      hub.name = this.hubToEdit.name
      hub.id = this.hubToEdit.id
      hub.createdDate = this.hubToEdit.createdDate
      hub.updatedDate = this.hubToEdit.updatedDate
    }

    return hub;
  }

  isObsolete = false
  selectChangeHandler(event: any) {
    this.isObsolete = event.target.value.toLowerCase() === 'true'
  }

  addHubSectionsClick() {
    this.showSectionModal = true;
  }

  closeHubSectionsModal() {
    this.showSectionModal = false
  }

  private createRowData() {
    this.rowData = [];
    this.hubSections.forEach( section => {
      if(!section.isObsolete)
      {
        let sectionName = section.name ?? ''
        let validationMessage = this.sectionNameValidator(sectionName, section.number)
        let valid = !validationMessage
        this.rowData.push({
          'Number': section.number,
          Name: {value: sectionName, lastValidation: valid, lastValidationMessage: validationMessage},
          'Actions': 'No'
        })
      }
    })
  }
}
