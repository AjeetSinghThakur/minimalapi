import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FormInputComponent} from "../../../../form-input/form-input.component";
import {ModalService} from "../../../../../services/modal.service";
import {Subject} from "rxjs/internal/Subject";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators
} from "@angular/forms";
import {FormInputService} from "../../../../../services/form-input.service";
import {MaxCheckWithVariable} from "../../../../../validators/max-with-variable-check";
import {HubSection} from "../../hub-section.model";
import {NgIf} from "@angular/common";
import {alphanumericValidator} from "../../../../../validators/alphanumeric-validator";

@Component({
  selector: 'dhms-add-hub-section-modal',
  standalone: true,
  imports: [
    FormInputComponent,
    ReactiveFormsModule,
    NgIf
  ],
  templateUrl: './add-hub-section-modal.component.html',
  styleUrl: './add-hub-section-modal.component.scss'
})
export class AddHubSectionModalComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  constructor(private modalService: ModalService,
              private formInputService: FormInputService) {
  }
  @Input() hubSectionsIn: HubSection[] = [];
  @Input() editMode = false;

  @Output() closed = new EventEmitter();
  @Output() hubSectionsOut = new EventEmitter();

  private activeSections!: HubSection[]

  addHubSectionsForm = new FormGroup({
    hubSectionNumber: new FormControl('', {
      validators: [Validators.required, Validators.min(1), MaxCheckWithVariable(this.hubSectionsIn.length, 10)]
    })
  })

  addHubSectionNumberErrors: Record<string, string> = {
    required: `Section number cannot be empty`,
    max:  `Maximum amount of hub sections is 10`,
    min: `Minimum amount of hub sections is 1`,
  }

  addHubSectionForm = new FormGroup({
    hubSectionName: new FormControl('', {
      validators: [Validators.required, Validators.maxLength(2), alphanumericValidator()]
    })
  })

  addHubSectionNameErrors: Record<string,string> = {
    required: `Name is required`,
    maxlength: `Only 2 characters allowed`,
    alphanumeric: `Hub section name must be alphanumeric`,
    max:  `Maximum amount of hub sections is 10`,
    unique: `Name must be unique`
  }

  ngOnInit() {
    if(this.editMode)
    {
      this.activeSections = this.hubSectionsIn.filter(x => !x.isObsolete)
      this.addHubSectionForm = new FormGroup({
        hubSectionName: new FormControl('', {
          validators: [Validators.required, Validators.maxLength(2), alphanumericValidator(),
            this.sectionTotalCheck(this.activeSections.length, 10), this.uniqueNameCheck()]
        })
      })
    } else {
      this.addHubSectionsForm = new FormGroup({
        hubSectionNumber: new FormControl('', {
          validators: [Validators.required, Validators.min(1), MaxCheckWithVariable(this.hubSectionsIn.length, 10)]
        })
      })
    }
  }

  uniqueNameCheck(): ValidatorFn {
    return (c: AbstractControl): ValidationErrors | null => {
      let res = !(this.hubSectionsIn.filter(x => x.name == c.value && !x.isObsolete).length > 0)
      return !res ? {unique: false } : null;
    };
  }

  sectionTotalCheck(variable: number, max: number): ValidatorFn {
    return (c: AbstractControl): ValidationErrors | null => {
      let res = variable + 1 <= max;
      return !res ? {max: false } : null;
    };
  }

  ngOnDestroy() {
    this.destroy$.next()
    this.destroy$.complete()
  }

  onSave() {
    if(this.editMode){
      this.saveSection()
    } else {
      this.saveSections()
    }
  }

  private saveSection() {
    if(!this.addHubSectionForm!.invalid) {
      let lastSectionNumber = Math.max(...this.activeSections.map(o => o.number))
      let sectionNumber = 1
      if(lastSectionNumber > 0) {
        sectionNumber = lastSectionNumber + 1
      }

      let section = {
        number: sectionNumber,
        name: this.addHubSectionForm.value.hubSectionName
      } as HubSection
      this.hubSectionsIn.push(section)
      this.hubSectionsOut.emit(this.hubSectionsIn)
      this.modalService.close()
    }
  }

  private saveSections()
  {
    if (this.addHubSectionsForm!.invalid)
    {
      this.formInputService.showValidationForInput({
        inputId: 'hubSectionNumber',
        visible: true
      })
    }
    else {
      let hubNumber = 1
      if (this.hubSectionsIn.length > 0)
      {
        hubNumber = this.hubSectionsIn[this.hubSectionsIn.length-1].number
        hubNumber++
      }
      for (let i = 1; i <= Number(this.addHubSectionsForm.value.hubSectionNumber); i++) {
        let newHubSection = {number: hubNumber} as HubSection
        this.hubSectionsIn.push(newHubSection)
        hubNumber++
      }
      this.hubSectionsOut.emit(this.hubSectionsIn)
      this.modalService.close()
    }
  }
}
