import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import {SvgIconComponent} from "../../../svg-icon/svg-icon.component";
import {NgIf} from "@angular/common";

@Component({
  selector: 'dhms-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.scss'],
  imports: [
    SvgIconComponent,
    NgIf
  ],
  standalone: true
})
export class ConfirmationModalComponent implements OnInit {
  message = 'Are you sure?';
  confirmText = 'Yes';
  cancelText = 'Cancel';
  iconPath?: string;
  private onConfirm: (() => void) | undefined;
  private onCancel: (() => void) | undefined;

  constructor(private modalService: ModalService) {}

  ngOnInit(): void {
    this.modalService.showModal$.subscribe(config => {
      if (config.show) {
        this.message = config.message || this.message;
        this.confirmText = config.confirmText || this.confirmText;
        this.cancelText = config.cancelText || this.cancelText;
        this.onConfirm = config.onConfirm;
        this.onCancel = config.onCancel;
        this.iconPath = config.iconPath;
      }
    });
  }

  handleConfirm() {
    if (this.onConfirm) {
      this.onConfirm();
    }
    this.modalService.closeModal();
  }

  handleCancel() {
    if (this.onCancel) {
      this.onCancel();
    }
    this.modalService.closeModal();
  }
}
