import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HubComponent } from './hub.component';
import { ChangeDetectorRef } from '@angular/core';
import { ActiveItemService } from 'src/app/services/active-item.service';
import { HubService } from './hub.service';
import { of } from 'rxjs';
import { ToastrModule } from 'ngx-toastr';

describe('HubComponent', () => {
  let component: HubComponent;
  let fixture: ComponentFixture<HubComponent>;
  let activeItemServiceMock: Partial<ActiveItemService>;
  let hubServiceMock: Partial<HubService>;

  beforeEach(async () => {
    // Mock services
    activeItemServiceMock = {
      setHeaderTitle: jasmine.createSpy(),
      setActiveSubItem: jasmine.createSpy()
    };
    hubServiceMock = {
      getHubs: jasmine.createSpy().and.returnValue(of([{ name: 'Test Hub' }]))
    };

    await TestBed.configureTestingModule({
      imports: [HubComponent, ToastrModule.forRoot()],
      providers: [
        { provide: ChangeDetectorRef, useValue: {} },
        { provide: ActiveItemService, useValue: activeItemServiceMock },
        { provide: HubService, useValue: hubServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(HubComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set active item correctly', () => {
    const itemName = 'Test Item';
    component.setActiveItem(itemName);
    expect(component.activeItem).toEqual(itemName);
    expect(activeItemServiceMock.setHeaderTitle).toHaveBeenCalledWith(itemName);
  });

  it('should fetch hubs on init', () => {
    fixture.detectChanges();
    expect(hubServiceMock.getHubs).toHaveBeenCalled();
    expect(component.data.length).toBeGreaterThan(0);
    expect(component.data[0].name).toEqual('Test Hub');
  });

});
