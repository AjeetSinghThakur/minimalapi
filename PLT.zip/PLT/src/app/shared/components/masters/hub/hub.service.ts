import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { environment } from '@env/environment';
import { Hub } from './hub.model';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HubService {
  private subject = new Subject<void>();
  private hubsSubject = new BehaviorSubject<Hub[]>([]);
  hubs$ = this.hubsSubject.asObservable();
  apiUrl = environment.apiUrls.masterApiUrl;

  constructor(private http: HttpClient) { }

  getHubs(): Observable<Hub[]> {
    return this.http.get<Hub[]>(`${this.apiUrl}/Hub`).pipe(
      tap(hubs => this.hubsSubject.next(hubs))
    );
  }

  getHubAudit(hubId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/Hub/${hubId}/GetHubAuditByHubId`);
  }

  setHubActiveOrInactive(hubId: number): Observable<any> {
    return this.http.patch<any>(`${this.apiUrl}/Hub/${hubId}/toggle-active`, null);
  }

  addHub(hub: Hub): Observable<any> {
    return this.http.post(`${this.apiUrl}/Hub`, hub);
  }

  editHub(hub: Hub): Observable<any> {
    return this.http.patch(`${this.apiUrl}/Hub/UpdateHub`, hub);
  }

  refreshGrid(): Observable<any> {
    return this.subject.asObservable();
  }

  sendRefresh() {
    this.subject.next();
  }

  getHubById(hubId: number): Hub | undefined {
    return this.hubsSubject.value.find(hub => hub.id === hubId);
  }
}
