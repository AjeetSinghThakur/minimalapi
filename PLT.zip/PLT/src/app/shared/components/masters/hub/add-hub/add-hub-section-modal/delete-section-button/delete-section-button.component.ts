import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { ICellRendererParams } from "@ag-grid-community/core";
import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  standalone: true,
  template: `<button type="button" (click)="sectionToDelete.emit(sectionNumber)">
    <img class="mt-2" src="../../../../assets/icons/grid-delete.svg" /></button>`,
})
export class DeleteSectionButtonComponent implements ICellRendererAngularComp {
  @Output() sectionToDelete = new EventEmitter()
  sectionNumber = 0
  agInit(params: ICellRendererParams): void {
    this.sectionNumber = params.data.Number
  }
  refresh(params: ICellRendererParams) {
    return true;
  }
}
