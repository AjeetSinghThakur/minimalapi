import { Component, forwardRef, Input } from '@angular/core';
import { SvgIconComponent } from '../svg-icon/svg-icon.component';
import {NG_VALUE_ACCESSOR, ControlValueAccessor, ReactiveFormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'dhms-input-text',
  standalone: true,
  imports: [SvgIconComponent, CommonModule, ReactiveFormsModule],
  templateUrl: './input-text.component.html',
  styleUrl: './input-text.component.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputTextComponent),
      multi: true,
    },
  ],
})
export class InputTextComponent implements ControlValueAccessor {
  @Input() label: string | undefined;
  @Input() isError: boolean = false;
  @Input() isSuccess: boolean = false;
  @Input() isDisabled: boolean = true;
  @Input() errorMessage: string = 'Something went wrong...';
  @Input() required: boolean = false;
  @Input() maxlength = ''

  private _value: string = '';

  onChange = (value: any) => {};
  onTouched = () => {};

  get value(): string {
    return this._value;
  }

  set value(val: string) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

  writeValue(value: any): void {
    if (value !== undefined) {
      this.value = value;
    }
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }

  onInputChange(event: Event): void {
    const input = event.target as HTMLInputElement | null;
    if (input) {
      this.value = input.value;
    }
  }
}
