import { Component, Input } from '@angular/core';

@Component({
  selector: 'dhms-svg-icon',
  standalone: true,
  imports: [],
  template: `
  <svg>
  <use attr.xlink:href="../../../../assets/icons/icons.svg#{{icon}}"></use>
  </svg>
`,
  styleUrl: './svg-icon.component.scss'
})
export class SvgIconComponent {
  @Input() icon: string | undefined;
}
