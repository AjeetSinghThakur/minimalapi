import { TestBed } from '@angular/core/testing';

import { LoadingMaskService } from './loading-mask.service';

describe('LoadingMaskService', () => {
  let service: LoadingMaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoadingMaskService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('show', () => {
    it('should set visibility to true and message', (done:DoneFn) => {
      service.onVisibilityChange().subscribe(res => {
        expect(res).toEqual(true)
      })
      service.show()
      done()
    })
  });

  describe('hide', () => {
    it('should set visibility to false', (done:DoneFn) => {
      service.onVisibilityChange().subscribe(res => {
        expect(res).toEqual(false)
      })
      service.hide()
      done()
    })
  });

  describe('onSetMessage', () => {
    it('should set loading message', (done:DoneFn) => {
      const msg = "Hello world"
      service.onSetMessage().subscribe(res => {
        expect(res).toEqual(msg)
      })
      service.setMessage(msg)
      done()
    })
  });
});
