import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DisableOverlayService {
  // Service to toggle an all over semi transparent screen overlay that stops the user interacting with anything

  private showOverlay = false;
  private showOverlaySource = new BehaviorSubject(this.showOverlay)

  constructor() { }

  show() {
    this.showOverlay = true
    this.showOverlaySource.next(this.showOverlay)
  }

  hide() {
    this.showOverlay = false
    this.showOverlaySource.next(this.showOverlay)
  }

  onVisibilityChange(): Observable<boolean> {
    return this.showOverlaySource.asObservable()
  }
}
