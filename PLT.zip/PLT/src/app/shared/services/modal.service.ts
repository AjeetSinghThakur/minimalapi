import {Injectable, Type} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {Subject} from "rxjs/internal/Subject";

interface ModalConfig {
  show: boolean;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm?: () => void;
  onCancel?: () => void;
  iconPath?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  private showModalSubject = new BehaviorSubject<ModalConfig>({ show: false });
  public showModal$ = this.showModalSubject.asObservable();
  private contentChangeSource = new Subject<any>();
  private isModalVisible = false;
  private isModalVisibleSource = new BehaviorSubject<boolean>(this.isModalVisible);

  public openModal(config: ModalConfig): void {
    this.showModalSubject.next({ ...config, show: true });
  }

  public closeModal(): void {
    this.showModalSubject.next({ show: false });
  }

  public setContent(content: Type<any>) {
    this.contentChangeSource.next(content)
  }

  public onContentChange(): Observable<Type<any>> {
    return this.contentChangeSource.asObservable();
  }

  public show() {
    this.isModalVisible = true;
    this.isModalVisibleSource.next(this.isModalVisible);
  }

  public close() {
    this.isModalVisible = false;
    this.isModalVisibleSource.next(this.isModalVisible);
  }

  public isVisibleChange(): Observable<boolean> {
    return this.isModalVisibleSource.asObservable();
  }
}
