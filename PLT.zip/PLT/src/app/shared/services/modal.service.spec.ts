import { TestBed } from '@angular/core/testing';
import { ModalService } from './modal.service';

describe('ModalService', () => {
  let service: ModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('openModal', () => {
    it('should set showModal$ observable with correct config and show = true', (done: DoneFn) => {
      const modalConfig = {
        message: 'Test Message',
        confirmText: 'Confirm',
        cancelText: 'Cancel',
        show: true,
        onConfirm: () => console.log('Confirmed'),
        onCancel: () => console.log('Cancelled')
      };

      service.openModal(modalConfig);

      service.showModal$.subscribe(config => {
        expect(config.show).toBeTrue();
        expect(config.message).toEqual(modalConfig.message);
        expect(config.confirmText).toEqual(modalConfig.confirmText);
        expect(config.cancelText).toEqual(modalConfig.cancelText);
        expect(config.onConfirm).toBeDefined();
        expect(config.onCancel).toBeDefined();
        done();
      });
    });
  });

  describe('closeModal', () => {
    it('should set showModal$ observable with show = false', (done: DoneFn) => {
      service.closeModal();

      service.showModal$.subscribe(config => {
        expect(config.show).toBeFalse();
        done();
      });
    });
  });
});
