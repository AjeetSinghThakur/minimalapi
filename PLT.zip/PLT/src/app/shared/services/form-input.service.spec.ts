import { TestBed } from '@angular/core/testing';

import {FormHelperVisibility, FormInputService} from './form-input.service';

describe('FormInputService', () => {
  let service: FormInputService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FormInputService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('onShowValidationChange', () => {
    it('should return true if passed true', (done:DoneFn) => {
      service.onShowValidationChange().subscribe( res => {
        expect(res).toEqual(true)
      })
      service.showValidation(true)
      done()
    })

    it('should return false if passed false', (done:DoneFn) => {
      service.onShowValidationChange().subscribe( res => {
        expect(res).toEqual(false)
      })
      service.showValidation(false)
      done()
    })
  });
});
