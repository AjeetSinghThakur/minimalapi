import {Injectable, Type} from '@angular/core';
import {Subject} from "rxjs/internal/Subject";

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private data = new Subject<any>();
  data$ = this.data.asObservable();

  setData(data: any) {
    this.data.next(data);
  }
}
