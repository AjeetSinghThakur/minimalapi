import { Injectable } from '@angular/core';
import {Subject} from "rxjs/internal/Subject";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class GridService {
  private searchSource = new Subject<string>()

  searchGrid(searchText: string) {
    this.searchSource.next(searchText)
  }

  onSearchGrid(): Observable<string> {
    return this.searchSource as Observable<string>
  }
}
