import { Injectable, Type } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import {TreeDataDisplayType} from "@ag-grid-community/core";

export interface ContentWithData {
  content: any
  data: any
}

@Injectable({
  providedIn: 'root',
})
export class SlidingPanelService {
  private isPanelVisible = false;
  private outsideClickSource = new Subject<void>();
  private closePanelSource = new BehaviorSubject<boolean>(this.isPanelVisible);
  public showSlidingPanel$ = this.closePanelSource.asObservable();
  private contentChangeSource = new Subject<any>();
  private titleChangeSource = new Subject<string>();
  private dataChangeSource: Subject<ContentWithData> = new Subject<ContentWithData>();
  private closeRequestSource = new Subject<void>();

  public onPanelVisibilityChange(): Observable<boolean> {
    return this.closePanelSource.asObservable();
  }

  public onContentChange(): Observable<Type<any>> {
    return this.contentChangeSource.asObservable();
  }

  public setContent(content: Type<any>): void {
    this.contentChangeSource.next(content);
  }

  public onContentWithDataChange(): Observable<ContentWithData> {
    return this.dataChangeSource.asObservable();
  }

  public setContentWithDataChange(data: ContentWithData): void {
    this.dataChangeSource.next(data);
  }

  public onTitleChange(): Observable<string> {
    return this.titleChangeSource.asObservable();
  }

  public setTitle(title: string): void {
    this.titleChangeSource.next(title);
  }

  public show(): void {
    this.isPanelVisible = true;
    this.closePanelSource.next(this.isPanelVisible);
  }

  public close(): void {
    this.isPanelVisible = false;
    this.closePanelSource.next(this.isPanelVisible);
  }

  public closeRequest() {
    this.closeRequestSource.next()
  }

  public closeRequestListener(): Observable<void> {
    return this.closeRequestSource.asObservable()
  }

  public onOutsideClick(): Observable<void> {
    return this.outsideClickSource.asObservable()
  }

  public emitOutsideClick() {
    this.outsideClickSource.next()
  }
}
