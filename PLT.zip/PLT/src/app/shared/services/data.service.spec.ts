import { TestBed } from '@angular/core/testing';

import { DataService } from './data.service';

describe('DataService', () => {
  let service: DataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('setData', () => {
    const expectedRes = "Hello World"
    it('should return the data sent', (done:DoneFn) => {
      service.data$.subscribe( res => {
          expect(res).toEqual(expectedRes)
      })
      service.setData(expectedRes)
      done()
    })
  });
});
