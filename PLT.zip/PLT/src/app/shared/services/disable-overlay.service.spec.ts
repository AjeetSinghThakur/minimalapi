import { TestBed } from '@angular/core/testing';

import { DisableOverlayService } from './disable-overlay.service';

describe('DisableOverlayService', () => {
  let service: DisableOverlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DisableOverlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
