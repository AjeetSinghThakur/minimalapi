import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable} from "rxjs";
import {Subject} from "rxjs/internal/Subject";

@Injectable({
  providedIn: 'root'
})
export class LoadingMaskService {
  private showMask = false
  private showMaskSource = new Subject<boolean>()
  private messageSource = new Subject<string>()

  constructor() { }

  show() {
    this.showMask = true
    this.messageSource.next("Please wait...")
    this.showMaskSource.next(this.showMask)
  }

  hide() {
    //await this.sleep(1000)
    this.showMask = false
    this.showMaskSource.next(this.showMask)
  }

  sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  onVisibilityChange(): Observable<boolean> {
    return this.showMaskSource.asObservable()
  }

  setMessage(message: string) {
    this.messageSource.next(message)
  }

  onSetMessage(): Observable<string> {
    return this.messageSource.asObservable()
  }
}
