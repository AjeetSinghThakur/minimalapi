import { Injectable } from '@angular/core';
import {Subject} from "rxjs/internal/Subject";
import {Observable} from "rxjs";

export interface FormHelperText {
  message: string,
  inputId: string
}

export interface FormHelperVisibility {
  visible: boolean,
  inputId: string
}

@Injectable({
  providedIn: 'root'
})

export class FormInputService {
  private helperVisibilitySource = new Subject<FormHelperVisibility>
  private helperTextChangeSource = new Subject<FormHelperText>
  private validationSource = new Subject<boolean>
  private validationForInputSource = new Subject<FormHelperVisibility>

  showValidation(showValidation: boolean) {
    this.validationSource.next(showValidation);
  }

  onShowValidationChange(): Observable<boolean> {
    return this.validationSource.asObservable();
  }

  showValidationForInput(formHelperText: FormHelperVisibility) {
    this.validationForInputSource.next(formHelperText)
  }

  onShowValidationForInputChange(): Observable<FormHelperVisibility> {
    return this.validationForInputSource.asObservable()
  }

  //Below allows you to hide / show / set the manual text helper - i.e. handling errors sent by the API that are not handled by the validators
  //Need to pass in some sort of ref / ID to change the correct input
  setText(helperText: FormHelperText) {
    this.helperTextChangeSource.next(helperText);
  }

  onTextChange(): Observable<FormHelperText> {
    return this.helperTextChangeSource.asObservable();
  }

  setHelperVisibility(helperVisibility: FormHelperVisibility) {
    this.helperVisibilitySource.next(helperVisibility);
  }

  onHelperVisibilityChange(): Observable<FormHelperVisibility> {
    return this.helperVisibilitySource.asObservable();
  }
}
