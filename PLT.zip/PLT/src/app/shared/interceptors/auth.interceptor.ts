import { finalize, switchMap, take } from 'rxjs/operators';
import { AuthService } from '@auth0/auth0-angular';
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
 
export const AuthInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  // Retrieve the token from the AuthService
  return authService.getAccessTokenSilently().pipe(
    take(1), // Make sure to only take one value from the observable
    switchMap(tokenClaims => {
      const token = tokenClaims;
      if (token) {
        // Clone the request and add the authorization header
        req = req.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`
          }
        });
      }
      return next(req);
    }),
    finalize(() => {
      // Any cleanup can go here, if needed
    })
  );
};