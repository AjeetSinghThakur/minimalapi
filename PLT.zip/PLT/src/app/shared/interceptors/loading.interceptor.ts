import { HttpInterceptorFn } from "@angular/common/http";
import { LoadingMaskService } from "../services/loading-mask.service";
import { finalize } from "rxjs";
import { inject } from "@angular/core";

export const LoadingInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/User/IsUserBlocked/') || req.url.includes('/UserRole/UserRoleToHubMappingsForUsers')) {
    return next(req);
  }

  const loadMaskService = inject(LoadingMaskService);
  loadMaskService.show();

  return next(req).pipe(
    finalize(() => {
      loadMaskService.hide();
    })
  );
};
