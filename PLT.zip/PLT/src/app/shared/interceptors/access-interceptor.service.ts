import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap, first, tap } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
import { UserService } from 'src/app/services/user.service';
import { AuthService as Auth0AuthService } from '@auth0/auth0-angular';
import { environment } from '@env/environment';

@Injectable()
export class AccessInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private userService: UserService,
    private toastr: ToastrService,
    private oAuthService: Auth0AuthService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (
      req.url.includes('/User/IsUserBlocked/') ||
      req.url.includes('/UserRole/UserRoleToHubMappingsForUsers')
    ) {
      return next.handle(req);
    }

    return this.authService.user().pipe(
      first(),
      switchMap((user) => {
        if (user && user.sub) {
          return this.userService.isUserBlocked(user.sub).pipe(
            switchMap((isBlocked) => {
              if (isBlocked) {
                setTimeout(() => {
                  this.toastr.error('No Access', '');
                  this.oAuthService.logout({ logoutParams: { returnTo:  environment.auth0Config.logoutUrl } });
                }, 1000);
                return throwError(() => new Error('User is blocked'));
              } else {
                return next.handle(req);
              }
            }),
            catchError((error) => {
              return next.handle(req);
            })
          );
        } else {
          return next.handle(req);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error);
      })
    );
  }
}
