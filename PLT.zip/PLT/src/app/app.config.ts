import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideAuth0 } from "@auth0/auth0-angular";
import { environment } from "../environments/environment";
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptors, withInterceptorsFromDi} from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideToastr } from 'ngx-toastr';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import {LoadingInterceptor} from "./shared/interceptors/loading.interceptor";
import { AccessInterceptor } from './shared/interceptors/access-interceptor.service';
import { AuthInterceptor } from './shared/interceptors/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideAuth0(environment.auth0Config),
    provideAuth0({
      ...environment.auth0Config,
      httpInterceptor: {
        ...environment.httpInterceptor,
      }
    }),
    provideHttpClient(
      withInterceptors([LoadingInterceptor]),   
      withInterceptorsFromDi()                  
    ),
    provideHttpClient(withInterceptors([LoadingInterceptor, AuthInterceptor])),
    provideAnimations(),
    provideToastr(),
    provideAnimationsAsync(),
    { provide: HTTP_INTERCEPTORS, useClass: AccessInterceptor, multi: true },
  ]
};
