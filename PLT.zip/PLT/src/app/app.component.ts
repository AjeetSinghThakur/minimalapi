import {Component, OnDestroy, OnInit} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from "./shared/components/sidebar/sidebar.component";
import { HeaderComponent } from './shared/components/header/header.component';
import {LoadingMaskComponent} from "./shared/components/loading-mask/loading-mask.component";
import {NgIf} from "@angular/common";
import {Subject} from "rxjs/internal/Subject";
import {DisableOverlayService} from "./shared/services/disable-overlay.service";
import {takeUntil} from "rxjs/operators";
import {
    ConfirmationModalComponent
} from "./shared/components/masters/hub/confirmation-modal/confirmation-modal.component";
import {ModalService} from "./shared/services/modal.service";
import {AuthService} from "@auth0/auth0-angular";
import {environment} from "@env/environment";
import { Subscription } from 'rxjs';
import { ChangeRoleModalComponent } from './shared/components/masters/change-role-modal/change-role-modal.component';


@Component({
  selector: 'dhms-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [RouterOutlet, SidebarComponent, HeaderComponent, LoadingMaskComponent, NgIf, ConfirmationModalComponent, ChangeRoleModalComponent]
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'pl-dhms-app';
  showOverlay = false;
  showLogOutModal = false;
  showRoleChangeModal = false;
  private destroy$ = new Subject<void>()
  private subscriptions = new Subscription();

  constructor(private disableOverlay: DisableOverlayService,
              private modalService: ModalService,
              private auth: AuthService            ) {
  }

  ngOnInit() {
    this.disableOverlay.onVisibilityChange().pipe(takeUntil(this.destroy$)).subscribe(showOverlay => {
      this.showOverlay = showOverlay;
    });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscriptions.unsubscribe();
  }

  logout() {
    this.showLogOutModal = true;
    this.showOverlay = true;
    this.modalService.openModal({
      message: 'Are you sure you want to log out of the application?',
      confirmText: 'Yes',
      cancelText: 'Cancel',
      show: true,
      iconPath: 'power',
      onConfirm: () => {
        this.auth.logout({ logoutParams: { returnTo: environment.auth0Config.logoutUrl } })
          .subscribe({ complete: () => {             
            // Optional: Clear browser history after successful logout
            window.history.replaceState({}, '', environment.auth0Config.logoutUrl); } 
          });
      },
      onCancel: () => {
        this.showOverlay = false;
        this.showRoleChangeModal = false;
      }
    });
  }

  openChangeRoleModal() {
    this.showRoleChangeModal = true;
    this.showOverlay = true;
    this.modalService.openModal({
      show: true,
      message: 'Select User Role',
      confirmText: 'Update',
      cancelText: 'Cancel',
      iconPath: 'role',
      onConfirm: () => {
        this.showOverlay = false;
        this.showRoleChangeModal = false;
      },
      onCancel: () => {
        this.showOverlay = false;
        this.showRoleChangeModal = false;
      }
    });
  }
}
