export class UserRoleToHubMapping {
    id?: number;
    userId? : number;
    userRoleId?: number;
    hubId? : number;
    isObsolete?: boolean;
    default?: boolean;
  }