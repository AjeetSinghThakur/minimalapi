export class UserRole {
    id? : number;
    name: string | null | undefined ;
    appliedToRef? : number | null | undefined;
    depotHubName?: string | null | undefined;
    depotHubId?: number;
    typeIdRef?: number | null | undefined;
    isObsolete?: boolean;
    default?: boolean;
  }