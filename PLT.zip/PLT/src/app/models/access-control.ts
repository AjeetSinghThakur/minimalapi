export class AccessControl {
    id!: number;
    controlName? : string;
    isObsolete? : boolean;
    
    parentControlId? : number | null | undefined;
    controlLevelId? : number;
    childControlsLevel2? : AccessControlItem[];
    childControlsLevel3? : AccessControlItem[];
    childControlsLevel4? : AccessControlItem[];
}

export class AccessControlItem extends AccessControl {
    isSelected: boolean = false; 
    constructor(init?: Partial<AccessControlItem>) {
      super();
      if (init) {
        Object.assign(this, init);
      }
    }
    toggleSelection(isObsolete: boolean): void {
        this.isSelected = !isObsolete;
        this.toggleChildSelection(this.childControlsLevel2, isObsolete);
        this.toggleChildSelection(this.childControlsLevel3, isObsolete);
        this.toggleChildSelection(this.childControlsLevel4, isObsolete);
    }

    private toggleChildSelection(children: AccessControlItem[] | undefined, isObsolete: boolean): void {
        children?.forEach(child => child.toggleSelection(isObsolete));
    }
  }
  