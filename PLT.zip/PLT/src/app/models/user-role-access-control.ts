export class UserRoleAccessControl {
    userRoleId?: number;
    accessControlId?: number;
    isObsolete?: boolean;
    createdDate?: Date;
    updatedDate?: Date;
}