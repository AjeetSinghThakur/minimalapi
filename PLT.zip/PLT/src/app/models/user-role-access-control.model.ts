export interface UserRoleAccessControl{
    isObsolete?: boolean;
    id: number;
    userRoleId: number;
    accessControlId: number;
  }