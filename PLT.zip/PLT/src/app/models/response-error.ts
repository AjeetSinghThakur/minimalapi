export interface ResponseError {
  error: string;
}
