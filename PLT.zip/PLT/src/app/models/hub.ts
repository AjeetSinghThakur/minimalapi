export class Hub {
  id?: string;
  name?: string;
  aliasName?: string;
  description?: string;
}
