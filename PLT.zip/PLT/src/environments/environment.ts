export const environment = {
  auth0Config: {
    domain: 'palletline-digital-hub-dev.uk.auth0.com',
    clientId: 'Q5vZKTX5ia9J2PdiiMGKjb7rB9gvmcqI',
    apiUri: 'https://localhost:7095',
    appUri: 'http://localhost:4200',
    authorizationParams: {
      audience: 'https://pal.dhms.auth.api.dev.com',
      redirect_uri: 'http://localhost:4200/hub'
    },
    logoutUrl: 'http://localhost:4200/login'
  },
  httpInterceptor: {
    allowedList: [`https://localhost:7095/*`]
  },
  apiUrls: {
    authApiUrl: 'http://localhost:5139/api',
    masterApiUrl: 'http://localhost:5106/api',
  },
}

