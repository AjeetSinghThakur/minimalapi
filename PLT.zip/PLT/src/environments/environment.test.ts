export const environment = {
    production: false,
    auth0Config: {
      domain: 'palletline-digital-hub-test.uk.auth0.com',
      clientId: 'GPY3bvCQSkFapkrLqerbtHtzu3NFcFUs',
      apiUri: 'https://localhost:7095',
      appUri: 'https://web-test.palletline.p2dl.com',
      authorizationParams: {
        audience: 'https://pal.dhms.auth.api.dev.com',
        redirect_uri: 'https://web-test.palletline.p2dl.com/hub'
      },
      logoutUrl: 'https://web-test.palletline.p2dl.com/login'
    },
    httpInterceptor: {
      allowedList: [`https://localhost:7095/*`]
    },
    apiUrls: {
      authApiUrl: 'https://auth-test.palletline.p2dl.com/api',
      masterApiUrl: 'https://masters-test.palletline.p2dl.com/api',
    },
  }