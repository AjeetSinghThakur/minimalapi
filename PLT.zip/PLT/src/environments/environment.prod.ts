export const environment = {
    production: true,
    auth0Config: {
      domain: 'palletline-digital-hub-dev.uk.auth0.com',
      clientId: 'Q5vZKTX5ia9J2PdiiMGKjb7rB9gvmcqI',
      apiUri: 'https://localhost:7095',
      appUri: 'https://icy-mud-01bc2d410.4.azurestaticapps.net',
      authorizationParams: {
        audience: 'https://pal.dhms.auth.api.dev.com',
        redirect_uri: 'https://web-dev.palletline.p2dl.com/hub'
      },
      logoutUrl: 'https://web-dev.palletline.p2dl.com/login'
    },
    httpInterceptor: {
      allowedList: [`https://localhost:7095/*`]
    },
    apiUrls: {
      authApiUrl: 'https://auth-dev.palletline.p2dl.com/api',
      masterApiUrl: 'https://masters-dev.palletline.p2dl.com/api',
    },
  }