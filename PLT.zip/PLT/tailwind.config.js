/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {
      colors:{
        primary:{
          medium:"#001CA8",
          text: "#171736",
          placeholder: "#B9B9B9",
          border:"#E6E9EC",
          span:"#939393",
          purple:"#D8D8FE",
          background:"#F2F2F2",
          notification:"#E23636",
          toggle:"#BBC5CB",
          toggleBackground:"#5570F11F",
        },
        secondary:{
          text:"#4F5B67",
          border:"#F1F1F1"
        },
        login:{
          text: "#939393",
        },
        sidebar:{
          active:"#F7F7FB",
          border:"#F2F2F2",
          logout:"#EF3E33",
          defaultIcon:"#D9D9D9",
          defaultSubIcon:"#D9D9D9",
        },
        header:{
          text:"#222",
          background:"#F3F4F6"
        },
        icon:{
          hover:"#162288",
        },
        dark:{
          background:"#1F2228",
        },
        table:{
          header:"#E8EBF3",
          active:"#32936F",
          activeBackground:"#32936F",
          inActive:"#fd0000",
          inActiveBackground:"#fd0000",
          border:"#00000024",
          iconBackground:"#F3F4F6"
        },
        slidingMenu:{
          button:"#F3F4F6",
          border:"#E6E6E6",
          heading:"#4F5B67",
          background2:"#18357f",
        },
        button:{
          closeHoverBg:"#EF3E3333",
          closeHover:"#EF3E33",
          close:"#222222",
          hoverBg:"#E8EBF3",
        },
        input:{
          background:"#E8EBF3"
        },
        accordion:{
          background:"#00b895"
        },
        validation:{
          success:"#32936f",
          error:"#f57e77",
        }
      }
    },screens: {
      'sm': '640px',
      'md': '768px',
      'lg': '900px',
      'xl': '1024px',
      '2xl': '1280px',
      '3xl': '1536px',
    },
  },
  plugins: [],
}
