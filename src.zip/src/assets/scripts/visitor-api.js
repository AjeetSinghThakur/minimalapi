!function e$jscomp$0(d,a,f){function p(q,l){if(!a[q]){if(!d[q]){var c="function"==typeof require&&require;if(!l&&c)return c(q,!0);if(C)return C(q,!0);l=Error("Cannot find module '"+q+"'");throw l.code="MODULE_NOT_FOUND",l;}l=a[q]={exports:{}};d[q][0].call(l.exports,function(a){var b=d[q][1][a];return p(b?b:a)},l,l.exports,e$jscomp$0,d,a,f)}return a[q].exports}for(var C="function"==typeof require&&require,l=0;l<f.length;l++)p(f[l]);return p}({1:[function(d,a,f){(function(m){var f=d("./child/ChildVisitor"),
C=d("./child/Message"),l=d("./child/makeChildMessageListener"),q=d("./utils/asyncParallelApply"),F=d("./utils/enums"),c=d("./utils/utils"),b=d("./utils/getDomain"),g=d("./units/version"),k=d("./units/crossDomain"),n=d("@adobe-mcid/visitor-js-shared/lib/ids/generateRandomID"),B=d("./units/makeCorsRequest"),Ca=d("./units/makeDestinationPublishing"),P=d("./utils/constants"),L=function(a,d,f){function p(a){return function(b){b=b||v.location.href;try{var c=e._extractParamFromUri(b,a);if(c)return I.parsePipeDelimetedKeyValues(c)}catch(vc){}}}
function t(a){a=a||{};e._supplementalDataIDCurrent=a.supplementalDataIDCurrent||"";e._supplementalDataIDCurrentConsumed=a.supplementalDataIDCurrentConsumed||{};e._supplementalDataIDLast=a.supplementalDataIDLast||"";e._supplementalDataIDLastConsumed=a.supplementalDataIDLastConsumed||{}}function L(a){return function(a){var b=I.getTimestampInSeconds();return a=a?a+="|":a,a+("TS\x3d"+b)}(a.reduce(function(a,b){var c=b[0];b=b[1];if(null!=b&&b!==ca){var e=a;a=(e=e?e+="|":e,e+(c+"\x3d"+encodeURIComponent(b)))}return a},
""))}if(!f||f.split("").reverse().join("")!==a)throw Error("Please use `Visitor.getInstance` to instantiate Visitor.");var e=this;e.version="3.1.2";var v=m,A=v.Visitor;A.version=e.version;A.AuthState=F.AUTH_STATE;A.OptOut=F.OPT_OUT;v.s_c_in||(v.s_c_il=[],v.s_c_in=0);e._c="Visitor";e._il=v.s_c_il;e._in=v.s_c_in;e._il[e._in]=e;v.s_c_in++;e._log={requests:[]};e.marketingCloudOrgID=a;e.cookieName="AMCV_"+a;e.sessionCookieName="AMCVS_"+a;e.cookieDomain=b();e.cookieDomain===v.location.hostname&&(e.cookieDomain=
"");e.loadSSL=0<=v.location.protocol.toLowerCase().indexOf("https");e.loadTimeout=3E4;e.CORSErrors=[];e.marketingCloudServer=e.audienceManagerServer="dpm.demdex.net";e.sdidParamExpiry=30;var va=v.document,ia=null,ca="NONE",Pa=B(e,Nb);e.FIELDS=F.FIELDS;e.cookieRead=function(a){a=encodeURIComponent(a);var b=(";"+va.cookie).split(" ").join(";"),e=b.indexOf(";"+a+"\x3d"),c=0>e?e:b.indexOf(";",e+1);return 0>e?"":decodeURIComponent(b.substring(e+2+a.length,0>c?b.length:c))};e.cookieWrite=function(a,b,c){var g,
k=e.cookieLifetime;(b=""+b,k=k?(""+k).toUpperCase():"",c&&"SESSION"!==k&&"NONE"!==k)?(g=""!==b?parseInt(k?k:0,10):-60)?(c=new Date,c.setTime(c.getTime()+1E3*g)):1===c&&(c=new Date,g=c.getYear(),c.setYear(g+2+(1900>g?1900:0))):c=0;return a&&"NONE"!==k?(va.cookie=encodeURIComponent(a)+"\x3d"+encodeURIComponent(b)+"; path\x3d/;"+(c?" expires\x3d"+c.toGMTString()+";":"")+(e.cookieDomain?" domain\x3d"+e.cookieDomain+";":""),e.cookieRead(a)===b):0};e.resetState=function(a){a?e._mergeServerState(a):t()};
e._isAllowedDone=!1;e._isAllowedFlag=!1;e.isAllowed=function(){return e._isAllowedDone||(e._isAllowedDone=!0,(e.cookieRead(e.cookieName)||e.cookieWrite(e.cookieName,"T",1))&&(e._isAllowedFlag=!0)),e._isAllowedFlag};e.setMarketingCloudVisitorID=function(a){e._setMarketingCloudFields(a)};e._use1stPartyMarketingCloudServer=!1;e.getMarketingCloudVisitorID=function(a,b){if(e.isAllowed()){e.marketingCloudServer&&0>e.marketingCloudServer.indexOf(".demdex.net")&&(e._use1stPartyMarketingCloudServer=!0);var c=
e._getAudienceManagerURLData("_setMarketingCloudFields");return e._getRemoteField("MCMID",c.url,a,b,c)}return""};e.getVisitorValues=function(a,b){var c={MCMID:{fn:e.getMarketingCloudVisitorID,args:[!0],context:e},MCOPTOUT:{fn:e.isOptedOut,args:[void 0,!0],context:e},MCAID:{fn:e.getAnalyticsVisitorID,args:[!0],context:e},MCAAMLH:{fn:e.getAudienceManagerLocationHint,args:[!0],context:e},MCAAMB:{fn:e.getAudienceManagerBlob,args:[!0],context:e}};b=b&&b.length?I.pluck(c,b):c;q(b,a)};e._currentCustomerIDs=
{};e._customerIDsHashChanged=!1;e._newCustomerIDsHash="";e.setCustomerIDs=function(a){function b(){e._customerIDsHashChanged=!1}if(e.isAllowed()&&a){e._readVisitor();var c,g;for(c in a)if(!Object.prototype[c]&&(g=a[c]))if("object"==typeof g){var k={};g.id&&(k.id=g.id);void 0!=g.authState&&(k.authState=g.authState);e._currentCustomerIDs[c]=k}else e._currentCustomerIDs[c]={id:g};a=e.getCustomerIDs();k=e._getField("MCCIDH");var oa="";k||(k=0);for(c in a)!Object.prototype[c]&&(g=a[c],oa+=(oa?"|":"")+
c+"|"+(g.id?g.id:"")+(g.authState?g.authState:""));e._newCustomerIDsHash=e._hash(oa);e._newCustomerIDsHash!==k&&(e._customerIDsHashChanged=!0,e._mapCustomerIDs(b))}};e.getCustomerIDs=function(){e._readVisitor();var a,b,c={};for(a in e._currentCustomerIDs)!Object.prototype[a]&&(b=e._currentCustomerIDs[a],c[a]||(c[a]={}),b.id&&(c[a].id=b.id),void 0!=b.authState?c[a].authState=b.authState:c[a].authState=A.AuthState.UNKNOWN);return c};e.setAnalyticsVisitorID=function(a){e._setAnalyticsFields(a)};e.getAnalyticsVisitorID=
function(a,b,c){if(!I.isTrackingServerPopulated()&&!c)return e._callCallback(a,[""]),"";if(e.isAllowed()){var g="";if(c||(g=e.getMarketingCloudVisitorID(function(b){e.getAnalyticsVisitorID(a,!0)})),g||c){var k=c?e.marketingCloudServer:e.trackingServer,oa="";e.loadSSL&&(c?e.marketingCloudServerSecure&&(k=e.marketingCloudServerSecure):e.trackingServerSecure&&(k=e.trackingServerSecure));var n={};if(k){k="http"+(e.loadSSL?"s":"")+"://"+k+"/id";g="d_visid_ver\x3d"+e.version+"\x26mcorgid\x3d"+encodeURIComponent(e.marketingCloudOrgID)+
(g?"\x26mid\x3d"+encodeURIComponent(g):"")+(e.idSyncDisable3rdPartySyncing||e.disableThirdPartyCookies?"\x26d_coppa\x3dtrue":"");var d=["s_c_il",e._in,"_set"+(c?"MarketingCloud":"Analytics")+"Fields"];oa=k+"?"+g+"\x26callback\x3ds_c_il%5B"+e._in+"%5D._set"+(c?"MarketingCloud":"Analytics")+"Fields";n.corsUrl=k+"?"+g;n.callback=d}return n.url=oa,e._getRemoteField(c?"MCMID":"MCAID",oa,a,b,n)}}return""};e.getAudienceManagerLocationHint=function(a,b){if(e.isAllowed()&&e.getMarketingCloudVisitorID(function(b){e.getAudienceManagerLocationHint(a,
!0)})){var c=e._getField("MCAID");if(!c&&I.isTrackingServerPopulated()&&(c=e.getAnalyticsVisitorID(function(b){e.getAudienceManagerLocationHint(a,!0)})),c||!I.isTrackingServerPopulated())return c=e._getAudienceManagerURLData(),e._getRemoteField("MCAAMLH",c.url,a,b,c)}return""};e.getLocationHint=e.getAudienceManagerLocationHint;e.getAudienceManagerBlob=function(a,b){if(e.isAllowed()&&e.getMarketingCloudVisitorID(function(b){e.getAudienceManagerBlob(a,!0)})){var c=e._getField("MCAID");if(!c&&I.isTrackingServerPopulated()&&
(c=e.getAnalyticsVisitorID(function(b){e.getAudienceManagerBlob(a,!0)})),c||!I.isTrackingServerPopulated()){c=e._getAudienceManagerURLData();var g=c.url;return e._customerIDsHashChanged&&e._setFieldExpire("MCAAMB",-1),e._getRemoteField("MCAAMB",g,a,b,c)}}return""};e._supplementalDataIDCurrent="";e._supplementalDataIDCurrentConsumed={};e._supplementalDataIDLast="";e._supplementalDataIDLastConsumed={};e.getSupplementalDataID=function(a,b){e._supplementalDataIDCurrent||b||(e._supplementalDataIDCurrent=
e._generateID(1));var c=e._supplementalDataIDCurrent;return e._supplementalDataIDLast&&!e._supplementalDataIDLastConsumed[a]?(c=e._supplementalDataIDLast,e._supplementalDataIDLastConsumed[a]=!0):c&&(e._supplementalDataIDCurrentConsumed[a]&&(e._supplementalDataIDLast=e._supplementalDataIDCurrent,e._supplementalDataIDLastConsumed=e._supplementalDataIDCurrentConsumed,e._supplementalDataIDCurrent=c=b?"":e._generateID(1),e._supplementalDataIDCurrentConsumed={}),c&&(e._supplementalDataIDCurrentConsumed[a]=
!0)),c};e.getOptOut=function(a,b){if(e.isAllowed()){var c=e._getAudienceManagerURLData("_setMarketingCloudFields");return e._getRemoteField("MCOPTOUT",c.url,a,b,c)}return""};e.isOptedOut=function(a,b,c){return e.isAllowed()?(b||(b=A.OptOut.GLOBAL),(c=e.getOptOut(function(c){c=c===A.OptOut.GLOBAL||0<=c.indexOf(b);e._callCallback(a,[c])},c))?c===A.OptOut.GLOBAL||0<=c.indexOf(b):null):!1};e._fields=null;e._fieldsExpired=null;e._hash=function(a){var b,c=0;if(a)for(b=0;b<a.length;b++){var e=a.charCodeAt(b);
c=(c<<5)-c+e;c&=c}return c};e._generateID=n;e._generateLocalMID=function(){var a=e._generateID(0);return da.isClientSideMarketingCloudVisitorID=!0,a};e._callbackList=null;e._callCallback=function(a,b){try{"function"==typeof a?a.apply(v,b):a[1].apply(a[0],b)}catch(jb){}};e._registerCallback=function(a,b){b&&(null==e._callbackList&&(e._callbackList={}),void 0==e._callbackList[a]&&(e._callbackList[a]=[]),e._callbackList[a].push(b))};e._callAllCallbacks=function(a,b){if(null!=e._callbackList&&(a=e._callbackList[a]))for(;0<
a.length;)e._callCallback(a.shift(),b)};e._addQuerystringParam=function(a,b,c,e){c=encodeURIComponent(b)+"\x3d"+encodeURIComponent(c);b=I.parseHash(a);a=I.hashlessUrl(a);if(-1===a.indexOf("?"))return a+"?"+c+b;var g=a.split("?");a=g[0]+"?";e=I.addQueryParamAtLocation(g[1],c,e);return a+e+b};e._extractParamFromUri=function(a,b){if((a=(new RegExp("[\\?\x26#]"+b+"\x3d([^\x26#]*)")).exec(a))&&a.length)return decodeURIComponent(a[1])};e._parseAdobeMcFromUrl=p(P.ADOBE_MC);e._parseAdobeMcSdidFromUrl=p(P.ADOBE_MC_SDID);
e._attemptToPopulateSdidFromUrl=function(b){b=e._parseAdobeMcSdidFromUrl(b);var c=1E9;b&&b.TS&&(c=I.getTimestampInSeconds()-b.TS);b&&b.SDID&&b.MCORGID===a&&c<e.sdidParamExpiry&&(e._supplementalDataIDCurrent=b.SDID,e._supplementalDataIDCurrentConsumed.SDID_URL_PARAM=!0)};e._attemptToPopulateIdsFromUrl=function(){var b=e._parseAdobeMcFromUrl();if(b&&b.TS){var c=I.getTimestampInSeconds()-b.TS;if(!(Math.floor(c/60)>P.ADOBE_MC_TTL_IN_MIN||b.MCORGID!==a)){c=b.MCMID;var g=e.setMarketingCloudVisitorID;c&&
c.match(P.VALID_VISITOR_ID_REGEX)&&g(c);e._setFieldExpire("MCAAMB",-1);b=b.MCAID;c=e.setAnalyticsVisitorID;b&&b.match(P.VALID_VISITOR_ID_REGEX)&&c(b)}}};e._mergeServerState=function(a){function b(a){I.isObject(a)&&e.setCustomerIDs(a)}function c(a){return I.isObject(a)?a:JSON.parse(a)}if(a)try{if(a=c(a),a[e.marketingCloudOrgID]){var g=a[e.marketingCloudOrgID];b(g.customerIDs);t(g.sdid)}}catch(Ud){throw Error("`serverState` has an invalid format.");}};e._timeout=null;e._loadData=function(a,b,c,g){e._addQuerystringParam(b,
"d_fieldgroup",a,1);g.url=e._addQuerystringParam(g.url,"d_fieldgroup",a,1);g.corsUrl=e._addQuerystringParam(g.corsUrl,"d_fieldgroup",a,1);da.fieldGroupObj[a]=!0;g===Object(g)&&g.corsUrl&&"XMLHttpRequest"===Pa.corsMetadata.corsType&&Pa.fireCORS(g,c,a)};e._clearTimeout=function(a){null!=e._timeout&&e._timeout[a]&&(clearTimeout(e._timeout[a]),e._timeout[a]=0)};e._settingsDigest=0;e._getSettingsDigest=function(){if(!e._settingsDigest){var a=e.version;e.audienceManagerServer&&(a+="|"+e.audienceManagerServer);
e.audienceManagerServerSecure&&(a+="|"+e.audienceManagerServerSecure);e._settingsDigest=e._hash(a)}return e._settingsDigest};e._readVisitorDone=!1;e._readVisitor=function(){if(!e._readVisitorDone){e._readVisitorDone=!0;var a,b,c;var g=e._getSettingsDigest();var k=!1,n=e.cookieRead(e.cookieName),d=new Date;if(null==e._fields&&(e._fields={}),n&&"T"!==n)for(n=n.split("|"),n[0].match(/^[\-0-9]+$/)&&(parseInt(n[0],10)!==g&&(k=!0),n.shift()),1===n.length%2&&n.pop(),a=0;a<n.length;a+=2){g=n[a].split("-");
var l=g[0];var B=n[a+1];1<g.length?(b=parseInt(g[1],10),c=0<g[1].indexOf("s")):(b=0,c=!1);k&&("MCCIDH"===l&&(B=""),0<b&&(b=d.getTime()/1E3-60));l&&B&&(e._setField(l,B,1),0<b&&(e._fields["expire"+l]=b+(c?"s":""),(d.getTime()>=1E3*b||c&&!e.cookieRead(e.sessionCookieName))&&(e._fieldsExpired||(e._fieldsExpired={}),e._fieldsExpired[l]=!0)))}!e._getField("MCAID")&&I.isTrackingServerPopulated()&&(n=e.cookieRead("s_vi"),n&&(n=n.split("|"),1<n.length&&0<=n[0].indexOf("v1")&&(B=n[1],a=B.indexOf("["),0<=a&&
(B=B.substring(0,a)),B&&B.match(P.VALID_VISITOR_ID_REGEX)&&e._setField("MCAID",B))))}};e._appendVersionTo=function(a){var b="vVersion|"+e.version,c=a?e._getCookieVersion(a):null;return c?g.areVersionsDifferent(c,e.version)&&(a=a.replace(P.VERSION_REGEX,b)):a+=(a?"|":"")+b,a};e._writeVisitor=function(){var a,b,c=e._getSettingsDigest();for(a in e._fields)!Object.prototype[a]&&e._fields[a]&&"expire"!==a.substring(0,6)&&(b=e._fields[a],c+=(c?"|":"")+a+(e._fields["expire"+a]?"-"+e._fields["expire"+a]:
"")+"|"+b);c=e._appendVersionTo(c);e.cookieWrite(e.cookieName,c,1)};e._getField=function(a,b){return null==e._fields||!b&&e._fieldsExpired&&e._fieldsExpired[a]?null:e._fields[a]};e._setField=function(a,b,c){null==e._fields&&(e._fields={});e._fields[a]=b;c||e._writeVisitor()};e._getFieldList=function(a,b){return(a=e._getField(a,b))?a.split("*"):null};e._setFieldList=function(a,b,c){e._setField(a,b?b.join("*"):"",c)};e._getFieldMap=function(a,b){if(a=e._getFieldList(a,b)){var c={};for(b=0;b<a.length;b+=
2)c[a[b]]=a[b+1];return c}return null};e._setFieldMap=function(a,b,c){var g,k=null;if(b)for(g in k=[],b)!Object.prototype[g]&&(k.push(g),k.push(b[g]));e._setFieldList(a,k,c)};e._setFieldExpire=function(a,b,c){var g=new Date;g.setTime(g.getTime()+1E3*b);null==e._fields&&(e._fields={});e._fields["expire"+a]=Math.floor(g.getTime()/1E3)+(c?"s":"");0>b?(e._fieldsExpired||(e._fieldsExpired={}),e._fieldsExpired[a]=!0):e._fieldsExpired&&(e._fieldsExpired[a]=!1);c&&(e.cookieRead(e.sessionCookieName)||e.cookieWrite(e.sessionCookieName,
"1"))};e._findVisitorID=function(a){return a&&("object"==typeof a&&(a=a.d_mid?a.d_mid:a.visitorID?a.visitorID:a.id?a.id:a.uuid?a.uuid:""+a),a&&(a=a.toUpperCase(),"NOTARGET"===a&&(a=ca)),a&&(a===ca||a.match(P.VALID_VISITOR_ID_REGEX))||(a="")),a};e._setFields=function(a,b){if(e._clearTimeout(a),null!=e._loading&&(e._loading[a]=!1),da.fieldGroupObj[a]&&da.setState(a,!1),"MC"===a){!0!==da.isClientSideMarketingCloudVisitorID&&(da.isClientSideMarketingCloudVisitorID=!1);var c=e._getField("MCMID");if(!c||
e.overwriteCrossDomainMCIDAndAID){if(c="object"==typeof b&&b.mid?b.mid:e._findVisitorID(b),!c){if(e._use1stPartyMarketingCloudServer&&!e.tried1stPartyMarketingCloudServer)return e.tried1stPartyMarketingCloudServer=!0,void e.getAnalyticsVisitorID(null,!1,!0);c=e._generateLocalMID()}e._setField("MCMID",c)}c&&c!==ca||(c="");"object"==typeof b&&((b.d_region||b.dcs_region||b.d_blob||b.blob)&&e._setFields("AAM",b),e._use1stPartyMarketingCloudServer&&b.mid&&e._setFields("A",{id:b.id}));e._callAllCallbacks("MCMID",
[c])}if("AAM"===a&&"object"==typeof b){c=604800;void 0!=b.id_sync_ttl&&b.id_sync_ttl&&(c=parseInt(b.id_sync_ttl,10));var g=Z.getRegionAndCheckIfChanged(b,c);e._callAllCallbacks("MCAAMLH",[g]);g=e._getField("MCAAMB");(b.d_blob||b.blob)&&(g=b.d_blob,g||(g=b.blob),e._setFieldExpire("MCAAMB",c),e._setField("MCAAMB",g));g||(g="");e._callAllCallbacks("MCAAMB",[g]);!b.error_msg&&e._newCustomerIDsHash&&e._setField("MCCIDH",e._newCustomerIDsHash)}"A"===a&&((a=e._getField("MCAID"))&&!e.overwriteCrossDomainMCIDAndAID||
(a=e._findVisitorID(b),a?a!==ca&&e._setFieldExpire("MCAAMB",-1):a=ca,e._setField("MCAID",a)),a&&a!==ca||(a=""),e._callAllCallbacks("MCAID",[a]));e.idSyncDisableSyncs||e.disableIdSyncs?Z.idCallNotProcesssed=!0:(Z.idCallNotProcesssed=!1,a={},a.ibs=b.ibs,a.subdomain=b.subdomain,Z.processIDCallData(a));if(b===Object(b)){var k,n;e.isAllowed()&&(k=e._getField("MCOPTOUT"));k||(k=ca,b.d_optout&&b.d_optout instanceof Array&&(k=b.d_optout.join(",")),n=parseInt(b.d_ottl,10),isNaN(n)&&(n=7200),e._setFieldExpire("MCOPTOUT",
n,!0),e._setField("MCOPTOUT",k));e._callAllCallbacks("MCOPTOUT",[k])}};e._loading=null;e._getRemoteField=function(a,b,c,g,k){var n,d="",B=I.isFirstPartyAnalyticsVisitorIDCall(a),l={MCAAMLH:!0,MCAAMB:!0};if(e.isAllowed())if(e._readVisitor(),d=e._getField(a,!0===l[a]),!(!d||e._fieldsExpired&&e._fieldsExpired[a])||e.disableThirdPartyCalls&&!B)d||("MCMID"===a?(e._registerCallback(a,c),d=e._generateLocalMID(),e.setMarketingCloudVisitorID(d)):"MCAID"===a?(e._registerCallback(a,c),d="",e.setAnalyticsVisitorID(d)):
(d="",g=!0));else if("MCMID"===a||"MCOPTOUT"===a?n="MC":"MCAAMLH"===a||"MCAAMB"===a?n="AAM":"MCAID"===a&&(n="A"),n)return!b||null!=e._loading&&e._loading[n]||(null==e._loading&&(e._loading={}),e._loading[n]=!0,e._loadData(n,b,function(b){e._getField(a)||(b&&da.setState(n,!0),b="","MCMID"===a?b=e._generateLocalMID():"AAM"===n&&(b={error_msg:"timeout"}),e._setFields(n,b))},k)),e._registerCallback(a,c),d?d:(b||e._setFields(n,{id:ca}),"");return"MCMID"!==a&&"MCAID"!==a||d!==ca||(d="",g=!0),c&&g&&e._callCallback(c,
[d]),d};e._setMarketingCloudFields=function(a){e._readVisitor();e._setFields("MC",a)};e._mapCustomerIDs=function(a){e.getAudienceManagerBlob(a,!0)};e._setAnalyticsFields=function(a){e._readVisitor();e._setFields("A",a)};e._setAudienceManagerFields=function(a){e._readVisitor();e._setFields("AAM",a)};e._getAudienceManagerURLData=function(a){var b=e.audienceManagerServer,c="",g=e._getField("MCMID"),k=e._getField("MCAAMB",!0),n=e._getField("MCAID");n=n&&n!==ca?"\x26d_cid_ic\x3dAVID%01"+encodeURIComponent(n):
"";if(e.loadSSL&&e.audienceManagerServerSecure&&(b=e.audienceManagerServerSecure),b){var d,B,l=e.getCustomerIDs();if(l)for(d in l)!Object.prototype[d]&&(B=l[d],n+="\x26d_cid_ic\x3d"+encodeURIComponent(d)+"%01"+encodeURIComponent(B.id?B.id:"")+(B.authState?"%01"+B.authState:""));a||(a="_setAudienceManagerFields");b="http"+(e.loadSSL?"s":"")+"://"+b+"/id";g="d_visid_ver\x3d"+e.version+"\x26d_rtbd\x3djson\x26d_ver\x3d2"+(!g&&e._use1stPartyMarketingCloudServer?"\x26d_verify\x3d1":"")+"\x26d_orgid\x3d"+
encodeURIComponent(e.marketingCloudOrgID)+"\x26d_nsid\x3d"+(e.idSyncContainerID||0)+(g?"\x26d_mid\x3d"+encodeURIComponent(g):"")+(e.idSyncDisable3rdPartySyncing||e.disableThirdPartyCookies?"\x26d_coppa\x3dtrue":"")+(!0===ia?"\x26d_coop_safe\x3d1":!1===ia?"\x26d_coop_unsafe\x3d1":"")+(k?"\x26d_blob\x3d"+encodeURIComponent(k):"")+n;k=["s_c_il",e._in,a];return c=b+"?"+g+"\x26d_cb\x3ds_c_il%5B"+e._in+"%5D."+a,{url:c,corsUrl:b+"?"+g,callback:k}}return{url:c}};e.appendVisitorIDsTo=function(a){try{var b=
[["MCMID",e._getField("MCMID")],["MCAID",e._getField("MCAID")],["MCORGID",e.marketingCloudOrgID]];return e._addQuerystringParam(a,P.ADOBE_MC,L(b))}catch(jb){return a}};e.appendSupplementalDataIDTo=function(a,b){if(b=b||e.getSupplementalDataID(I.generateRandomString(),!0),!b)return a;try{var c=L([["SDID",b],["MCORGID",e.marketingCloudOrgID]]);return e._addQuerystringParam(a,P.ADOBE_MC_SDID,c)}catch(vc){return a}};var I={parseHash:function(a){var b=a.indexOf("#");return 0<b?a.substr(b):""},hashlessUrl:function(a){var b=
a.indexOf("#");return 0<b?a.substr(0,b):a},addQueryParamAtLocation:function(a,b,c){a=a.split("\x26");return c=null!=c?c:a.length,a.splice(c,0,b),a.join("\x26")},isFirstPartyAnalyticsVisitorIDCall:function(a,b,c){if("MCAID"!==a)return!1;var g;return b||(b=e.trackingServer),c||(c=e.trackingServerSecure),g=e.loadSSL?c:b,!("string"!=typeof g||!g.length)&&0>g.indexOf("2o7.net")&&0>g.indexOf("omtrdc.net")},isObject:function(a){return!(!a||a!==Object(a))},removeCookie:function(a){document.cookie=encodeURIComponent(a)+
"\x3d; Path\x3d/; Expires\x3dThu, 01 Jan 1970 00:00:01 GMT;"+(e.cookieDomain?" domain\x3d"+e.cookieDomain+";":"")},isTrackingServerPopulated:function(){return!!e.trackingServer||!!e.trackingServerSecure},getTimestampInSeconds:function(){return Math.round((new Date).getTime()/1E3)},parsePipeDelimetedKeyValues:function(a){return a.split("|").reduce(function(a,b){b=b.split("\x3d");return a[b[0]]=decodeURIComponent(b[1]),a},{})},generateRandomString:function(a){a=a||5;for(var b="";a--;)b+="abcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(36*
Math.random())];return b},parseBoolean:function(a){return"true"===a||"false"!==a&&null},replaceMethodsWithFunction:function(a,b){for(var c in a)a.hasOwnProperty(c)&&"function"==typeof a[c]&&(a[c]=b);return a},pluck:function(a,b){return b.reduce(function(b,c){return a[c]&&(b[c]=a[c]),b},Object.create(null))}};e._helpers=I;var Z=Ca(e,A);e._destinationPublishing=Z;e.timeoutMetricsLog=[];var Nb,da={isClientSideMarketingCloudVisitorID:null,MCIDCallTimedOut:null,AnalyticsIDCallTimedOut:null,AAMIDCallTimedOut:null,
fieldGroupObj:{},setState:function(a,b){switch(a){case "MC":!1===b?!0!==this.MCIDCallTimedOut&&(this.MCIDCallTimedOut=!1):this.MCIDCallTimedOut=b;break;case "A":!1===b?!0!==this.AnalyticsIDCallTimedOut&&(this.AnalyticsIDCallTimedOut=!1):this.AnalyticsIDCallTimedOut=b;break;case "AAM":!1===b?!0!==this.AAMIDCallTimedOut&&(this.AAMIDCallTimedOut=!1):this.AAMIDCallTimedOut=b}}};e.isClientSideMarketingCloudVisitorID=function(){return da.isClientSideMarketingCloudVisitorID};e.MCIDCallTimedOut=function(){return da.MCIDCallTimedOut};
e.AnalyticsIDCallTimedOut=function(){return da.AnalyticsIDCallTimedOut};e.AAMIDCallTimedOut=function(){return da.AAMIDCallTimedOut};e.idSyncGetOnPageSyncInfo=function(){return e._readVisitor(),e._getField("MCSYNCSOP")};e.idSyncByURL=function(a){var b=a||{};var g=b.minutesToLive,k="";b=((e.idSyncDisableSyncs||e.disableIdSyncs)&&(k=k?k:"Error: id syncs have been disabled"),"string"==typeof b.dpid&&b.dpid.length||(k=k?k:"Error: config.dpid is empty"),"string"==typeof b.url&&b.url.length||(k=k?k:"Error: config.url is empty"),
"undefined"==typeof g?g=20160:(g=parseInt(g,10),(isNaN(g)||0>=g)&&(k=k?k:"Error: config.minutesToLive needs to be a positive number")),{error:k,ttl:g});if(b.error)return b.error;var n,d;g=a.url;k=encodeURIComponent;var B=Z;return g=g.replace(/^https:/,"").replace(/^http:/,""),n=c.encodeAndBuildRequest(["",a.dpid,a.dpuuid||""],","),d=["ibs",k(a.dpid),"img",k(g),b.ttl,"",n],B.addMessage(d.join("|")),B.requestToProcess(),"Successfully queued"};e.idSyncByDataSource=function(a){return a===Object(a)&&"string"==
typeof a.dpuuid&&a.dpuuid.length?(a.url="//dpm.demdex.net/ibs:dpid\x3d"+a.dpid+"\x26dpuuid\x3d"+a.dpuuid,e.idSyncByURL(a)):"Error: config or config.dpuuid is empty"};e._getCookieVersion=function(a){a=a||e.cookieRead(e.cookieName);return(a=P.VERSION_REGEX.exec(a))&&1<a.length?a[1]:null};e._resetAmcvCookie=function(a){var b=e._getCookieVersion();b&&!g.isLessThan(b,a)||I.removeCookie(e.cookieName)};e.setAsCoopSafe=function(){ia=!0};e.setAsCoopUnsafe=function(){ia=!1};e.init=function(){(function(){if(d&&
"object"==typeof d){e.configs=Object.create(null);for(var a in d)!Object.prototype[a]&&(e[a]=d[a],e.configs[a]=d[a]);e.idSyncContainerID=e.idSyncContainerID||0;ia="boolean"==typeof e.isCoopSafe?e.isCoopSafe:I.parseBoolean(e.isCoopSafe);e.resetBeforeVersion&&e._resetAmcvCookie(e.resetBeforeVersion);e._attemptToPopulateIdsFromUrl();e._attemptToPopulateSdidFromUrl();e._readVisitor();a=e._getField("MCIDTS");var b=Math.ceil((new Date).getTime()/P.MILLIS_PER_DAY);e.idSyncDisableSyncs||e.disableIdSyncs||
!Z.canMakeSyncIDCall(a,b)||(e._setFieldExpire("MCAAMB",-1),e._setField("MCIDTS",b));e.getMarketingCloudVisitorID();e.getAudienceManagerLocationHint();e.getAudienceManagerBlob();e._mergeServerState(e.serverState)}else e._attemptToPopulateIdsFromUrl(),e._attemptToPopulateSdidFromUrl()})();(function(){if(!e.idSyncDisableSyncs&&!e.disableIdSyncs){Z.checkDPIframeSrc();v.addEventListener("load",function(){A.windowLoaded=!0;var a=Z;a.readyToAttachIframe()&&a.attachIframe()});try{k.receiveMessage(function(a){Z.receiveMessage(a.data)},
Z.iframeHost)}catch(oa){}}})();(function(){e.whitelistIframeDomains&&P.POST_MESSAGE_ENABLED&&(e.whitelistIframeDomains=e.whitelistIframeDomains instanceof Array?e.whitelistIframeDomains:[e.whitelistIframeDomains],e.whitelistIframeDomains.forEach(function(b){var c=new C(a,b);c=l(e,c);k.receiveMessage(c,b)}))})()}};L.getInstance=function(a,b){function g(a){return a.cookieWrite("TEST_AMCV_COOKIE","T",1),"T"===a.cookieRead("TEST_AMCV_COOKIE")&&(a._helpers.removeCookie("TEST_AMCV_COOKIE"),!0)}if(!a)throw Error("Visitor requires Adobe Marketing Cloud Org ID.");
0>a.indexOf("@")&&(a+="@AdobeOrg");var k=function(){var b=m.s_c_il;if(b)for(var c=0;c<b.length;c++){var g=b[c];if(g&&"Visitor"===g._c&&g.marketingCloudOrgID===a)return g}}();if(k)return k;var n=a.split("").reverse().join("");k=new L(a,null,n);m.s_c_il.splice(--m.s_c_in,1);var d=c.getIeVersion();if("number"==typeof d&&10>d)return k._helpers.replaceMethodsWithFunction(k,function(){});try{var e=m.self!==m.parent}catch(pa){e=!0}b=e&&!g(k)&&m.parent?new f(a,b,k,m.parent):new L(a,b,n);return k=null,b.init(),
b};(function(){function a(){L.windowLoaded=!0}m.addEventListener?m.addEventListener("load",a):m.attachEvent&&m.attachEvent("onload",a);L.codeLoadEnd=(new Date).getTime()})();m.Visitor=L;a.exports=L}).call(this,"undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{"./child/ChildVisitor":2,"./child/Message":3,"./child/makeChildMessageListener":4,"./units/crossDomain":8,
"./units/makeCorsRequest":9,"./units/makeDestinationPublishing":10,"./units/version":11,"./utils/asyncParallelApply":12,"./utils/constants":14,"./utils/enums":15,"./utils/getDomain":16,"./utils/utils":18,"@adobe-mcid/visitor-js-shared/lib/ids/generateRandomID":19}],2:[function(d,a,f){(function(f){d("../utils/polyfills");var p=d("./strategies/LocalVisitor"),m=d("./strategies/ProxyVisitor"),l=d("./strategies/PlaceholderVisitor"),q=d("../utils/callbackRegistryFactory"),F=d("./Message"),c=d("../utils/enums").MESSAGES;
a.exports=function(a,g,k,n){function b(a){Q.isInvalid(a)||(qa=!1,a=Q.parse(a),t.setStateAndPublish(a.state))}function d(a){!qa&&ua&&(qa=!0,Q.send(n,a))}function P(){Object.assign(t,new p(k._generateID));t.getMarketingCloudVisitorID();t.callbackRegistry.executeAll(t.state,!0);f.removeEventListener("message",L)}function L(a){Q.isInvalid(a)||(a=Q.parse(a),qa=!1,f.clearTimeout(this.timeout),f.removeEventListener("message",L),Object.assign(t,new m(t)),f.addEventListener("message",b),t.setStateAndPublish(a.state),
t.callbackRegistry.hasCallbacks()&&d(c.GETSTATE))}function C(){ua&&postMessage?(f.addEventListener("message",L),d(c.HANDSHAKE),this.timeout=setTimeout(P,250)):P()}function A(){Object.keys(k).forEach(function(a){0!==a.indexOf("_")&&"function"==typeof k[a]&&(t[a]=function(){})});t.getSupplementalDataID=k.getSupplementalDataID}var t=this,ua=g.whitelistParentDomain;t.state={};t.version=k.version;t.marketingCloudOrgID=a;var qa=!1,Q=new F(a,ua);t.callbackRegistry=q();t.init=function(){f.s_c_in||(f.s_c_il=
[],f.s_c_in=0);t._c="Visitor";t._il=f.s_c_il;t._in=f.s_c_in;t._il[t._in]=t;f.s_c_in++;A();Object.assign(t,new l(t));C()};t.findField=function(a,b){if(t.state[a])return b(t.state[a]),t.state[a]};t.messageParent=d;t.setStateAndPublish=function(a){Object.assign(t.state,a);t.callbackRegistry.executeAll(t.state)}}}).call(this,"undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:
{})},{"../utils/callbackRegistryFactory":13,"../utils/enums":15,"../utils/polyfills":17,"./Message":3,"./strategies/LocalVisitor":5,"./strategies/PlaceholderVisitor":6,"./strategies/ProxyVisitor":7}],3:[function(d,a,f){var m=d("../utils/enums").MESSAGES,p={0:"prefix",1:"orgID",2:"state"};a.exports=function(a,d){this.parse=function(a){try{var d={};return a.data.split("|").forEach(function(a,b){void 0!==a&&(d[p[b]]=2!==b?a:JSON.parse(a))}),d}catch(c){}};this.isInvalid=function(l){var f=this.parse(l);
if(!f||2>Object.keys(f).length)return!0;var c=a!==f.orgID;l=!d||l.origin!==d;f=-1===Object.keys(m).indexOf(f.prefix);return c||l||f};this.send=function(l,f,c){f=f+"|"+a;c&&c===Object(c)&&(f+="|"+JSON.stringify(c));try{l.postMessage(f,d)}catch(b){}}}},{"../utils/enums":15}],4:[function(d,a,f){f=d("../utils/enums");var m=d("../utils/utils"),p=f.MESSAGES,C=f.ALL_APIS,l=f.ASYNC_API_MAP,q=f.FIELDGROUP_TO_FIELD;a.exports=function(a,c){function b(){var b={};return Object.keys(C).forEach(function(c){var g=
a[C[c]]();m.isValueEmpty(g)||(b[c]=g)}),b}function g(){var b=[];return a._loading&&Object.keys(a._loading).forEach(function(c){a._loading[c]&&b.push(q[c])}),b.length?b:null}function k(b){return function A(c){if(c=g())a[l[c[0]]](A,!0);else b()}}function n(a){f(a);var g=p.HANDSHAKE,k=b();c.send(a,g,k)}function d(a){k(function(){var g=p.PARENTSTATE,k=b();c.send(a,g,k)})()}function f(b){var g=a.setCustomerIDs;a.setCustomerIDs=function(k){g.call(a,k);c.send(b,p.PARENTSTATE,{CUSTOMERIDS:a.getCustomerIDs()})}}
return function(a){c.isInvalid(a)||(c.parse(a).prefix===p.HANDSHAKE?n:d)(a.source)}}},{"../utils/enums":15,"../utils/utils":18}],5:[function(d,a,f){var m=d("../../utils/enums").STATE_KEYS_MAP;a.exports=function(a){function d(){}function l(d,l){var c=this;return function(){var b=a(0,m.MCMID),g={};return g[m.MCMID]=b,c.setStateAndPublish(g),l(b),b}}this.getMarketingCloudVisitorID=function(a){a=a||d;var f=this.findField(m.MCMID,a);a=l.call(this,m.MCMID,a);return"undefined"!=typeof f?f:a()}}},{"../../utils/enums":15}],
6:[function(d,a,f){var m=d("../../utils/enums").ASYNC_API_MAP;a.exports=function(){Object.keys(m).forEach(function(a){this[m[a]]=function(d){this.callbackRegistry.add(a,d)}},this)}},{"../../utils/enums":15}],7:[function(d,a,f){d=d("../../utils/enums");var m=d.MESSAGES,p=d.ASYNC_API_MAP,C=d.SYNC_API_MAP;a.exports=function(){function a(){}function d(a,c){var b=this;return function(){return b.callbackRegistry.add(a,c),b.messageParent(m.GETSTATE),""}}Object.keys(p).forEach(function(l){this[p[l]]=function(c){c=
c||a;var b=this.findField(l,c);c=d.call(this,l,c);return"undefined"!=typeof b?b:c()}},this);Object.keys(C).forEach(function(d){this[C[d]]=function(){return this.findField(d,a)||{}}},this)}},{"../../utils/enums":15}],8:[function(d,a,f){(function(d){var f=!!d.postMessage;a.exports={postMessage:function(a,d,q){var l=1;d&&(f?q.postMessage(a,d.replace(/([^:]+:\/\/[^\/]+).*/,"$1")):d&&(q.location=d.replace(/#.*$/,"")+"#"+ +new Date+l++ +"\x26"+a))},receiveMessage:function(a,l){var q;try{f&&(a&&(q=function(d){return!("string"==
typeof l&&d.origin!==l||"[object Function]"===Object.prototype.toString.call(l)&&!1===l(d.origin))&&void a(d)}),d.addEventListener?d[a?"addEventListener":"removeEventListener"]("message",q):d[a?"attachEvent":"detachEvent"]("onmessage",q))}catch(F){}}}}).call(this,"undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],9:[function(d,a,f){(function(d){a.exports=function(a,
f){return{corsMetadata:function(){var a="none",f=!0;return"undefined"!=typeof XMLHttpRequest&&XMLHttpRequest===Object(XMLHttpRequest)&&("withCredentials"in new XMLHttpRequest?a="XMLHttpRequest":"undefined"!=typeof XDomainRequest&&XDomainRequest===Object(XDomainRequest)&&(f=!1),0<Object.prototype.toString.call(d.HTMLElement).indexOf("Constructor")&&(f=!1)),{corsType:a,corsCookiesEnabled:f}}(),getCORSInstance:function(){return"none"===this.corsMetadata.corsType?null:new d[this.corsMetadata.corsType]},
fireCORS:function(f,q,p){var c=this;q&&(f.loadErrorHandler=q);try{var b=this.getCORSInstance();b.open("get",f.corsUrl+"\x26ts\x3d"+(new Date).getTime(),!0);"XMLHttpRequest"===this.corsMetadata.corsType&&(b.withCredentials=!0,b.timeout=a.loadTimeout,b.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),b.onreadystatechange=function(){if(4===this.readyState&&200===this.status)a:{var a;try{if(a=JSON.parse(this.responseText),a!==Object(a)){c.handleCORSError(f,null,"Response is not JSON");
break a}}catch(Ca){c.handleCORSError(f,Ca,"Error parsing response as JSON");break a}try{for(var b=f.callback,n=d,B=0;B<b.length;B++)n=n[b[B]];n(a)}catch(Ca){c.handleCORSError(f,Ca,"Error forming callback function")}}});b.onerror=function(a){c.handleCORSError(f,a,"onerror")};b.ontimeout=function(a){c.handleCORSError(f,a,"ontimeout")};b.send();a._log.requests.push(f.corsUrl)}catch(g){this.handleCORSError(f,g,"try-catch")}},handleCORSError:function(d,f,p){a.CORSErrors.push({corsData:d,error:f,description:p});
d.loadErrorHandler&&("ontimeout"===p?d.loadErrorHandler(!0):d.loadErrorHandler(!1))}}}}).call(this,"undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],10:[function(d,a,f){(function(f){var p=d("../utils/constants"),m=d("./crossDomain"),l=d("../utils/utils");a.exports=function(a,d){var c=f.document;return{THROTTLE_START:3E4,MAX_SYNCS_LENGTH:649,throttleTimerSet:!1,
id:null,onPagePixels:[],iframeHost:null,getIframeHost:function(a){if("string"==typeof a)return a=a.split("/"),a[0]+"//"+a[2]},subdomain:null,url:null,getUrl:function(){var b,g="http://fast.",k="?d_nsid\x3d"+a.idSyncContainerID+"#"+encodeURIComponent(c.location.href);return this.subdomain||(this.subdomain="nosubdomainreturned"),a.loadSSL&&(g=a.idSyncSSLUseAkamai?"https://fast.":"https://"),b=g+this.subdomain+".demdex.net/dest5.html"+k,this.iframeHost=this.getIframeHost(b),this.id="destination_publishing_iframe_"+
this.subdomain+"_"+a.idSyncContainerID,b},checkDPIframeSrc:function(){var b="?d_nsid\x3d"+a.idSyncContainerID+"#"+encodeURIComponent(c.location.href);"string"==typeof a.dpIframeSrc&&a.dpIframeSrc.length&&(this.id="destination_publishing_iframe_"+(a._subdomain||this.subdomain||(new Date).getTime())+"_"+a.idSyncContainerID,this.iframeHost=this.getIframeHost(a.dpIframeSrc),this.url=a.dpIframeSrc+b)},idCallNotProcesssed:null,doAttachIframe:!1,startedAttachingIframe:!1,iframeHasLoaded:null,iframeIdChanged:null,
newIframeCreated:null,originalIframeHasLoadedAlready:null,regionChanged:!1,timesRegionChanged:0,sendingMessages:!1,messages:[],messagesPosted:[],messagesReceived:[],messageSendingInterval:p.POST_MESSAGE_ENABLED?null:100,jsonForComparison:[],jsonDuplicates:[],jsonWaiting:[],jsonProcessed:[],canSetThirdPartyCookies:!0,receivedThirdPartyCookiesNotification:!1,readyToAttachIframe:function(){return!a.idSyncDisable3rdPartySyncing&&(this.doAttachIframe||a._doAttachIframe)&&(this.subdomain&&"nosubdomainreturned"!==
this.subdomain||a._subdomain)&&this.url&&!this.startedAttachingIframe},attachIframe:function(){function a(){n=c.createElement("iframe");n.sandbox="allow-scripts allow-same-origin";n.title="Adobe ID Syncing iFrame";n.id=k.id;n.name=k.id+"_name";n.style.cssText="display: none; width: 0; height: 0;";n.src=k.url;k.newIframeCreated=!0;g();c.body.appendChild(n)}function g(){n.addEventListener("load",function(){n.className="aamIframeLoaded";k.iframeHasLoaded=!0;k.requestToProcess()})}this.startedAttachingIframe=
!0;var k=this,n=c.getElementById(this.id);n?"IFRAME"!==n.nodeName?(this.id+="_2",this.iframeIdChanged=!0,a()):(this.newIframeCreated=!1,"aamIframeLoaded"!==n.className?(this.originalIframeHasLoadedAlready=!1,g()):(this.originalIframeHasLoadedAlready=!0,this.iframeHasLoaded=!0,this.iframe=n,this.requestToProcess())):a();this.iframe=n},requestToProcess:function(b){function c(){n.jsonForComparison.push(b);n.jsonWaiting.push(b);n.processSyncOnPage(b)}var k,n=this;if(b===Object(b)&&b.ibs)if(k=JSON.stringify(b.ibs||
[]),this.jsonForComparison.length){var d,f,l=!1;var m=0;for(d=this.jsonForComparison.length;m<d;m++)if(f=this.jsonForComparison[m],k===JSON.stringify(f.ibs||[])){l=!0;break}l?this.jsonDuplicates.push(b):c()}else c();(this.receivedThirdPartyCookiesNotification||!p.POST_MESSAGE_ENABLED||this.iframeHasLoaded)&&this.jsonWaiting.length&&(k=this.jsonWaiting.shift(),this.process(k),this.requestToProcess());!a.idSyncDisableSyncs&&this.iframeHasLoaded&&this.messages.length&&!this.sendingMessages&&(this.throttleTimerSet||
(this.throttleTimerSet=!0,setTimeout(function(){n.messageSendingInterval=p.POST_MESSAGE_ENABLED?null:150},this.THROTTLE_START)),this.sendingMessages=!0,this.sendMessages())},getRegionAndCheckIfChanged:function(b,c){var g=a._getField("MCAAMLH");b=b.d_region||b.dcs_region;return g?b&&(a._setFieldExpire("MCAAMLH",c),a._setField("MCAAMLH",b),parseInt(g,10)!==b&&(this.regionChanged=!0,this.timesRegionChanged++,a._setField("MCSYNCSOP",""),a._setField("MCSYNCS",""),g=b)):(g=b,g&&(a._setFieldExpire("MCAAMLH",
c),a._setField("MCAAMLH",g))),g||(g=""),g},processSyncOnPage:function(a){var b,c;if((b=a.ibs)&&b instanceof Array&&(c=b.length))for(a=0;a<c;a++){var n=b[a];n.syncOnPage&&this.checkFirstPartyCookie(n,"","syncOnPage")}},process:function(a){var b,c,n,d=encodeURIComponent,f=!1;if((b=a.ibs)&&b instanceof Array&&(c=b.length))for(f=!0,n=0;n<c;n++){var p=b[n];var m=[d("ibs"),d(p.id||""),d(p.tag||""),l.encodeAndBuildRequest(p.url||[],","),d(p.ttl||""),"","",p.fireURLSync?"true":"false"];p.syncOnPage||(this.canSetThirdPartyCookies?
this.addMessage(m.join("|")):p.fireURLSync&&this.checkFirstPartyCookie(p,m.join("|")))}f&&this.jsonProcessed.push(a)},checkFirstPartyCookie:function(b,c,k){var g=(k="syncOnPage"===k)?"MCSYNCSOP":"MCSYNCS";a._readVisitor();var d,f,l=a._getField(g),m=!1,v=!1,C=Math.ceil((new Date).getTime()/p.MILLIS_PER_DAY);l?(d=l.split("*"),f=this.pruneSyncData(d,b.id,C),m=f.dataPresent,v=f.dataValid,m&&v||this.fireSync(k,b,c,d,g,C)):(d=[],this.fireSync(k,b,c,d,g,C))},pruneSyncData:function(a,c,k){var b,g=!1,d=!1;
for(b=0;b<a.length;b++){var f=a[b];var l=parseInt(f.split("-")[1],10);f.match("^"+c+"-")?(g=!0,k<l?d=!0:(a.splice(b,1),b--)):k>=l&&(a.splice(b,1),b--)}return{dataPresent:g,dataValid:d}},manageSyncsSize:function(a){if(a.join("*").length>this.MAX_SYNCS_LENGTH)for(a.sort(function(a,b){return parseInt(a.split("-")[1],10)-parseInt(b.split("-")[1],10)});a.join("*").length>this.MAX_SYNCS_LENGTH;)a.shift()},fireSync:function(b,c,k,n,d,f){var g=this;if(b){if("img"===c.tag){var l=c.url,B=a.loadSSL?"https:":
"http:";b=0;for(k=l.length;b<k;b++){n=l[b];var p=/^\/\//.test(n);var m=new Image;m.addEventListener("load",function(b,c,k,e){return function(){g.onPagePixels[b]=null;a._readVisitor();var n=a._getField(d);var f=[];if(n){n=n.split("*");var l;var B=0;for(l=n.length;B<l;B++){var p=n[B];p.match("^"+c.id+"-")||f.push(p)}}g.setSyncTrackingData(f,c,k,e)}}(this.onPagePixels.length,c,d,f));m.src=(p?B:"")+n;this.onPagePixels.push(m)}}}else this.addMessage(k),this.setSyncTrackingData(n,c,d,f)},addMessage:function(b){var c=
encodeURIComponent(a._enableErrorReporting?"---destpub-debug---":"---destpub---");this.messages.push((p.POST_MESSAGE_ENABLED?"":c)+b)},setSyncTrackingData:function(b,c,k,n){b.push(c.id+"-"+(n+Math.ceil(c.ttl/60/24)));this.manageSyncsSize(b);a._setField(k,b.join("*"))},sendMessages:function(){var a,c=this,k="",n=encodeURIComponent;this.regionChanged&&(k=n("---destpub-clear-dextp---"),this.regionChanged=!1);this.messages.length?p.POST_MESSAGE_ENABLED?(a=k+n("---destpub-combined---")+this.messages.join("%01"),
this.postMessage(a),this.messages=[],this.sendingMessages=!1):(a=this.messages.shift(),this.postMessage(k+a),setTimeout(function(){c.sendMessages()},this.messageSendingInterval)):this.sendingMessages=!1},postMessage:function(a){m.postMessage(a,this.url,this.iframe.contentWindow);this.messagesPosted.push(a)},receiveMessage:function(a){var b,c=/^---destpub-to-parent---/;"string"==typeof a&&c.test(a)&&(b=a.replace(c,"").split("|"),"canSetThirdPartyCookies"===b[0]&&(this.canSetThirdPartyCookies="true"===
b[1],this.receivedThirdPartyCookiesNotification=!0,this.requestToProcess()),this.messagesReceived.push(a))},processIDCallData:function(b){(null==this.url||b.subdomain&&"nosubdomainreturned"===this.subdomain)&&("string"==typeof a._subdomain&&a._subdomain.length?this.subdomain=a._subdomain:this.subdomain=b.subdomain||"",this.url=this.getUrl());b.ibs instanceof Array&&b.ibs.length&&(this.doAttachIframe=!0);this.readyToAttachIframe()&&(a.idSyncAttachIframeOnWindowLoad?(d.windowLoaded||"complete"===c.readyState||
"loaded"===c.readyState)&&this.attachIframe():this.attachIframeASAP());"function"==typeof a.idSyncIDCallResult?a.idSyncIDCallResult(b):this.requestToProcess(b);"function"==typeof a.idSyncAfterIDCallResult&&a.idSyncAfterIDCallResult(b)},canMakeSyncIDCall:function(b,c){return a._forceSyncIDCall||!b||c-b>p.DAYS_BETWEEN_SYNC_ID_CALLS},attachIframeASAP:function(){function a(){g.startedAttachingIframe||(c.body?g.attachIframe():setTimeout(a,30))}var g=this;a()}}}}).call(this,"undefined"!=typeof window&&
"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{"../utils/constants":14,"../utils/utils":18,"./crossDomain":8}],11:[function(d,a,f){function m(a,d){if(a===d)return 0;a=a.toString().split(".");d=d.toString().split(".");a:{var f=a.concat(d);for(var m=/^\d+$/,p=0,c=f.length;p<c;p++)if(!m.test(f[p])){f=!1;break a}f=!0}if(f){for(;a.length<d.length;)a.push("0");for(;d.length<a.length;)d.push("0");
a:{for(f=0;f<a.length;f++){m=parseInt(a[f],10);p=parseInt(d[f],10);if(m>p){a=1;break a}if(p>m){a=-1;break a}}a=0}}else a=NaN;return a}a.exports={compare:m,isLessThan:function(a,d){return 0>m(a,d)},areVersionsDifferent:function(a,d){return 0!==m(a,d)},isGreaterThan:function(a,d){return 0<m(a,d)},isEqual:function(a,d){return 0===m(a,d)}}},{}],12:[function(d,a,f){a.exports=function(a,d){function f(a){return function(b){l[a]=b;m++;m===p&&d(l)}}var l={},m=0,p=Object.keys(a).length;Object.keys(a).forEach(function(c){var b=
a[c];if(b.fn){var g=b.args||[];g.unshift(f(c));b.fn.apply(b.context||null,g)}})}},{}],13:[function(d,a,f){var m=d("./utils");a.exports=function(){return{callbacks:{},add:function(a,d){this.callbacks[a]=this.callbacks[a]||[];var f=this.callbacks[a].push(d)-1;return function(){this.callbacks[a].splice(f,1)}},execute:function(a,d){if(this.callbacks[a]){d="undefined"==typeof d?[]:d;d=d instanceof Array?d:[d];try{for(;this.callbacks[a].length;){var f=this.callbacks[a].shift();"function"==typeof f?f.apply(null,
d):f instanceof Array&&f[1].apply(f[0],d)}delete this.callbacks[a]}catch(q){}}},executeAll:function(a,d){(d||a&&!m.isObjectEmpty(a))&&Object.keys(this.callbacks).forEach(function(d){this.execute(d,void 0!==a[d]?a[d]:"")},this)},hasCallbacks:function(){return!!Object.keys(this.callbacks).length}}}},{"./utils":18}],14:[function(d,a,f){a.exports={POST_MESSAGE_ENABLED:!!("undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=
typeof self?self:"undefined"!=typeof window?window:{}).postMessage,DAYS_BETWEEN_SYNC_ID_CALLS:1,MILLIS_PER_DAY:864E5,ADOBE_MC:"adobe_mc",ADOBE_MC_SDID:"adobe_mc_sdid",VALID_VISITOR_ID_REGEX:/^[0-9a-fA-F\-]+$/,ADOBE_MC_TTL_IN_MIN:5,VERSION_REGEX:/vVersion\|((\d+\.)?(\d+\.)?(\*|\d+))(?=$|\|)/}},{}],15:[function(d,a,f){f.MESSAGES={HANDSHAKE:"HANDSHAKE",GETSTATE:"GETSTATE",PARENTSTATE:"PARENTSTATE"};f.STATE_KEYS_MAP={MCMID:"MCMID",MCAID:"MCAID",MCAAMB:"MCAAMB",MCAAMLH:"MCAAMLH",MCOPTOUT:"MCOPTOUT",CUSTOMERIDS:"CUSTOMERIDS"};
f.ASYNC_API_MAP={MCMID:"getMarketingCloudVisitorID",MCAID:"getAnalyticsVisitorID",MCAAMB:"getAudienceManagerBlob",MCAAMLH:"getAudienceManagerLocationHint",MCOPTOUT:"getOptOut"};f.SYNC_API_MAP={CUSTOMERIDS:"getCustomerIDs"};f.ALL_APIS={MCMID:"getMarketingCloudVisitorID",MCAAMB:"getAudienceManagerBlob",MCAAMLH:"getAudienceManagerLocationHint",MCOPTOUT:"getOptOut",MCAID:"getAnalyticsVisitorID",CUSTOMERIDS:"getCustomerIDs"};f.FIELDGROUP_TO_FIELD={MC:"MCMID",A:"MCAID",AAM:"MCAAMB"};f.FIELDS={MCMID:"MCMID",
MCOPTOUT:"MCOPTOUT",MCAID:"MCAID",MCAAMLH:"MCAAMLH",MCAAMB:"MCAAMB"};f.AUTH_STATE={UNKNOWN:0,AUTHENTICATED:1,LOGGED_OUT:2};f.OPT_OUT={GLOBAL:"global"}},{}],16:[function(d,a,f){(function(d){a.exports=function(a){var f;if(!a&&d.location&&(a=d.location.hostname),f=a)if(/^[0-9.]+$/.test(f))f="";else{a=f.split(".");var l=a.length-1,m=l-1;if(1<l&&2>=a[l].length&&(2===a[l-1].length||0>",ac,ad,ae,af,ag,ai,al,am,an,ao,aq,ar,as,at,au,aw,ax,az,ba,bb,be,bf,bg,bh,bi,bj,bm,bo,br,bs,bt,bv,bw,by,bz,ca,cc,cd,cf,cg,ch,ci,cl,cm,cn,co,cr,cu,cv,cw,cx,cz,de,dj,dk,dm,do,dz,ec,ee,eg,es,et,eu,fi,fm,fo,fr,ga,gb,gd,ge,gf,gg,gh,gi,gl,gm,gn,gp,gq,gr,gs,gt,gw,gy,hk,hm,hn,hr,ht,hu,id,ie,im,in,io,iq,ir,is,it,je,jo,jp,kg,ki,km,kn,kp,kr,ky,kz,la,lb,lc,li,lk,lr,ls,lt,lu,lv,ly,ma,mc,md,me,mg,mh,mk,ml,mn,mo,mp,mq,mr,ms,mt,mu,mv,mw,mx,my,na,nc,ne,nf,ng,nl,no,nr,nu,nz,om,pa,pe,pf,ph,pk,pl,pm,pn,pr,ps,pt,pw,py,qa,re,ro,rs,ru,rw,sa,sb,sc,sd,se,sg,sh,si,sj,sk,sl,sm,sn,so,sr,st,su,sv,sx,sy,sz,tc,td,tf,tg,th,tj,tk,tl,tm,tn,to,tp,tr,tt,tv,tw,tz,ua,ug,uk,us,uy,uz,va,vc,ve,vg,vi,vn,vu,wf,ws,yt,".indexOf(","+
a[l]+","))&&m--,0<m)for(f="";l>=m;)f=a[l]+(f?".":"")+f,l--}return f}}).call(this,"undefined"!=typeof window&&"undefined"!=typeof global&&window.global===global?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],17:[function(d,a,f){Object.assign=Object.assign||function(a){for(var d,f,l=1;l<arguments.length;++l)for(d in f=arguments[l],f)Object.prototype.hasOwnProperty.call(f,d)&&(a[d]=f[d]);return a}},{}],18:[function(d,a,f){f.isObjectEmpty=
function(a){return a===Object(a)&&0===Object.keys(a).length};f.isValueEmpty=function(a){return""===a||f.isObjectEmpty(a)};f.getIeVersion=function(){if(document.documentMode)return document.documentMode;for(var a=7;4<a;a--){var d=document.createElement("div");if(d.innerHTML="\x3c!--[if IE "+a+"]\x3e\x3cspan\x3e\x3c/span\x3e\x3c![endif]--\x3e",d.getElementsByTagName("span").length)return a}return null};f.encodeAndBuildRequest=function(a,d){return a.map(encodeURIComponent).join(d)}},{}],19:[function(d,
a,f){a.exports=function(a){var d="0123456789",f="",l="",m=8,F=10,c=10;if(1==a){d+="ABCDEF";for(a=0;16>a;a++){var b=Math.floor(Math.random()*m);f+=d.substring(b,b+1);b=Math.floor(Math.random()*m);l+=d.substring(b,b+1);m=16}return f+"-"+l}for(a=0;19>a;a++)b=Math.floor(Math.random()*F),f+=d.substring(b,b+1),0===a&&9==b?F=3:(1==a||2==a)&&10!=F&&2>b?F=10:2<a&&(F=10),b=Math.floor(Math.random()*c),l+=d.substring(b,b+1),0===a&&9==b?c=3:(1==a||2==a)&&10!=c&&2>b?c=10:2<a&&(c=10);return f+l}},{}]},{},[1]);
var visitor=Visitor.getInstance("29BE15F354E747F10A4C98A4@AdobeOrg",{trackingServer:"metrics.qatarairways.com",trackingServerSecure:"smetrics.qatarairways.com"}),visit_ID=visitor.getCustomerIDs();


/* AppMeasurement JS 2.9.0
Copyright 1996-2018 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com
Migration to AppMeasurement from s_code -Vengadesh*/
/************************ ADDITIONAL FEATURES ************************
     Plugins
*/

var s_account="qatarairwaysqrdev";
var hostName = window.location.hostname;
if(hostName=='ancillaries.qatarairways.com')	{
	s_account="qatarairwayscomprod";
}

var s=s_gi(s_account);
window['scode'] = s
//s=new AppMeasurement();
//s.account="qatarairwaysqrdev";

/************************** CONFIG SECTION **************************/
/* You may add or alter any code config here. */
/* charSet ISO-8859-1 */
s.charSet="ISO-8859-1"
/* Conversion Config */
s.currencyCode="USD"
/* Link Tracking Config */
s.trackDownloadLinks=true
s.trackExternalLinks=true
s.trackInlineStats=true
s.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx"
s.linkInternalFilters="javascript:,http://stg.qatarairways.com.qa,qatarairways.com"
s.linkLeaveQueryString=false
s.linkTrackVars="None"
s.linkTrackEvents="None"
/* Plugin Config */
s.usePlugins=true
s.visitor = Visitor.getInstance("29BE15F354E747F10A4C98A4@AdobeOrg");
//Channel Manager Settings
s._extraSearchEngines="voila.fr|rdata,kw|Voila>rechercher.aliceadsl.fr|qs|Aliceadsl.fr>toile.com|query,q|Toile du Quebec"
s._channelDomain="Social Networks|xanga.com,cafemom.com,yuku.com,hi5.com,bebo.com,ning.com,brightkite.com,tagged.com,mylife.com,myyearbook.com,classmates.com,smugmug.com,fotolog.com,photobucket.com,dailymotion.com,imeem.com,flickr.com,jaiku.com,identi.ca,zooomr.com,12seconds.tv,vimeo.com,youtube.com,flixster.com,diigo.com,mister-wong.com,netvibes.com,backtype.com,slideshare.net,plurk.com,intensedebate.com,disqus.com,tumblr.com,delicious.com,mixx.com,yelp.com,twine.com,stumbleupon.com,reddit.com,digg.com,myspace.com,friendfeed.com,wordpress.com,blogspot.com,livejournal.com,friendster.com,orkut.com,twitter.com,linkedin.com,facebook.com"
s._channelParameter="Search Center|s_kwcid"
s._channelPattern="Email|EM>Banner|BA>Partners|PA>Affiliates|AF>Social Networks|SM>Print|OF>Metasearch|TM>Microsite|MS"


function s_doPlugins(s) {
	/* Add calls to plugins here */

	      try{

s.pageURL= top.location.href;
s.prop20 = (typeof(Visitor) != "undefined" ? "VisitorAPI Present" : "VisitorAPI Missing");
      if(!s.campaign){
                   hu = top.location.href;
               gy = hu.split("&");
               for (i=0;i<gy.length;i++) {
                       ft = gy[i].split("=");
                       if (ft[0] == 'cid' || ft[0] == 'CID') {
                               s.campaign = ft[1];

                       }

               }

    }
    }catch(arr){}

	var kwcid=s.Util.getQueryParam('S_KWCID');
		 //console.log("kwcid---"+kwcid);
	if (!kwcid)
	{
	kwcid=s.Util.getQueryParam('s_kwcid');
	//console.log("kwcid small---"+kwcid);
	}
if (kwcid) {

        s.pageURL = top.location.href;
		//console.log("inside s_kwcid---"+s.pageURL);
    }


	/* Channel Manager */

	s.channelManager('CID','','c_m','','s_dl');

	/* Removing Direct Load Tracking */
	if(s._channel=="Direct Load") {
		s._referrer=s._referringDomain=s._campaign=s._keywords=s._channel=""}

	/* keyword encoding */
	s._keywords=decodeURI(s._keywords);

           var marque = new Array('quatar airlines','quatar airline','qtar airways','qtaar airways','qr airways','qatra airways','qatr airways','qatqr airways','qater airways','qater air ways','qater air','qatat airways','qatari airways','qatari airlines','qatari air','qatarairways','qatarairway','qatar ways','qatar irways','qatar arways','qatar aiways','qatar airwys','qatar airways','qatar airway','qatar airwas','qatar airwais','qatar airwa','qatar airlines','qatar airline','qatar airays','qatar air ways flight','qatar air ways','qatar air wayes','qatar air way','qatar air lines','qatar air line','qata airways','qaatr airways','qaar airways','katar airline','gulf airways qatar','evrs qatarairways','aqtar airways');

	/* separating brands from Organic Search */
        if (s._channel == 'Natural Search') {
            var i;
            for (i = 0; i < marque.length; i++) {
                if (s._keywords.indexOf(marque[i], 0) > -1) { s._channel = "Natural Search Brand"; }
            }
        }

        if (s._channel == 'Paid Non-Search') {
            s._partner = 'Paid:' + s._referringDomain;
            s._keywords = 'unknown';
        }
        if (s._channel == 'Natural Search') {
            //s._campaign = 'SEO:' + s._partner + ':' + s._keywords;
        }
        if (s._channel == 'Natural Search Brand') {
            //s._campaign = 'N:' + s._partner + ':' + s._keywords;
        }


        if (s._channel == 'Referrers') {
                if (s._referringDomain.indexOf("mail",0)>-1) {
                s._partner = 'webmail';

            }
                if ((s._referringDomain.indexOf("search",0)>-1)||(s._referringDomain.indexOf("recherche",0)>-1)) {
                s._channel = 'Natural Search';
                s._partner = 'Unknown Search Engine';

            }

        }

        if (s._channel == 'Referrers' || s._channel == 'Print' || s._channel == 'Affiliates' || s._channel == 'Banner' || s._channel == 'Partners' || s._channel == 'Social Networks')
            s._partner = s._channel + ":" + s._referringDomain;
        if (s._channel == 'Emailing')
            s._partner = s._channel;

      	/* changing the channel names */
      	if (s._channel == 'Paid Search') {s._channel="Paid Search";}



        /*Stacking tracking codes*/
        if (s._campaign == 'n/a') {
            s.stackedTrackingCodes = s.crossVisitParticipation('[' + s._channel + ']', 's_stc', '90', '3', '>', 'purchase');
        }
        else { s.stackedTrackingCodes = s.crossVisitParticipation(s._campaign, 's_stc', '90', '3', '>', 'purchase'); }

        /*Stacking Channels*/
        s.stackedChannels = s.crossVisitParticipation(s._channel, 's_schan', '90', '3', '>', 'purchase');

        /*Stacking Keywords*/
        if (s._keywords) {
            if (s._keywords != 'n/a') { s.stackedKeywords = s.crossVisitParticipation(s._keywords, 's_skw', '90', '5', '>', 'purchase'); }

        }

      	/* variables set up */
        //s.campaign = s._campaign;
        s.eVar21 = s._channel;
        s.eVar22 = s._partner;
        s.eVar23 = s._keywords;
        s.eVar24 = s._referringDomain;
        s.eVar25 = s.stackedTrackingCodes
        s.eVar26 = s.stackedChannels
        s.eVar27 = s.stackedKeywords


        if(!s.campaign)
           {
		   s.campaign=s.Util.getQueryParam('cid');
			//console.log("s.campaign small cid--"+s.campaign);

			}
			if(!s.campaign)
			 {
			 s.campaign=s.Util.getQueryParam('CID');
			//console.log("s.campaign--"+s.campaign);
			  }
			s.eVar15=s.Util.getQueryParam('iid');
			//console.log("s.eVar15--"+s.eVar15);
	 /*Capture Search Center Parameter*/
		 //***DO NOT MODIFY EVAR50 dedicated for Search Center purposes

	   if (kwcid!='') {
	   //  console.log("s.campaign kwcid");
	  s.campaign="PPC SearchCenter";
	  //console.log("s.campaign kwcid--"+s.campaign);
	 }
	   else {
	   if(s.campaign) {
	   s.eVar50="Other Campaigns";
	   }
	   }

	//Bounce Rate
	s.clickThruQuality('s_kwcid','event21','event22');






	/*Capture Search Center Parameter*/
	//***DO NOT MODIFY EVAR50 dedicated for Search Center purposes
  	if (kwcid !='') {
		s.campaign="PPC SearchCenter";
	}
  	else {
	  if(s.campaign) {
	  s.eVar50="Other Campaigns";
	  }
  	}


	/*PurchaseID in eVar */
    if (s.purchaseID) { s.eVar14 = s.purchaseID; }



/*Flight search Duplicate event for IBE Visit- Event14*/
/* 	if(s.events){
	if (s.events.indexOf("event1", 0) > -1) {
                  s.events = s.apl(s.events, 'event14', ',');}
	} */


 	/*New vs Returning*/
	//****MAKE SURE TO CHANGE PROP9 and evar17
	 s.prop9=s.getNewRepeat();
 	if (s.prop9) s.eVar17=s.prop9;



 	/*Time Parting*/
	//****MAKE SURE TO CHANGE PROP10/11/12 and eVar9
	//currDate = new Date();
	//s.prop10=s.getTimeParting('h','+1',currDate.getFullYear()) // Set hour
	//s.prop11=s.getTimeParting('d','+1',currDate.getFullYear()) // Set day
	//s.prop12=s.getTimeParting('w','+1',currDate.getFullYear()) // Set Weekend / Weekday

	//if(s.prop10&&s.prop11) s.eVar9= s.prop10 + '-' + s.prop11;

	s.eVar86  = s.pageName;
	s.eVar87  = window.location.href;
	s.events  = s.events?s.events+",event106":"event106";
	s.eVar88  = s.visitor.getMarketingCloudVisitorID();
  s.prop16  =  s.visitor.getMarketingCloudVisitorID();
}
s.doPlugins=s_doPlugins
/************************** PLUGINS SECTION *************************/
/* You may insert any plugins you wish to use here.                 */



/*
* Utility Function: vpr - set the variable vs with value v
*/
s.vpr = new Function("vs", "v",
"if(typeof(v)!='undefined'){var s=this; eval('s.'+vs+'=\"'+v+'\"')}");
/*
*	Plug-in: manageQueryParam v1.2 - Manages query string parameters
*	by either encoding, swapping, or both encoding and swapping a value.
*/
/* Plug-in Example: manageQueryParam v1.2
*/


//add page name to all events tracking



/*Prodview Duplicate- Event 3*/
if(s.events){
  if(s.events.indexOf("prodView",0 )!=-1){s.events=s.events?s.events+",event3":"event3";}
}

/*Flight search Duplicate event for IBE Visit- Event14*/
/* if(s.events){
  if(s.events.indexOf("event1",0 )!=-1){s.events=s.events?s.events+",event14":"even14";}
} */

/*s.manageQueryParam = new Function("p", "w", "e", "u", ""
+ "var s=this,x,y,i,qs,qp,qv,f,b;u=u?u:(s.pageURL?s.pageURL:''+s.wd.lo"
+ "cation);u=u=='f'?''+s.gtfs().location:u+'';x=u.indexOf('?');qs=x>-1"
+ "?u.substring(x,u.length):'';u=x>-1?u.substring(0,x):u;x=qs.indexOf("
+ "'?'+p+'=');if(x>-1){y=qs.indexOf('&');f='';if(y>-1){qp=qs.substring"
+ "(x+1,y);b=qs.substring(y+1,qs.length);}else{qp=qs.substring(1,qs.le"
+ "ngth);b='';}}else{x=qs.indexOf('&'+p+'=');if(x>-1){f=qs.substring(1"
+ ",x);b=qs.substring(x+1,qs.length);y=b.indexOf('&');if(y>-1){qp=b.su"
+ "bstring(0,y);b=b.substring(y,b.length);}else{qp=b;b='';}}}if(e&&qp)"
+ "{y=qp.indexOf('=');qv=y>-1?qp.substring(y+1,qp.length):'';var eui=0"
+ ";while(qv.indexOf('%25')>-1){qv=unescape(qv);eui++;if(eui==10)break"
+ ";}qv=s.rep(qv,'+',' ');qv=escape(qv);qv=s.rep(qv,'%25','%');qv=s.re"
+ "p(qv,'%7C','|');qv=s.rep(qv,'%7c','|');qp=qp.substring(0,y+1)+qv;}i"
+ "f(w&&qp){if(f)qs='?'+qp+'&'+f+b;else if(b)qs='?'+qp+'&'+b;else qs='"
+ "?'+qp}else if(f)qs='?'+f+'&'+qp+b;else if(b)qs='?'+qp+'&'+b;else if"
+ "(qp)qs='?'+qp;return u+qs;");*/

/*
* Plugin: getQueryParam 2.3 - return query string parameter(s)
* Omniture Consulting 18/06/2009: Amended to avoid using s.epa method
*/
/*s.getQueryParam= new Function("p", "d", "u", ""
+ "var s=this,v='',i,t;d=d?d:'';u=u?u:(s.pageURL?s.pageURL:s.wd.locati"
+ "on);if(u=='f')u=s.gtfs().location;while(p){i=p.indexOf(',');i=i<0?p"
+ ".length:i;t=s.p_gpv(p.substring(0,i),u+'');if(t){t=t.indexOf('#')>-"
+ "1?t.substring(0,t.indexOf('#')):t;}if(t)v+=v?d+t:t;p=p.substring(i="
+ "=p.length?i:i+1)}return v");
s.p_gpv = new Function("k", "u", ""
+ "var s=this,v='',i=u.indexOf('?'),q;if(k&&i>-1){q=u.substring(i+1);v"
+ "=s.pt(q,'&','p_gvf',k)}return v");
s.p_gvf = new Function("t", "k", ""
+ "if(t){var s=this,i=t.indexOf('='),p=i<0?t:t.substring(0,i),v=i<0?'T"
+ "rue':t.substring(i+1);if(p.toLowerCase()==k.toLowerCase()){v=s.rep(v,'+',' '); return v;}"
+ "}return ''");
*/


/*
 * Plugin: getValOnce_v1.0
 */
s.getValOnce=new Function("v","c","e",""
+"var s=this,a=new Date,v=v?v:v='',c=c?c:c='s_gvo',e=e?e:0,k=s.c_r(c"
+");if(v){a.setTime(a.getTime()+e*86400000);s.c_w(c,v,e?a:0);}return"
+" v==k?'':v");

/*
 * s.join: 1.0 - s.join(v,p)
 *
 *  v - Array (may also be array of array)
 *  p - formatting parameters (front, back, delim, wrap)
 *
 */

s.join = new Function("v","p",""
+"var s = this;var f,b,d,w;if(p){f=p.front?p.front:'';b=p.back?p.back"
+":'';d=p.delim?p.delim:'';w=p.wrap?p.wrap:'';}var str='';for(var x=0"
+";x<v.length;x++){if(typeof(v[x])=='object' )str+=s.join( v[x],p);el"
+"se str+=w+v[x]+w;if(x<v.length-1)str+=d;}return f+str+b;");


/*
 * Plugin: getPreviousValue_v1.0 - return previous value of designated
 *   variable (requires split utility)
 */
s.getPreviousValue=new Function("v","c","el",""
+"var s=this,t=new Date,i,j,r='';t.setTime(t.getTime()+1800000);if(el"
+"){if(s.events){i=s.split(el,',');j=s.split(s.events,',');for(x in i"
+"){for(y in j){if(i[x]==j[y]){if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t)"
+":s.c_w(c,'no value',t);return r}}}}}else{if(s.c_r(c)) r=s.c_r(c);v?"
+"s.c_w(c,v,t):s.c_w(c,'no value',t);return r}");


/*
 * Plugin: getNewRepeat 1.0 - Return whether user is new or repeat
 */
s.getNewRepeat=new Function(""
+"var s=this,e=new Date(),cval,ct=e.getTime(),y=e.getYear();e.setTime"
+"(ct+30*24*60*60*1000);cval=s.c_r('s_nr');if(cval.length==0){s.c_w("
+"'s_nr',ct,e);return 'New';}if(cval.length!=0&&ct-cval<30*60*1000){s"
+".c_w('s_nr',ct,e);return 'New';}if(cval<1123916400001){e.setTime(cv"
+"al+30*24*60*60*1000);s.c_w('s_nr',ct,e);return 'Repeat';}else retur"
+"n 'Repeat';");

/*
 * Plugin: getTimeParting 1.3 - Set timeparting values based on time zone
 */

s.getTimeParting=new Function("t","z","y",""
+"dc=new Date('1/1/2000');f=15;ne=8;if(dc.getDay()!=6||"
+"dc.getMonth()!=0){return'Data Not Available'}else{;z=parseInt(z);"
+"if(y=='2009'){f=8;ne=1};gmar=new Date('3/1/'+y);dsts=f-gmar.getDay("
+");gnov=new Date('11/1/'+y);dste=ne-gnov.getDay();spr=new Date('3/'"
+"+dsts+'/'+y);fl=new Date('11/'+dste+'/'+y);cd=new Date();"
+"if(cd>spr&&cd<fl){z=z+1}else{z=z};utc=cd.getTime()+(cd.getTimezoneO"
+"ffset()*60000);tz=new Date(utc + (3600000*z));thisy=tz.getFullYear("
+");var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Fr"
+"iday','Saturday'];if(thisy!=y){return'Data Not Available'}else{;thi"
+"sh=tz.getHours();thismin=tz.getMinutes();thisd=tz.getDay();var dow="
+"days[thisd];var ap='AM';var dt='Weekday';var mint='00';if(thismin>3"
+"0){mint='30'}if(thish>=12){ap='PM';thish=thish-12};if (thish==0){th"
+"ish=12};if(thisd==6||thisd==0){dt='Weekend'};var timestring=thish+'"
+":'+mint+ap;var daystring=dow;var endstring=dt;if(t=='h'){return tim"
+"estring}if(t=='d'){return daystring};if(t=='w'){return en"
+"dstring}}};"
);

/*
 * Utility Function: split v1.5 (JS 1.0 compatible)
 */
s.split=new Function("l","d",""
+"var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x"
+"++]=l.substring(0,i);l=l.substring(i+d.length);}return a");

/*
 * Plugin Utility: apl v1.1
 */
s.apl=new Function("l","v","d","u",""
+"var s=this,m=0;if(!l)l='';if(u){var i,n,a=s.split(l,d);for(i=0;i<a."
+"length;i++){n=a[i];m=m||(u==1?(n==v):(n.toLowerCase()==v.toLowerCas"
+"e()));}}if(!m)l=l?l+d+v:v;return l");


/*
 * Plugin: getVisitStart v2.0 - returns 1 on first page of visit
 * otherwise 0
 */
s.getVisitStart=new Function("c",""
+"var s=this,v=1,t=new Date;t.setTime(t.getTime()+1800000);if(s.c_r(c"
+")){v=0}if(!s.c_w(c,1,t)){s.c_w(c,1,0)}if(!s.c_r(c)){v=0}return v;");


s.clickThruQuality =new Function("scp","tcth_ev","cp_ev","cff_ev","cf_th",""
+"var s=this;if(s.p_fo('clickThruQuality')==1){var ev=s.events?s.even"
+"ts+',':'';if(s.Util.getQueryParam&&s.Util.getQueryParam(scp)){s.events=ev+tct"
+"h_ev;if(s.c_r('cf')){var tct=parseInt(s.c_r('cf'))+1;s.c_w('cf',tct"
+",0);if(tct==cf_th&&cff_ev){s.events=s.events+','+cff_ev;}}else {s.c"
+"_w('cf',1,0);}}else {if(s.c_r('cf')>=1){s.c_w('cf',0,0);s.events=ev"
+"+cp_ev;}}}");


s.p_fo=new Function("n",""
+"var s=this;if(!s.__fo){s.__fo=new Object;}if(!s.__fo[n]){s.__fo[n]="
+"new Object;return 1;}else {return 0;}");

/*
 * channelManager v2.4 - Tracking External Traffic
 */
s.channelManager=new Function("a","b","c","d","e","f",""
+"var s=this,A,B,g,l,m,M,p,q,P,h,k,u,S,i,O,T,j,r,t,D,E,F,G,H,N,U,v=0,"
+"X,Y,W,n=new Date;n.setTime(n.getTime()+1800000);if(e){v=1;if(s.c_r("
+"e)){v=0}if(!s.c_w(e,1,n)){s.c_w(e,1,0)}if(!s.c_r(e)){v=0}}g=s.refer"
+"rer?s.referrer:document.referrer;g=g.toLowerCase();;if(!g){h=1}i=g.i"
+"ndexOf('?')>-1?g.indexOf('?'):g.length;j=g.substring(0,i);k=s.linkI"
+"nternalFilters.toLowerCase();k=s.split(k,',');l=k.length;for(m=0;m<"
+"l;m++){B=j.indexOf(k[m])==-1?'':g;if(B)O=B}if(!O&&!h){p=g;U=g.index"
+"Of('//');q=U>-1?U+2:0;Y=g.indexOf('/',q);r=Y>-1?Y:i;t=g.substring(q"
+",r);t=t.toLowerCase();u=t;P='Referrers';S=s.seList+'>'+s._extraSear"
+"chEngines;if(d==1){j=s.repl(j,'oogle','%');j=s.repl(j,'ahoo','^');g"
+"=s.repl(g,'as_q','*')}A=s.split(S,'>');T=A.length;for(i=0;i<T;i++){"
+"D=A[i];D=s.split(D,'|');E=s.split(D[0],',');F=E.length;for(G=0;G<F;"
+"G++){H=j.indexOf(E[G]);if(H>-1){i=s.split(D[1],',');U=i.length;for("
+"k=0;k<U;k++){l=s.Util.getQueryParam(i[k],'',g);if(l){l=l.toLowerCase();M"
+"=l;if(D[2]){u=D[2];N=D[2]}else{N=t}if(d==1){N=s.repl(N,'#',' - ');g"
+"=s.repl(g,'*','as_q');N=s.repl(N,'^','ahoo');N=s.repl(N,'%','oogle'"
+");}}}}}}}if(!O||f!='1'){O=s.Util.getQueryParam(a,b);if(O){u=O;if(M){P='P"
+"aid Search'}else{P='Paid Non-Search';}}if(!O&&M){u=N;P='Natural Sea"
+"rch'}}if(h==1&&!O&&v==1){u=P=t=p='Direct Load'}X=M+u+t;c=c?c:'c_m';"
+"if(c!='0'){X=s.getValOnce(X,c,0);}g=s._channelDomain;if(g&&X){k=s.s"
+"plit(g,'>');l=k.length;for(m=0;m<l;m++){q=s.split(k[m],'|');r=s.spl"
+"it(q[1],',');S=r.length;for(T=0;T<S;T++){Y=r[T];Y=Y.toLowerCase();i"
+"=j.indexOf(Y);if(i>-1)P=q[0]}}}g=s._channelParameter;if(g&&X){k=s.s"
+"plit(g,'>');l=k.length;for(m=0;m<l;m++){q=s.split(k[m],'|');r=s.spl"
+"it(q[1],',');S=r.length;for(T=0;T<S;T++){U=s.Util.getQueryParam(r[T]);if"
+"(U)P=q[0]}}}g=s._channelPattern;if(g&&X){k=s.split(g,'>');l=k.lengt"
+"h;for(m=0;m<l;m++){q=s.split(k[m],'|');r=s.split(q[1],',');S=r.leng"
+"th;for(T=0;T<S;T++){Y=r[T];Y=Y.toLowerCase();i=O.toLowerCase();H=i."
+"indexOf(Y);if(H==0)P=q[0]}}}if(X)M=M?M:'n/a';p=X&&p?p:'';t=X&&t?t:'"
+"';N=X&&N?N:'';O=X&&O?O:'';u=X&&u?u:'';M=X&&M?M:'';P=X&&P?P:'';s._re"
+"ferrer=p;s._referringDomain=t;s._partner=N;s._campaignID=O;s._campa"
+"ign=u;s._keywords=M;s._channel=P");
/* Top 130 - Grouped */
s.seList="altavista.co,altavista.de|q,r|AltaVista>.aol.,suche.aolsvc"
+".de|q,query|AOL>ask.jp,ask.co|q,ask|Ask>www.baidu.com|wd|Baidu>daum"
+".net,search.daum.net|q|Daum>google.,googlesyndication.com|q,as_q|Go"
+"ogle>icqit.com|q|icq>bing.com|q|Microsoft Bing>myway.com|searchfor|"
+"MyWay.com>naver.com,search.naver.com|query|Naver>netscape.com|query"
+",search|Netscape Search>reference.com|q|Reference.com>seznam|w|Sezn"
+"am.cz>abcsok.no|q|Startsiden>tiscali.it,www.tiscali.co.uk|key,query"
+"|Tiscali>virgilio.it|qs|Virgilio>yahoo.com,yahoo.co.jp|p,va|Yahoo!>"
+"yandex|text|Yandex.ru>search.cnn.com|query|CNN Web Search>search.ea"
+"rthlink.net|q|Earthlink Search>search.comcast.net|q|Comcast Search>"
+"search.rr.com|qs|RoadRunner Search>optimum.net|q|Optimum Search";

/*
 *	Plug-in: crossVisitParticipation v1.5 - stacks values from
 *	specified variable in cookie and returns value
 */

s.crossVisitParticipation=new Function("v","cn","ex","ct","dl","ev","dv",""
+"var s=this,ce;if(typeof(dv)==='undefined')dv=0;if(s.events&&ev){var"
+" ay=s.split(ev,',');var ea=s.split(s.events,',');for(var u=0;u<ay.l"
+"ength;u++){for(var x=0;x<ea.length;x++){if(ay[u]==ea[x]){ce=1;}}}}i"
+"f(!v||v=='')return '';v=escape(v);var arry=new Array(),a=new Array("
+"),c=s.c_r(cn),g=0,h=new Array();if(c&&c!='')arry=eval(c);var e=new "
+"Date();e.setFullYear(e.getFullYear()+5);if(dv==0 && arry.length>0 &"
+"& arry[arry.length-1][0]==v)arry[arry.length-1]=[v, new Date().getT"
+"ime()];else arry[arry.length]=[v, new Date().getTime()];var start=a"
+"rry.length-ct<0?0:arry.length-ct;var td=new Date();for(var x=start;"
+"x<arry.length;x++){var diff=Math.round((td.getTime()-arry[x][1])/86"
+"400000);if(diff<ex){h[g]=unescape(arry[x][0]);a[g]=[arry[x][0],arry"
+"[x][1]];g++;}}var data=s.join(a,{delim:',',front:'[',back:']',wrap:"
+"\"'\"});s.c_w(cn,data,e);var r=s.join(h,{delim:dl});if(ce) s.c_w(cn"
+",'');return r;");






/* WARNING: Changing any of the below variables will cause drastic
changes to how your visitor data is collected.  Changes should only be
made when instructed to do so by your account manager.*/
s.visitorNamespace="qatarairways"
s.trackingServer="metrics.qatarairways.com"
s.trackingServerSecure="smetrics.qatarairways.com"






/*
 Start ActivityMap Module

 The following module enables ActivityMap tracking in Adobe Analytics. ActivityMap
 allows you to view data overlays on your links and content to understand how
 users engage with your web site. If you do not intend to use ActivityMap, you
 can remove the following block of code from your AppMeasurement.js file.
 Additional documentation on how to configure ActivityMap is available at:
 https://marketing.adobe.com/resources/help/en_US/analytics/activitymap/getting-started-admins.html
*/
function AppMeasurement_Module_ActivityMap(f){function g(a,d){var b,c,n;if(a&&d&&(b=e.c[d]||(e.c[d]=d.split(","))))for(n=0;n<b.length&&(c=b[n++]);)if(-1<a.indexOf(c))return null;p=1;return a}function q(a,d,b,c,e){var g,h;if(a.dataset&&(h=a.dataset[d]))g=h;else if(a.getAttribute)if(h=a.getAttribute("data-"+b))g=h;else if(h=a.getAttribute(b))g=h;if(!g&&f.useForcedLinkTracking&&e&&(g="",d=a.onclick?""+a.onclick:"")){b=d.indexOf(c);var l,k;if(0<=b){for(b+=10;b<d.length&&0<="= \t\r\n".indexOf(d.charAt(b));)b++;
if(b<d.length){h=b;for(l=k=0;h<d.length&&(";"!=d.charAt(h)||l);)l?d.charAt(h)!=l||k?k="\\"==d.charAt(h)?!k:0:l=0:(l=d.charAt(h),'"'!=l&&"'"!=l&&(l=0)),h++;if(d=d.substring(b,h))a.e=new Function("s","var e;try{s.w."+c+"="+d+"}catch(e){}"),a.e(f)}}}return g||e&&f.w[c]}function r(a,d,b){var c;return(c=e[d](a,b))&&(p?(p=0,c):g(k(c),e[d+"Exclusions"]))}function s(a,d,b){var c;if(a&&!(1===(c=a.nodeType)&&(c=a.nodeName)&&(c=c.toUpperCase())&&t[c])&&(1===a.nodeType&&(c=a.nodeValue)&&(d[d.length]=c),b.a||
b.t||b.s||!a.getAttribute||((c=a.getAttribute("alt"))?b.a=c:(c=a.getAttribute("title"))?b.t=c:"IMG"==(""+a.nodeName).toUpperCase()&&(c=a.getAttribute("src")||a.src)&&(b.s=c)),(c=a.childNodes)&&c.length))for(a=0;a<c.length;a++)s(c[a],d,b)}function k(a){if(null==a||void 0==a)return a;try{return a.replace(RegExp("^[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+","mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+$",
"mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]{1,}","mg")," ").substring(0,254)}catch(d){}}var e=this;e.s=f;var m=window;m.s_c_in||(m.s_c_il=[],m.s_c_in=0);e._il=m.s_c_il;e._in=m.s_c_in;e._il[e._in]=e;m.s_c_in++;e._c="s_m";e.c={};var p=0,t={SCRIPT:1,STYLE:1,LINK:1,CANVAS:1};e._g=function(){var a,d,b,c=f.contextData,e=f.linkObject;(a=f.pageName||f.pageURL)&&(d=r(e,"link",f.linkName))&&(b=r(e,"region"))&&(c["a.activitymap.page"]=a.substring(0,
255),c["a.activitymap.link"]=128<d.length?d.substring(0,128):d,c["a.activitymap.region"]=127<b.length?b.substring(0,127):b,c["a.activitymap.pageIDType"]=f.pageName?1:0)};e.link=function(a,d){var b;if(d)b=g(k(d),e.linkExclusions);else if((b=a)&&!(b=q(a,"sObjectId","s-object-id","s_objectID",1))){var c,f;(f=g(k(a.innerText||a.textContent),e.linkExclusions))||(s(a,c=[],b={a:void 0,t:void 0,s:void 0}),(f=g(k(c.join(""))))||(f=g(k(b.a?b.a:b.t?b.t:b.s?b.s:void 0)))||!(c=(c=a.tagName)&&c.toUpperCase?c.toUpperCase():
"")||("INPUT"==c||"SUBMIT"==c&&a.value?f=g(k(a.value)):"IMAGE"==c&&a.src&&(f=g(k(a.src)))));b=f}return b};e.region=function(a){for(var d,b=e.regionIDAttribute||"id";a&&(a=a.parentNode);){if(d=q(a,b,b,b))return d;if("BODY"==a.nodeName)return"BODY"}}}

/* End ActivityMap Module */
/*
 ============== DO NOT ALTER ANYTHING BELOW THIS LINE ! ===============

AppMeasurement for JavaScript version: 2.9.0
Copyright 1996-2016 Adobe, Inc. All Rights Reserved
More info available at http://www.adobe.com/marketing-cloud.html
*/
function AppMeasurement(r){var a=this;a.version="2.9.0";var k=window;k.s_c_in||(k.s_c_il=[],k.s_c_in=0);a._il=k.s_c_il;a._in=k.s_c_in;a._il[a._in]=a;k.s_c_in++;a._c="s_c";var p=k.AppMeasurement.Mb;p||(p=null);var n=k,m,s;try{for(m=n.parent,s=n.location;m&&m.location&&s&&""+m.location!=""+s&&n.location&&""+m.location!=""+n.location&&m.location.host==s.host;)n=m,m=n.parent}catch(u){}a.D=function(a){try{console.log(a)}catch(b){}};a.Ga=function(a){return""+parseInt(a)==""+a};a.replace=function(a,b,d){return!a||
0>a.indexOf(b)?a:a.split(b).join(d)};a.escape=function(c){var b,d;if(!c)return c;c=encodeURIComponent(c);for(b=0;7>b;b++)d="+~!*()'".substring(b,b+1),0<=c.indexOf(d)&&(c=a.replace(c,d,"%"+d.charCodeAt(0).toString(16).toUpperCase()));return c};a.unescape=function(c){if(!c)return c;c=0<=c.indexOf("+")?a.replace(c,"+"," "):c;try{return decodeURIComponent(c)}catch(b){}return unescape(c)};a.tb=function(){var c=k.location.hostname,b=a.fpCookieDomainPeriods,d;b||(b=a.cookieDomainPeriods);if(c&&!a.ya&&!/^[0-9.]+$/.test(c)&&
(b=b?parseInt(b):2,b=2<b?b:2,d=c.lastIndexOf("."),0<=d)){for(;0<=d&&1<b;)d=c.lastIndexOf(".",d-1),b--;a.ya=0<d?c.substring(d):c}return a.ya};a.c_r=a.cookieRead=function(c){c=a.escape(c);var b=" "+a.d.cookie,d=b.indexOf(" "+c+"="),f=0>d?d:b.indexOf(";",d);c=0>d?"":a.unescape(b.substring(d+2+c.length,0>f?b.length:f));return"[[B]]"!=c?c:""};a.c_w=a.cookieWrite=function(c,b,d){var f=a.tb(),e=a.cookieLifetime,g;b=""+b;e=e?(""+e).toUpperCase():"";d&&"SESSION"!=e&&"NONE"!=e&&((g=""!=b?parseInt(e?e:0):-60)?
(d=new Date,d.setTime(d.getTime()+1E3*g)):1==d&&(d=new Date,g=d.getYear(),d.setYear(g+5+(1900>g?1900:0))));return c&&"NONE"!=e?(a.d.cookie=a.escape(c)+"="+a.escape(""!=b?b:"[[B]]")+"; path=/;"+(d&&"SESSION"!=e?" expires="+d.toUTCString()+";":"")+(f?" domain="+f+";":""),a.cookieRead(c)==b):0};a.qb=function(){var c=a.Util.getIeVersion();"number"===typeof c&&10>c&&(a.unsupportedBrowser=!0,a.fb(a,function(){}))};a.fb=function(a,b){for(var d in a)a.hasOwnProperty(d)&&"function"===typeof a[d]&&(a[d]=b)};
a.L=[];a.ba=function(c,b,d){if(a.za)return 0;a.maxDelay||(a.maxDelay=250);var f=0,e=(new Date).getTime()+a.maxDelay,g=a.d.visibilityState,h=["webkitvisibilitychange","visibilitychange"];g||(g=a.d.webkitVisibilityState);if(g&&"prerender"==g){if(!a.ca)for(a.ca=1,d=0;d<h.length;d++)a.d.addEventListener(h[d],function(){var c=a.d.visibilityState;c||(c=a.d.webkitVisibilityState);"visible"==c&&(a.ca=0,a.delayReady())});f=1;e=0}else d||a.o("_d")&&(f=1);f&&(a.L.push({m:c,a:b,t:e}),a.ca||setTimeout(a.delayReady,
a.maxDelay));return f};a.delayReady=function(){var c=(new Date).getTime(),b=0,d;for(a.o("_d")?b=1:a.qa();0<a.L.length;){d=a.L.shift();if(b&&!d.t&&d.t>c){a.L.unshift(d);setTimeout(a.delayReady,parseInt(a.maxDelay/2));break}a.za=1;a[d.m].apply(a,d.a);a.za=0}};a.setAccount=a.sa=function(c){var b,d;if(!a.ba("setAccount",arguments))if(a.account=c,a.allAccounts)for(b=a.allAccounts.concat(c.split(",")),a.allAccounts=[],b.sort(),d=0;d<b.length;d++)0!=d&&b[d-1]==b[d]||a.allAccounts.push(b[d]);else a.allAccounts=
c.split(",")};a.foreachVar=function(c,b){var d,f,e,g,h="";e=f="";if(a.lightProfileID)d=a.P,(h=a.lightTrackVars)&&(h=","+h+","+a.ga.join(",")+",");else{d=a.g;if(a.pe||a.linkType)h=a.linkTrackVars,f=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(h=a[e].Kb,f=a[e].Jb));h&&(h=","+h+","+a.G.join(",")+",");f&&h&&(h+=",events,")}b&&(b=","+b+",");for(f=0;f<d.length;f++)e=d[f],(g=a[e])&&(!h||0<=h.indexOf(","+e+","))&&(!b||0<=b.indexOf(","+e+","))&&c(e,g)};a.q=function(c,
b,d,f,e){var g="",h,l,k,q,m=0;"contextData"==c&&(c="c");if(b){for(h in b)if(!(Object.prototype[h]||e&&h.substring(0,e.length)!=e)&&b[h]&&(!d||0<=d.indexOf(","+(f?f+".":"")+h+","))){k=!1;if(m)for(l=0;l<m.length;l++)h.substring(0,m[l].length)==m[l]&&(k=!0);if(!k&&(""==g&&(g+="&"+c+"."),l=b[h],e&&(h=h.substring(e.length)),0<h.length))if(k=h.indexOf("."),0<k)l=h.substring(0,k),k=(e?e:"")+l+".",m||(m=[]),m.push(k),g+=a.q(l,b,d,f,k);else if("boolean"==typeof l&&(l=l?"true":"false"),l){if("retrieveLightData"==
f&&0>e.indexOf(".contextData."))switch(k=h.substring(0,4),q=h.substring(4),h){case "transactionID":h="xact";break;case "channel":h="ch";break;case "campaign":h="v0";break;default:a.Ga(q)&&("prop"==k?h="c"+q:"eVar"==k?h="v"+q:"list"==k?h="l"+q:"hier"==k&&(h="h"+q,l=l.substring(0,255)))}g+="&"+a.escape(h)+"="+a.escape(l)}}""!=g&&(g+="&."+c)}return g};a.usePostbacks=0;a.wb=function(){var c="",b,d,f,e,g,h,l,k,q="",m="",n=e="";if(a.lightProfileID)b=a.P,(q=a.lightTrackVars)&&(q=","+q+","+a.ga.join(",")+
",");else{b=a.g;if(a.pe||a.linkType)q=a.linkTrackVars,m=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(q=a[e].Kb,m=a[e].Jb));q&&(q=","+q+","+a.G.join(",")+",");m&&(m=","+m+",",q&&(q+=",events,"));a.events2&&(n+=(""!=n?",":"")+a.events2)}if(a.visitor&&a.visitor.getCustomerIDs){e=p;if(g=a.visitor.getCustomerIDs())for(d in g)Object.prototype[d]||(f=g[d],"object"==typeof f&&(e||(e={}),f.id&&(e[d+".id"]=f.id),f.authState&&(e[d+".as"]=f.authState)));e&&(c+=a.q("cid",
e))}a.AudienceManagement&&a.AudienceManagement.isReady()&&(c+=a.q("d",a.AudienceManagement.getEventCallConfigParams()));for(d=0;d<b.length;d++){e=b[d];g=a[e];f=e.substring(0,4);h=e.substring(4);g||("events"==e&&n?(g=n,n=""):"marketingCloudOrgID"==e&&a.visitor&&(g=a.visitor.marketingCloudOrgID));if(g&&(!q||0<=q.indexOf(","+e+","))){switch(e){case "customerPerspective":e="cp";break;case "marketingCloudOrgID":e="mcorgid";break;case "supplementalDataID":e="sdid";break;case "timestamp":e="ts";break;case "dynamicVariablePrefix":e=
"D";break;case "visitorID":e="vid";break;case "marketingCloudVisitorID":e="mid";break;case "analyticsVisitorID":e="aid";break;case "audienceManagerLocationHint":e="aamlh";break;case "audienceManagerBlob":e="aamb";break;case "authState":e="as";break;case "pageURL":e="g";255<g.length&&(a.pageURLRest=g.substring(255),g=g.substring(0,255));break;case "pageURLRest":e="-g";break;case "referrer":e="r";break;case "vmk":case "visitorMigrationKey":e="vmt";break;case "visitorMigrationServer":e="vmf";a.ssl&&
a.visitorMigrationServerSecure&&(g="");break;case "visitorMigrationServerSecure":e="vmf";!a.ssl&&a.visitorMigrationServer&&(g="");break;case "charSet":e="ce";break;case "visitorNamespace":e="ns";break;case "cookieDomainPeriods":e="cdp";break;case "cookieLifetime":e="cl";break;case "variableProvider":e="vvp";break;case "currencyCode":e="cc";break;case "channel":e="ch";break;case "transactionID":e="xact";break;case "campaign":e="v0";break;case "latitude":e="lat";break;case "longitude":e="lon";break;
case "resolution":e="s";break;case "colorDepth":e="c";break;case "javascriptVersion":e="j";break;case "javaEnabled":e="v";break;case "cookiesEnabled":e="k";break;case "browserWidth":e="bw";break;case "browserHeight":e="bh";break;case "connectionType":e="ct";break;case "homepage":e="hp";break;case "events":n&&(g+=(""!=g?",":"")+n);if(m)for(h=g.split(","),g="",f=0;f<h.length;f++)l=h[f],k=l.indexOf("="),0<=k&&(l=l.substring(0,k)),k=l.indexOf(":"),0<=k&&(l=l.substring(0,k)),0<=m.indexOf(","+l+",")&&(g+=
(g?",":"")+h[f]);break;case "events2":g="";break;case "contextData":c+=a.q("c",a[e],q,e);g="";break;case "lightProfileID":e="mtp";break;case "lightStoreForSeconds":e="mtss";a.lightProfileID||(g="");break;case "lightIncrementBy":e="mti";a.lightProfileID||(g="");break;case "retrieveLightProfiles":e="mtsr";break;case "deleteLightProfiles":e="mtsd";break;case "retrieveLightData":a.retrieveLightProfiles&&(c+=a.q("mts",a[e],q,e));g="";break;default:a.Ga(h)&&("prop"==f?e="c"+h:"eVar"==f?e="v"+h:"list"==
f?e="l"+h:"hier"==f&&(e="h"+h,g=g.substring(0,255)))}g&&(c+="&"+e+"="+("pev"!=e.substring(0,3)?a.escape(g):g))}"pev3"==e&&a.e&&(c+=a.e)}a.fa&&(c+="&lrt="+a.fa,a.fa=null);return c};a.C=function(a){var b=a.tagName;if("undefined"!=""+a.Pb||"undefined"!=""+a.Fb&&"HTML"!=(""+a.Fb).toUpperCase())return"";b=b&&b.toUpperCase?b.toUpperCase():"";"SHAPE"==b&&(b="");b&&(("INPUT"==b||"BUTTON"==b)&&a.type&&a.type.toUpperCase?b=a.type.toUpperCase():!b&&a.href&&(b="A"));return b};a.Ca=function(a){var b=k.location,
d=a.href?a.href:"",f,e,g;f=d.indexOf(":");e=d.indexOf("?");g=d.indexOf("/");d&&(0>f||0<=e&&f>e||0<=g&&f>g)&&(e=a.protocol&&1<a.protocol.length?a.protocol:b.protocol?b.protocol:"",f=b.pathname.lastIndexOf("/"),d=(e?e+"//":"")+(a.host?a.host:b.host?b.host:"")+("/"!=d.substring(0,1)?b.pathname.substring(0,0>f?0:f)+"/":"")+d);return d};a.M=function(c){var b=a.C(c),d,f,e="",g=0;return b&&(d=c.protocol,f=c.onclick,!c.href||"A"!=b&&"AREA"!=b||f&&d&&!(0>d.toLowerCase().indexOf("javascript"))?f?(e=a.replace(a.replace(a.replace(a.replace(""+
f,"\r",""),"\n",""),"\t","")," ",""),g=2):"INPUT"==b||"SUBMIT"==b?(c.value?e=c.value:c.innerText?e=c.innerText:c.textContent&&(e=c.textContent),g=3):"IMAGE"==b&&c.src&&(e=c.src):e=a.Ca(c),e)?{id:e.substring(0,100),type:g}:0};a.Nb=function(c){for(var b=a.C(c),d=a.M(c);c&&!d&&"BODY"!=b;)if(c=c.parentElement?c.parentElement:c.parentNode)b=a.C(c),d=a.M(c);d&&"BODY"!=b||(c=0);c&&(b=c.onclick?""+c.onclick:"",0<=b.indexOf(".tl(")||0<=b.indexOf(".trackLink("))&&(c=0);return c};a.Eb=function(){var c,b,d=a.linkObject,
f=a.linkType,e=a.linkURL,g,h;a.ha=1;d||(a.ha=0,d=a.clickObject);if(d){c=a.C(d);for(b=a.M(d);d&&!b&&"BODY"!=c;)if(d=d.parentElement?d.parentElement:d.parentNode)c=a.C(d),b=a.M(d);b&&"BODY"!=c||(d=0);if(d&&!a.linkObject){var l=d.onclick?""+d.onclick:"";if(0<=l.indexOf(".tl(")||0<=l.indexOf(".trackLink("))d=0}}else a.ha=1;!e&&d&&(e=a.Ca(d));e&&!a.linkLeaveQueryString&&(g=e.indexOf("?"),0<=g&&(e=e.substring(0,g)));if(!f&&e){var m=0,q=0,n;if(a.trackDownloadLinks&&a.linkDownloadFileTypes)for(l=e.toLowerCase(),
g=l.indexOf("?"),h=l.indexOf("#"),0<=g?0<=h&&h<g&&(g=h):g=h,0<=g&&(l=l.substring(0,g)),g=a.linkDownloadFileTypes.toLowerCase().split(","),h=0;h<g.length;h++)(n=g[h])&&l.substring(l.length-(n.length+1))=="."+n&&(f="d");if(a.trackExternalLinks&&!f&&(l=e.toLowerCase(),a.Fa(l)&&(a.linkInternalFilters||(a.linkInternalFilters=k.location.hostname),g=0,a.linkExternalFilters?(g=a.linkExternalFilters.toLowerCase().split(","),m=1):a.linkInternalFilters&&(g=a.linkInternalFilters.toLowerCase().split(",")),g))){for(h=
0;h<g.length;h++)n=g[h],0<=l.indexOf(n)&&(q=1);q?m&&(f="e"):m||(f="e")}}a.linkObject=d;a.linkURL=e;a.linkType=f;if(a.trackClickMap||a.trackInlineStats)a.e="",d&&(f=a.pageName,e=1,d=d.sourceIndex,f||(f=a.pageURL,e=0),k.s_objectID&&(b.id=k.s_objectID,d=b.type=1),f&&b&&b.id&&c&&(a.e="&pid="+a.escape(f.substring(0,255))+(e?"&pidt="+e:"")+"&oid="+a.escape(b.id.substring(0,100))+(b.type?"&oidt="+b.type:"")+"&ot="+c+(d?"&oi="+d:"")))};a.xb=function(){var c=a.ha,b=a.linkType,d=a.linkURL,f=a.linkName;b&&(d||
f)&&(b=b.toLowerCase(),"d"!=b&&"e"!=b&&(b="o"),a.pe="lnk_"+b,a.pev1=d?a.escape(d):"",a.pev2=f?a.escape(f):"",c=1);a.abort&&(c=0);if(a.trackClickMap||a.trackInlineStats||a.Ab()){var b={},d=0,e=a.cookieRead("s_sq"),g=e?e.split("&"):0,h,l,k,e=0;if(g)for(h=0;h<g.length;h++)l=g[h].split("="),f=a.unescape(l[0]).split(","),l=a.unescape(l[1]),b[l]=f;f=a.account.split(",");h={};for(k in a.contextData)k&&!Object.prototype[k]&&"a.activitymap."==k.substring(0,14)&&(h[k]=a.contextData[k],a.contextData[k]="");
a.e=a.q("c",h)+(a.e?a.e:"");if(c||a.e){c&&!a.e&&(e=1);for(l in b)if(!Object.prototype[l])for(k=0;k<f.length;k++)for(e&&(g=b[l].join(","),g==a.account&&(a.e+=("&"!=l.charAt(0)?"&":"")+l,b[l]=[],d=1)),h=0;h<b[l].length;h++)g=b[l][h],g==f[k]&&(e&&(a.e+="&u="+a.escape(g)+("&"!=l.charAt(0)?"&":"")+l+"&u=0"),b[l].splice(h,1),d=1);c||(d=1);if(d){e="";h=2;!c&&a.e&&(e=a.escape(f.join(","))+"="+a.escape(a.e),h=1);for(l in b)!Object.prototype[l]&&0<h&&0<b[l].length&&(e+=(e?"&":"")+a.escape(b[l].join(","))+"="+
a.escape(l),h--);a.cookieWrite("s_sq",e)}}}return c};a.yb=function(){if(!a.Ib){var c=new Date,b=n.location,d,f,e=f=d="",g="",h="",l="1.2",k=a.cookieWrite("s_cc","true",0)?"Y":"N",m="",p="";if(c.setUTCDate&&(l="1.3",(0).toPrecision&&(l="1.5",c=[],c.forEach))){l="1.6";f=0;d={};try{f=new Iterator(d),f.next&&(l="1.7",c.reduce&&(l="1.8",l.trim&&(l="1.8.1",Date.parse&&(l="1.8.2",Object.create&&(l="1.8.5")))))}catch(r){}}d=screen.width+"x"+screen.height;e=navigator.javaEnabled()?"Y":"N";f=screen.pixelDepth?
screen.pixelDepth:screen.colorDepth;g=a.w.innerWidth?a.w.innerWidth:a.d.documentElement.offsetWidth;h=a.w.innerHeight?a.w.innerHeight:a.d.documentElement.offsetHeight;try{a.b.addBehavior("#default#homePage"),m=a.b.Ob(b)?"Y":"N"}catch(s){}try{a.b.addBehavior("#default#clientCaps"),p=a.b.connectionType}catch(t){}a.resolution=d;a.colorDepth=f;a.javascriptVersion=l;a.javaEnabled=e;a.cookiesEnabled=k;a.browserWidth=g;a.browserHeight=h;a.connectionType=p;a.homepage=m;a.Ib=1}};a.Q={};a.loadModule=function(c,
b){var d=a.Q[c];if(!d){d=k["AppMeasurement_Module_"+c]?new k["AppMeasurement_Module_"+c](a):{};a.Q[c]=a[c]=d;d.Za=function(){return d.eb};d.gb=function(b){if(d.eb=b)a[c+"_onLoad"]=b,a.ba(c+"_onLoad",[a,d],1)||b(a,d)};try{Object.defineProperty?Object.defineProperty(d,"onLoad",{get:d.Za,set:d.gb}):d._olc=1}catch(f){d._olc=1}}b&&(a[c+"_onLoad"]=b,a.ba(c+"_onLoad",[a,d],1)||b(a,d))};a.o=function(c){var b,d;for(b in a.Q)if(!Object.prototype[b]&&(d=a.Q[b])&&(d._olc&&d.onLoad&&(d._olc=0,d.onLoad(a,d)),d[c]&&
d[c]()))return 1;return 0};a.Ab=function(){return a.ActivityMap&&a.ActivityMap._c?!0:!1};a.Bb=function(){var c=Math.floor(1E13*Math.random()),b=a.visitorSampling,d=a.visitorSamplingGroup,d="s_vsn_"+(a.visitorNamespace?a.visitorNamespace:a.account)+(d?"_"+d:""),f=a.cookieRead(d);if(b){b*=100;f&&(f=parseInt(f));if(!f){if(!a.cookieWrite(d,c))return 0;f=c}if(f%1E4>b)return 0}return 1};a.R=function(c,b){var d,f,e,g,h,l;for(d=0;2>d;d++)for(f=0<d?a.ua:a.g,e=0;e<f.length;e++)if(g=f[e],(h=c[g])||c["!"+g]){if(!b&&
("contextData"==g||"retrieveLightData"==g)&&a[g])for(l in a[g])h[l]||(h[l]=a[g][l]);a[g]=h}};a.Qa=function(c,b){var d,f,e,g;for(d=0;2>d;d++)for(f=0<d?a.ua:a.g,e=0;e<f.length;e++)g=f[e],c[g]=a[g],b||c[g]||(c["!"+g]=1)};a.sb=function(a){var b,d,f,e,g,h=0,l,k="",m="";if(a&&255<a.length&&(b=""+a,d=b.indexOf("?"),0<d&&(l=b.substring(d+1),b=b.substring(0,d),e=b.toLowerCase(),f=0,"http://"==e.substring(0,7)?f+=7:"https://"==e.substring(0,8)&&(f+=8),d=e.indexOf("/",f),0<d&&(e=e.substring(f,d),g=b.substring(d),
b=b.substring(0,d),0<=e.indexOf("google")?h=",q,ie,start,search_key,word,kw,cd,":0<=e.indexOf("yahoo.co")&&(h=",p,ei,"),h&&l)))){if((a=l.split("&"))&&1<a.length){for(f=0;f<a.length;f++)e=a[f],d=e.indexOf("="),0<d&&0<=h.indexOf(","+e.substring(0,d)+",")?k+=(k?"&":"")+e:m+=(m?"&":"")+e;k&&m?l=k+"&"+m:m=""}d=253-(l.length-m.length)-b.length;a=b+(0<d?g.substring(0,d):"")+"?"+l}return a};a.Ta=function(c){var b=a.d.visibilityState,d=["webkitvisibilitychange","visibilitychange"];b||(b=a.d.webkitVisibilityState);
if(b&&"prerender"==b){if(c)for(b=0;b<d.length;b++)a.d.addEventListener(d[b],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);"visible"==b&&c()});return!1}return!0};a.X=!1;a.J=!1;a.ib=function(){a.J=!0;a.H()};a.Y=!1;a.S=!1;a.jb=function(c){a.marketingCloudVisitorID=c.MCMID;a.visitorOptedOut=c.MCOPTOUT;a.analyticsVisitorID=c.MCAID;a.audienceManagerLocationHint=c.MCAAMLH;a.audienceManagerBlob=c.MCAAMB;a.S=!0;a.H()};a.Sa=function(c){a.maxDelay||(a.maxDelay=250);return a.o("_d")?(c&&
setTimeout(function(){c()},a.maxDelay),!1):!0};a.W=!1;a.I=!1;a.qa=function(){a.I=!0;a.H()};a.isReadyToTrack=function(){var c=!0,b=a.visitor;a.X||a.J||(a.Ta(a.ib)?a.J=!0:a.X=!0);if(a.X&&!a.J)return!1;b&&b.isAllowed()&&(a.Y||a.marketingCloudVisitorID||!b.getVisitorValues||(a.Y=!0,a.marketingCloudVisitorID?a.S=!0:b.getVisitorValues(a.jb)),c=!a.Y||a.S||a.marketingCloudVisitorID?!0:!1);a.W||a.I||(a.Sa(a.qa)?a.I=!0:a.W=!0);a.W&&!a.I&&(c=!1);return c};a.l=p;a.r=0;a.callbackWhenReadyToTrack=function(c,b,
d){var f;f={};f.nb=c;f.mb=b;f.kb=d;a.l==p&&(a.l=[]);a.l.push(f);0==a.r&&(a.r=setInterval(a.H,100))};a.H=function(){var c;if(a.isReadyToTrack()&&(a.hb(),a.l!=p))for(;0<a.l.length;)c=a.l.shift(),c.mb.apply(c.nb,c.kb)};a.hb=function(){a.r&&(clearInterval(a.r),a.r=0)};a.ab=function(c){var b,d,f=p,e=p;if(!a.isReadyToTrack()){b=[];if(c!=p)for(d in f={},c)f[d]=c[d];e={};a.Qa(e,!0);b.push(f);b.push(e);a.callbackWhenReadyToTrack(a,a.track,b);return!0}return!1};a.ub=function(){var c=a.cookieRead("s_fid"),b=
"",d="",f;f=8;var e=4;if(!c||0>c.indexOf("-")){for(c=0;16>c;c++)f=Math.floor(Math.random()*f),b+="0123456789ABCDEF".substring(f,f+1),f=Math.floor(Math.random()*e),d+="0123456789ABCDEF".substring(f,f+1),f=e=16;c=b+"-"+d}a.cookieWrite("s_fid",c,1)||(c=0);return c};a.t=a.track=function(c,b){var d,f=new Date,e="s"+Math.floor(f.getTime()/108E5)%10+Math.floor(1E13*Math.random()),g=f.getYear(),g="t="+a.escape(f.getDate()+"/"+f.getMonth()+"/"+(1900>g?g+1900:g)+" "+f.getHours()+":"+f.getMinutes()+":"+f.getSeconds()+
" "+f.getDay()+" "+f.getTimezoneOffset());a.visitor&&a.visitor.getAuthState&&(a.authState=a.visitor.getAuthState());a.o("_s");a.ab(c)||(b&&a.R(b),c&&(d={},a.Qa(d,0),a.R(c)),a.Bb()&&!a.visitorOptedOut&&(a.analyticsVisitorID||a.marketingCloudVisitorID||(a.fid=a.ub()),a.Eb(),a.usePlugins&&a.doPlugins&&a.doPlugins(a),a.account&&(a.abort||(a.trackOffline&&!a.timestamp&&(a.timestamp=Math.floor(f.getTime()/1E3)),f=k.location,a.pageURL||(a.pageURL=f.href?f.href:f),a.referrer||a.Ra||(f=a.Util.getQueryParam("adobe_mc_ref",
null,null,!0),a.referrer=f||void 0===f?void 0===f?"":f:n.document.referrer),a.Ra=1,a.referrer=a.sb(a.referrer),a.o("_g")),a.xb()&&!a.abort&&(a.visitor&&!a.supplementalDataID&&a.visitor.getSupplementalDataID&&(a.supplementalDataID=a.visitor.getSupplementalDataID("AppMeasurement:"+a._in,a.expectSupplementalData?!1:!0)),a.yb(),g+=a.wb(),a.cb(e,g),a.o("_t"),a.referrer=""))),c&&a.R(d,1));a.abort=a.supplementalDataID=a.timestamp=a.pageURLRest=a.linkObject=a.clickObject=a.linkURL=a.linkName=a.linkType=k.s_objectID=
a.pe=a.pev1=a.pev2=a.pev3=a.e=a.lightProfileID=0};a.ta=[];a.registerPreTrackCallback=function(c){for(var b=[],d=1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.ta.push([c,b]):a.debugTracking&&a.D("DEBUG: Non function type passed to registerPreTrackCallback")};a.Wa=function(c){a.oa(a.ta,c)};a.ra=[];a.registerPostTrackCallback=function(c){for(var b=[],d=1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.ra.push([c,b]):a.debugTracking&&a.D("DEBUG: Non function type passed to registerPostTrackCallback")};
a.Va=function(c){a.oa(a.ra,c)};a.oa=function(c,b){if("object"==typeof c)for(var d=0;d<c.length;d++){var f=c[d][0],e=c[d][1].slice();e.unshift(b);if("function"==typeof f)try{f.apply(null,e)}catch(g){a.debugTracking&&a.D(g.message)}}};a.tl=a.trackLink=function(c,b,d,f,e){a.linkObject=c;a.linkType=b;a.linkName=d;e&&(a.k=c,a.v=e);return a.track(f)};a.trackLight=function(c,b,d,f){a.lightProfileID=c;a.lightStoreForSeconds=b;a.lightIncrementBy=d;return a.track(f)};a.clearVars=function(){var c,b;for(c=0;c<
a.g.length;c++)if(b=a.g[c],"prop"==b.substring(0,4)||"eVar"==b.substring(0,4)||"hier"==b.substring(0,4)||"list"==b.substring(0,4)||"channel"==b||"events"==b||"eventList"==b||"products"==b||"productList"==b||"purchaseID"==b||"transactionID"==b||"state"==b||"zip"==b||"campaign"==b)a[b]=void 0};a.tagContainerMarker="";a.cb=function(c,b){var d=a.Xa()+"/"+c+"?AQB=1&ndh=1&pf=1&"+(a.pa()?"callback=s_c_il["+a._in+"].doPostbacks&et=1&":"")+b+"&AQE=1";a.Wa(d);a.Ua(d);a.T()};a.Xa=function(){var c=a.Ya();return"http"+
(a.ssl?"s":"")+"://"+c+"/b/ss/"+a.account+"/"+(a.mobile?"5.":"")+(a.pa()?"10":"1")+"/JS-"+a.version+(a.Hb?"T":"")+(a.tagContainerMarker?"-"+a.tagContainerMarker:"")};a.pa=function(){return a.AudienceManagement&&a.AudienceManagement.isReady()||0!=a.usePostbacks};a.Ya=function(){var c=a.dc,b=a.trackingServer;b?a.trackingServerSecure&&a.ssl&&(b=a.trackingServerSecure):(c=c?(""+c).toLowerCase():"d1","d1"==c?c="112":"d2"==c&&(c="122"),b=a.$a()+"."+c+".2o7.net");return b};a.$a=function(){var c=a.visitorNamespace;
c||(c=a.account.split(",")[0],c=c.replace(/[^0-9a-z]/gi,""));return c};a.Pa=/{(%?)(.*?)(%?)}/;a.Lb=RegExp(a.Pa.source,"g");a.rb=function(c){if("object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=c.dests[b];if("string"==typeof d.c&&"aa."==d.id.substr(0,3))for(var f=d.c.match(a.Lb),e=0;e<f.length;++e){var g=f[e],h=g.match(a.Pa),k="";"%"==h[1]&&"timezone_offset"==h[2]?k=(new Date).getTimezoneOffset():"%"==h[1]&&"timestampz"==h[2]&&(k=a.vb());d.c=d.c.replace(g,a.escape(k))}}};a.vb=function(){var c=
new Date,b=new Date(6E4*Math.abs(c.getTimezoneOffset()));return a.j(4,c.getFullYear())+"-"+a.j(2,c.getMonth()+1)+"-"+a.j(2,c.getDate())+"T"+a.j(2,c.getHours())+":"+a.j(2,c.getMinutes())+":"+a.j(2,c.getSeconds())+(0<c.getTimezoneOffset()?"-":"+")+a.j(2,b.getUTCHours())+":"+a.j(2,b.getUTCMinutes())};a.j=function(a,b){return(Array(a+1).join(0)+b).slice(-a)};a.la={};a.doPostbacks=function(c){if("object"==typeof c)if(a.rb(c),"object"==typeof a.AudienceManagement&&"function"==typeof a.AudienceManagement.isReady&&
a.AudienceManagement.isReady()&&"function"==typeof a.AudienceManagement.passData)a.AudienceManagement.passData(c);else if("object"==typeof c&&"object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=c.dests[b];"object"==typeof d&&"string"==typeof d.c&&"string"==typeof d.id&&"aa."==d.id.substr(0,3)&&(a.la[d.id]=new Image,a.la[d.id].alt="",a.la[d.id].src=d.c)}};a.Ua=function(c){a.i||a.zb();a.i.push(c);a.ea=a.B();a.Na()};a.zb=function(){a.i=a.Cb();a.i||(a.i=[])};a.Cb=function(){var c,b;if(a.ka()){try{(b=
k.localStorage.getItem(a.ia()))&&(c=k.JSON.parse(b))}catch(d){}return c}};a.ka=function(){var c=!0;a.trackOffline&&a.offlineFilename&&k.localStorage&&k.JSON||(c=!1);return c};a.Da=function(){var c=0;a.i&&(c=a.i.length);a.p&&c++;return c};a.T=function(){if(a.p&&(a.A&&a.A.complete&&a.A.F&&a.A.na(),a.p))return;a.Ea=p;if(a.ja)a.ea>a.O&&a.La(a.i),a.ma(500);else{var c=a.lb();if(0<c)a.ma(c);else if(c=a.Aa())a.p=1,a.Db(c),a.Gb(c)}};a.ma=function(c){a.Ea||(c||(c=0),a.Ea=setTimeout(a.T,c))};a.lb=function(){var c;
if(!a.trackOffline||0>=a.offlineThrottleDelay)return 0;c=a.B()-a.Ja;return a.offlineThrottleDelay<c?0:a.offlineThrottleDelay-c};a.Aa=function(){if(0<a.i.length)return a.i.shift()};a.Db=function(c){if(a.debugTracking){var b="AppMeasurement Debug: "+c;c=c.split("&");var d;for(d=0;d<c.length;d++)b+="\n\t"+a.unescape(c[d]);a.D(b)}};a.bb=function(){return a.marketingCloudVisitorID||a.analyticsVisitorID};a.V=!1;var t;try{t=JSON.parse('{"x":"y"}')}catch(w){t=null}t&&"y"==t.x?(a.V=!0,a.U=function(a){return JSON.parse(a)}):
k.$&&k.$.parseJSON?(a.U=function(a){return k.$.parseJSON(a)},a.V=!0):a.U=function(){return null};a.Gb=function(c){var b,d,f;a.bb()&&2047<c.length&&("undefined"!=typeof XMLHttpRequest&&(b=new XMLHttpRequest,"withCredentials"in b?d=1:b=0),b||"undefined"==typeof XDomainRequest||(b=new XDomainRequest,d=2),b&&(a.AudienceManagement&&a.AudienceManagement.isReady()||0!=a.usePostbacks)&&(a.V?b.va=!0:b=0));!b&&a.Oa&&(c=c.substring(0,2047));!b&&a.d.createElement&&(0!=a.usePostbacks||a.AudienceManagement&&a.AudienceManagement.isReady())&&
(b=a.d.createElement("SCRIPT"))&&"async"in b&&((f=(f=a.d.getElementsByTagName("HEAD"))&&f[0]?f[0]:a.d.body)?(b.type="text/javascript",b.setAttribute("async","async"),d=3):b=0);b||(b=new Image,b.alt="",b.abort||"undefined"===typeof k.InstallTrigger||(b.abort=function(){b.src=p}));b.Ka=Date.now();b.xa=function(){try{b.F&&(clearTimeout(b.F),b.F=0)}catch(a){}};b.onload=b.na=function(){b.Ka&&(a.fa=Date.now()-b.Ka);a.Va(c);b.xa();a.pb();a.Z();a.p=0;a.T();if(b.va){b.va=!1;try{a.doPostbacks(a.U(b.responseText))}catch(d){}}};
b.onabort=b.onerror=b.Ba=function(){b.xa();(a.trackOffline||a.ja)&&a.p&&a.i.unshift(a.ob);a.p=0;a.ea>a.O&&a.La(a.i);a.Z();a.ma(500)};b.onreadystatechange=function(){4==b.readyState&&(200==b.status?b.na():b.Ba())};a.Ja=a.B();if(1==d||2==d){var e=c.indexOf("?");f=c.substring(0,e);e=c.substring(e+1);e=e.replace(/&callback=[a-zA-Z0-9_.\[\]]+/,"");1==d?(b.open("POST",f,!0),b.send(e)):2==d&&(b.open("POST",f),b.send(e))}else if(b.src=c,3==d){if(a.Ha)try{f.removeChild(a.Ha)}catch(g){}f.firstChild?f.insertBefore(b,
f.firstChild):f.appendChild(b);a.Ha=a.A}b.F=setTimeout(function(){b.F&&(b.complete?b.na():(a.trackOffline&&b.abort&&b.abort(),b.Ba()))},5E3);a.ob=c;a.A=k["s_i_"+a.replace(a.account,",","_")]=b;if(a.useForcedLinkTracking&&a.K||a.v)a.forcedLinkTrackingTimeout||(a.forcedLinkTrackingTimeout=250),a.aa=setTimeout(a.Z,a.forcedLinkTrackingTimeout)};a.pb=function(){if(a.ka()&&!(a.Ia>a.O))try{k.localStorage.removeItem(a.ia()),a.Ia=a.B()}catch(c){}};a.La=function(c){if(a.ka()){a.Na();try{k.localStorage.setItem(a.ia(),
k.JSON.stringify(c)),a.O=a.B()}catch(b){}}};a.Na=function(){if(a.trackOffline){if(!a.offlineLimit||0>=a.offlineLimit)a.offlineLimit=10;for(;a.i.length>a.offlineLimit;)a.Aa()}};a.forceOffline=function(){a.ja=!0};a.forceOnline=function(){a.ja=!1};a.ia=function(){return a.offlineFilename+"-"+a.visitorNamespace+a.account};a.B=function(){return(new Date).getTime()};a.Fa=function(a){a=a.toLowerCase();return 0!=a.indexOf("#")&&0!=a.indexOf("about:")&&0!=a.indexOf("opera:")&&0!=a.indexOf("javascript:")?!0:
!1};a.setTagContainer=function(c){var b,d,f;a.Hb=c;for(b=0;b<a._il.length;b++)if((d=a._il[b])&&"s_l"==d._c&&d.tagContainerName==c){a.R(d);if(d.lmq)for(b=0;b<d.lmq.length;b++)f=d.lmq[b],a.loadModule(f.n);if(d.ml)for(f in d.ml)if(a[f])for(b in c=a[f],f=d.ml[f],f)!Object.prototype[b]&&("function"!=typeof f[b]||0>(""+f[b]).indexOf("s_c_il"))&&(c[b]=f[b]);if(d.mmq)for(b=0;b<d.mmq.length;b++)f=d.mmq[b],a[f.m]&&(c=a[f.m],c[f.f]&&"function"==typeof c[f.f]&&(f.a?c[f.f].apply(c,f.a):c[f.f].apply(c)));if(d.tq)for(b=
0;b<d.tq.length;b++)a.track(d.tq[b]);d.s=a;break}};a.Util={urlEncode:a.escape,urlDecode:a.unescape,cookieRead:a.cookieRead,cookieWrite:a.cookieWrite,getQueryParam:function(c,b,d,f){var e,g="";b||(b=a.pageURL?a.pageURL:k.location);d=d?d:"&";if(!c||!b)return g;b=""+b;e=b.indexOf("?");if(0>e)return g;b=d+b.substring(e+1)+d;if(!f||!(0<=b.indexOf(d+c+d)||0<=b.indexOf(d+c+"="+d))){e=b.indexOf("#");0<=e&&(b=b.substr(0,e)+d);e=b.indexOf(d+c+"=");if(0>e)return g;b=b.substring(e+d.length+c.length+1);e=b.indexOf(d);
0<=e&&(b=b.substring(0,e));0<b.length&&(g=a.unescape(b));return g}},getIeVersion:function(){if(document.documentMode)return document.documentMode;for(var a=7;4<a;a--){var b=document.createElement("div");b.innerHTML="\x3c!--[if IE "+a+"]><span></span><![endif]--\x3e";if(b.getElementsByTagName("span").length)return a}return null}};a.G="supplementalDataID timestamp dynamicVariablePrefix visitorID marketingCloudVisitorID analyticsVisitorID audienceManagerLocationHint authState fid vmk visitorMigrationKey visitorMigrationServer visitorMigrationServerSecure charSet visitorNamespace cookieDomainPeriods fpCookieDomainPeriods cookieLifetime pageName pageURL customerPerspective referrer contextData currencyCode lightProfileID lightStoreForSeconds lightIncrementBy retrieveLightProfiles deleteLightProfiles retrieveLightData".split(" ");
a.g=a.G.concat("purchaseID variableProvider channel server pageType transactionID campaign state zip events events2 products audienceManagerBlob tnt".split(" "));a.ga="timestamp charSet visitorNamespace cookieDomainPeriods cookieLifetime contextData lightProfileID lightStoreForSeconds lightIncrementBy".split(" ");a.P=a.ga.slice(0);a.ua="account allAccounts debugTracking visitor visitorOptedOut trackOffline offlineLimit offlineThrottleDelay offlineFilename usePlugins doPlugins configURL visitorSampling visitorSamplingGroup linkObject clickObject linkURL linkName linkType trackDownloadLinks trackExternalLinks trackClickMap trackInlineStats linkLeaveQueryString linkTrackVars linkTrackEvents linkDownloadFileTypes linkExternalFilters linkInternalFilters useForcedLinkTracking forcedLinkTrackingTimeout trackingServer trackingServerSecure ssl abort mobile dc lightTrackVars maxDelay expectSupplementalData usePostbacks registerPreTrackCallback registerPostTrackCallback AudienceManagement".split(" ");
for(m=0;250>=m;m++)76>m&&(a.g.push("prop"+m),a.P.push("prop"+m)),a.g.push("eVar"+m),a.P.push("eVar"+m),6>m&&a.g.push("hier"+m),4>m&&a.g.push("list"+m);m="pe pev1 pev2 pev3 latitude longitude resolution colorDepth javascriptVersion javaEnabled cookiesEnabled browserWidth browserHeight connectionType homepage pageURLRest marketingCloudOrgID".split(" ");a.g=a.g.concat(m);a.G=a.G.concat(m);a.ssl=0<=k.location.protocol.toLowerCase().indexOf("https");a.charSet="UTF-8";a.contextData={};a.offlineThrottleDelay=
0;a.offlineFilename="AppMeasurement.offline";a.Ja=0;a.ea=0;a.O=0;a.Ia=0;a.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx";a.w=k;a.d=k.document;try{if(a.Oa=!1,navigator){var v=navigator.userAgent;if("Microsoft Internet Explorer"==navigator.appName||0<=v.indexOf("MSIE ")||0<=v.indexOf("Trident/")&&0<=v.indexOf("Windows NT 6"))a.Oa=!0}}catch(x){}a.Z=function(){a.aa&&(k.clearTimeout(a.aa),a.aa=p);a.k&&a.K&&a.k.dispatchEvent(a.K);a.v&&("function"==typeof a.v?a.v():
a.k&&a.k.href&&(a.d.location=a.k.href));a.k=a.K=a.v=0};a.Ma=function(){a.b=a.d.body;a.b?(a.u=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["s_fe_"+a._in])){if(a.wa)if(a.useForcedLinkTracking)a.b.removeEventListener("click",a.u,!1);else{a.b.removeEventListener("click",a.u,!0);a.wa=a.useForcedLinkTracking=0;return}else a.useForcedLinkTracking=0;a.clickObject=c.srcElement?c.srcElement:c.target;try{if(!a.clickObject||a.N&&a.N==a.clickObject||!(a.clickObject.tagName||a.clickObject.parentElement||
a.clickObject.parentNode))a.clickObject=0;else{var h=a.N=a.clickObject;a.da&&(clearTimeout(a.da),a.da=0);a.da=setTimeout(function(){a.N==h&&(a.N=0)},1E4);f=a.Da();a.track();if(f<a.Da()&&a.useForcedLinkTracking&&c.target){for(e=c.target;e&&e!=a.b&&"A"!=e.tagName.toUpperCase()&&"AREA"!=e.tagName.toUpperCase();)e=e.parentNode;if(e&&(g=e.href,a.Fa(g)||(g=0),d=e.target,c.target.dispatchEvent&&g&&(!d||"_self"==d||"_top"==d||"_parent"==d||k.name&&d==k.name))){try{b=a.d.createEvent("MouseEvents")}catch(l){b=
new k.MouseEvent}if(b){try{b.initMouseEvent("click",c.bubbles,c.cancelable,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget)}catch(m){b=0}b&&(b["s_fe_"+a._in]=b.s_fe=1,c.stopPropagation(),c.stopImmediatePropagation&&c.stopImmediatePropagation(),c.preventDefault(),a.k=c.target,a.K=b)}}}}}catch(n){a.clickObject=0}}},a.b&&a.b.attachEvent?a.b.attachEvent("onclick",a.u):a.b&&a.b.addEventListener&&(navigator&&(0<=navigator.userAgent.indexOf("WebKit")&&
a.d.createEvent||0<=navigator.userAgent.indexOf("Firefox/2")&&k.MouseEvent)&&(a.wa=1,a.useForcedLinkTracking=1,a.b.addEventListener("click",a.u,!0)),a.b.addEventListener("click",a.u,!1))):setTimeout(a.Ma,30)};a.qb();a.Qb||(r?a.setAccount(r):a.D("Error, missing Report Suite ID in AppMeasurement initialization"),a.Ma(),a.loadModule("ActivityMap"))}
function s_gi(r){var a,k=window.s_c_il,p,n,m=r.split(","),s,u,t=0;if(k)for(p=0;!t&&p<k.length;){a=k[p];if("s_c"==a._c&&(a.account||a.oun))if(a.account&&a.account==r)t=1;else for(n=a.account?a.account:a.oun,n=a.allAccounts?a.allAccounts:n.split(","),s=0;s<m.length;s++)for(u=0;u<n.length;u++)m[s]==n[u]&&(t=1);p++}t?a.setAccount&&a.setAccount(r):a=new AppMeasurement(r);return a}AppMeasurement.getInstance=s_gi;window.s_objectID||(window.s_objectID=0);
