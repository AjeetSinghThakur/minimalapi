export const environment = {
  production: false,
  bundlesOutputPath: 'assets/i18n',
  systemParamUrl: 'assets/config',
  userInteractivityTimeOut: 300000, // 5 minute inactivity timeout
  dropdownOptions: 10,
  ancillariesUrl: 'http://172.27.168.102:8088/ancillary-handshake-services/v2/ancillary',
  offerUrl: 'http://172.27.168.102:8088/ancillary-offer-services/v2/ancillary',
  externalUrls: {
    manageBookingUrl: 'https://nspuat.qatarairways.com.qa/nsp/views/retrievePnr.xhtml',
    manageBookingMobileUrl: 'https://nspuat.qatarairways.com.qa/nspMobile/manageBooking/search/showSearch.htm#s'
  }
};
