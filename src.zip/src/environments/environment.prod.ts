export const environment = {
  production: true,
  bundlesOutputPath: 'ancillaries/assets/i18n',
  systemParamUrl: 'ancillaries/assets/config',
  userInteractivityTimeOut: 1200000, // 20 minute inactivity timeout
  dropdownOptions: 10,
  ancillariesUrl: 'https://qoreservices.qatarairways.com/ancillary-services/v1/ancillary',
  externalUrls: {
    manageBookingUrl: 'https://booking.qatarairways.com/nsp/views/retrievePnr.xhtml',
    manageBookingMobileUrl: 'https://m.qatarairways.com/mobile/manageBooking/search/showSearch.htm#s'
  }
};
