export const environment = {
  production: false,
  bundlesOutputPath: 'ancillary/assets/i18n',
  systemParamUrl: 'ancillary/assets/config',
  userInteractivityTimeOut: 1200000, // 20 minute inactivity timeout
  dropdownOptions: 10,
  ancillariesUrl: 'https://qoreuat.qatarairways.com.qa/ancillary-services/v1/ancillary',
  externalUrls: {
    manageBookingUrl: 'https://nspuat.qatarairways.com.qa/nsp/views/retrievePnr.xhtml',
    manageBookingMobileUrl: 'https://nspuat.qatarairways.com.qa/nspMobile/manageBooking/search/showSearch.htm#s'
  }
};
