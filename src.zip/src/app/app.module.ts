import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreRouterConnectingModule, RouterState, RouterStateSerializer } from '@ngrx/router-store';
import { ToasterModule } from 'angular2-toaster';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateModule } from '@ngx-translate/core';
import { environment } from '@env/environment';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { translateLoaderProvider } from './shared/translations';
import { CustomSerializer } from './store/reducers/router.reducer';
import { ModalComponent } from './shared/components';
import { ROOT_REDUCERS, metaReducers } from './store/reducers';
import { RouterEffects, UserEffects, AncillariesEffects } from './store/effects';
import { RouterModule } from '@angular/router';
import { appRoutes } from './app.routing.module';
import { OnNavigationPreloadingStrategy } from './on-navigation-strategy.preloader';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ToasterModule.forRoot(),
    RouterModule.forRoot(appRoutes, {
    useHash: false,
    preloadingStrategy: OnNavigationPreloadingStrategy,
    scrollPositionRestoration: 'enabled',
    relativeLinkResolution: 'legacy'
}),
    TranslateModule.forRoot({ loader: translateLoaderProvider }),
    StoreModule.forRoot(ROOT_REDUCERS, {
      metaReducers: environment.production ? metaReducers : [],
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true,
        strictStateSerializability: true,
        strictActionSerializability: true,
      },
    }),
    EffectsModule.forRoot([
      RouterEffects,
      UserEffects,
      AncillariesEffects
    ]),
    CoreModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    !environment.production ? StoreDevtoolsModule.instrument({ maxAge: 25 }) : [],
    StoreRouterConnectingModule.forRoot({
      routerState: RouterState.Minimal
    })
  ],
  providers: [
    CookieService,
    { provide: RouterStateSerializer, useClass: CustomSerializer }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    ModalComponent,
  ],
})
export class AppModule {}
