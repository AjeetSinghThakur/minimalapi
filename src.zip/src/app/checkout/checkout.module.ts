import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { checkoutRoutes } from './checkout.routing';
import { SharedModule } from '@app/shared/shared.module';
import { ContentComponent } from '@app/checkout/container';
import { CheckoutItemComponent} from './presentational';
import { TotalpriceComponent} from './presentational';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(checkoutRoutes),
    SharedModule,
  ],
  exports: [],
  declarations: [
    ContentComponent,
    CheckoutItemComponent,
    TotalpriceComponent

  ],
  providers: [],
})
export class CheckoutModule {}
