import { Component, Input, Output, EventEmitter } from '@angular/core';
import { AnclillaryDetail } from '@app/models';

@Component({
  selector: 'qa-checkout-item',
  templateUrl: './checkout-item.component.html',
  styleUrls: ['./checkout-item.component.css'],
})
export class CheckoutItemComponent {
  
}

