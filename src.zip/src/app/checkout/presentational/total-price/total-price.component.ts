import { Component, OnInit, Input } from '@angular/core';
import { AmountOverView } from '@app/models';

@Component({
  selector: 'qa-total-price',
  templateUrl: './total-price.component.html',
  styleUrls: ['./total-price.component.css']
})
export class TotalpriceComponent implements OnInit {
  @Input() amountOverView: AmountOverView;

  ngOnInit(): void {
  }

}
