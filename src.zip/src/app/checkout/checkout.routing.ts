import { Routes } from '@angular/router';
import { ContentComponent } from './container';

export const checkoutRoutes: Routes = [{ path: '', component: ContentComponent }];
