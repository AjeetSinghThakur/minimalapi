import { Routes } from '@angular/router';
import { ContentComponent } from './container';

export const dashboardRoutes: Routes = [{ path: '', component: ContentComponent }];
