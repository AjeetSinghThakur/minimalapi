import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { AncillariesStoreFacade } from '@app/store/ancillaries-store.facade';
import { AnclillaryDetail, HandshakeRequest } from '@app/models';
import { RouterStateUrl } from '@app/store/reducers/router.reducer';
import { authTokenSuccess, loadTrip, authToken, routerNavigation } from '@app/store/actions/ancillaries.actions';
import { BOOKING_REFERENCE } from '@app/shared/constants';

@Component({
  selector: 'qa-dashboard',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ContentComponent implements OnInit {
  dashboardDetail$: Observable<AnclillaryDetail[]>;
  routerState$: Observable<RouterStateUrl>;
  loading$: Observable<boolean>;
  routerState: RouterStateUrl = null;
  constructor( private ancillariesStoreFacade: AncillariesStoreFacade) { }

   ngOnInit() {
     this.dashboardDetail$ = this.ancillariesStoreFacade.dashboardView$;
     this.routerState$ = this.ancillariesStoreFacade.routerState$;
     this.loading$ = this.ancillariesStoreFacade.loading$;
   }
  configureRouterState(routerState: RouterStateUrl ) {
    this.routerState = routerState;
  }
  loadPageData(ancillaries: AnclillaryDetail[]) {
    if (!ancillaries) {
      const request: HandshakeRequest = {
        searchType: BOOKING_REFERENCE,
        searchValue: this.routerState.params.pnr,
        lastName: this.routerState.params.lastName,
        lang: this.routerState.params.lang,
        principal : this.routerState.params.pnr
      };
      if (this.routerState.params.token) {
        this.ancillariesStoreFacade.dispatch(authTokenSuccess({ payload: this.routerState.params.token }));
        this.ancillariesStoreFacade.dispatch(loadTrip());
      } else {
        this.ancillariesStoreFacade.dispatch(authToken({ payload: request }));
      }
    }
  }
  navigateToUrl(routerName: string) {
    let redirectionUrl = `${routerName}/${this.routerState.params.pnr}/${this.routerState.params.lastName}/${this.routerState.params.lang}`;
    redirectionUrl = this.routerState.params.token ? redirectionUrl + '/' + this.routerState.params.token : redirectionUrl;
    this.ancillariesStoreFacade.dispatch(routerNavigation({ payload: redirectionUrl }));
  }
}
