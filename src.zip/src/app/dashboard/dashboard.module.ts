import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { dashboardRoutes } from './dashboard.routing';
import { SharedModule } from '@app/shared/shared.module';
import { ContentComponent } from '@app/dashboard/container';
import { AddonsItemComponent} from './presentational';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(dashboardRoutes),
    SharedModule,
  ],
  exports: [],
  declarations: [
    ContentComponent,
    AddonsItemComponent
  ],
  providers: [],
})
export class DashboardModule {}
