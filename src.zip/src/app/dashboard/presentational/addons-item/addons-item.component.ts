import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { AnclillaryDetail } from '@app/models';

@Component({
  selector: 'qa-addons-item',
  templateUrl: './addons-item.component.html',
  styleUrls: ['./addons-item.component.css'],
})
export class AddonsItemComponent implements OnChanges {
  @Input() loading: boolean;
  @Input() anclillaries: AnclillaryDetail[];
  @Output() navigationEmitter = new EventEmitter<string>();
  @Output() pageDataEmitter: EventEmitter<AnclillaryDetail[]> = new EventEmitter();

  ngOnChanges(changes: any) {
    if (changes.anclillaries) {
      this.pageDataEmitter.emit(changes.anclillaries.currentValue);
    }
  }
  redirectToDetail(routerName: string) {
    this.navigationEmitter.emit(routerName);
  }
}

