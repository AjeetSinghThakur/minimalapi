export * from './addons-item/addons-item.component';

