import { Injectable, ElementRef, Inject } from '@angular/core';
import { Store, Action } from '@ngrx/store';
import { AbstractLocalizationService, QaNotificationService } from '@app/shared/services';
import { currentLang, buildValidationErrors } from './actions/ancillaries.actions';
import {
  getRouterState,
  CoreState,
  getAuthToken,
  getCurrentLang,
  getTrip,
  getErrors,
  getConfirmedAncillaries,
  getEditableConfig,
  getLoading,
  getManagebookingUrl,
  getPodCountry,
  getEligibleAncillaries
} from './reducers';
import { UtilityService } from '@app/core/services';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';
import { FormGroup } from '@angular/forms';
import { GenericValidator } from '@app/shared/validators';
import { MessageModel, MessageCategory } from '@app/models';
@Injectable({
  providedIn: 'root'
})
export class AncillariesStoreFacade {
  authToken$ = this.store.select(getAuthToken);
  currentLang$ = this.store.select(getCurrentLang);
  trip$ = this.store.select(getTrip);
  errorMessage$ = this.store.select(getErrors);
  confirmedAncillaries$ = this.store.select(getConfirmedAncillaries);
  editableConfig$ = this.store.select(getEditableConfig);
  routerState$ = this.store.select(getRouterState);
  loading$ = this.store.select(getLoading);
  podCountry$ = this.store.select(getPodCountry);
  manageBookingUrl$ = this.store.select(getManagebookingUrl);
  dashboardView$ = this.store.select(getEligibleAncillaries);

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
  configureLanguageService(el: ElementRef, langUsed?: string, isCalledFromParent?: boolean) {
    const parentElem = isCalledFromParent ? el.nativeElement.parentElement.parentElement :
    el.nativeElement.parentElement.parentElement.parentElement.parentElement.parentElement;

    const lang = document.createAttribute('lang');
    lang.value = langUsed ? langUsed : this.localizationService.getfallbackLanguage();
    const cssClass = document.createAttribute('class');
    cssClass.value = lang.value;
    parentElem.attributes.setNamedItem(lang);
    parentElem.attributes.setNamedItem(cssClass);

    this.localizationService.configure();
    this.localizationService.useLanguage(lang.value);
  }
  configureAncillaries(el: ElementRef, langUsed?: string) {
    this.configureLanguageService(el, langUsed);
    this.dispatch(currentLang({ payload: langUsed }));
  }
  navigateToManageBooking() {
    return this.utilityService.isMobileTablet() ? this.environmentConfiguration.externalUrls.manageBookingMobileUrl :
    this.environmentConfiguration.externalUrls.manageBookingUrl;
  }
  buildErrors(validationKey: string , formGroup: FormGroup, isPartialValidation: boolean = false) {
    const messages = GenericValidator.processMessages(validationKey, formGroup, isPartialValidation);
    const validationMessges: MessageModel[] = this.qaNotificationService.createNotifications(messages, MessageCategory.Error);
    this.dispatch(buildValidationErrors({ payload: validationMessges }));
  }
  constructor(private store: Store<CoreState>,
              private utilityService: UtilityService,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration,
              private localizationService: AbstractLocalizationService,
              private qaNotificationService: QaNotificationService) {}
}

