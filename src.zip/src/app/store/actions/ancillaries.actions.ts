import { createAction, props } from '@ngrx/store';
import { MessageModel, HandshakeRequest, Trip, Ancillaries, AncillariesResponse, CountryDetail } from '@app/models';
import { EditableConfiguration } from '@app/shared/configurations';

// Build validation errors.
export const buildValidationErrors = createAction('[Error] Validation Messages', props<{ payload: MessageModel[] }>());

// Set Current Language
export const currentLang = createAction('[Langauge] Set Current Langauge', props<{ payload: string }>());

// Set URL Navigation
export const urlNavigation = createAction('[URL] Navigation', props<{ payload: string }>());

// Set ROUTER Navigation
export const routerNavigation = createAction('[ROUTER] Navigation', props<{ payload: string }>());

// Set Deeplink redirection url
export const manageBookingDeepLink = createAction('[DeepLink] Load Success', props<{ payload: string }>());

// Set POD country
export const podCountry = createAction('[POD] country', props<{ payload: string }>());

// Set Auth Token.
export const authToken = createAction('[Auth] Request', props<{ payload: HandshakeRequest }>());
export const authTokenSuccess = createAction('[Auth] Request Success', props<{ payload: string }>());
export const authTokenFail = createAction('[Auth] Request Fail', props<{ payload: MessageModel[] }>());

// Load Trip
export const loadTrip = createAction('[Trip] Load');
export const loadTripSuccess = createAction('[Trip] Load Success', props<{ payload: Trip }>());
export const loadTripFail = createAction('[Trip] Load Fail', props<{ payload: MessageModel[] }>());

// Retrieve Eligible Ancillaries
export const loadEligibleAncillaries = createAction('[Eligible Ancillaries] Load');
export const loadEligibleAncillariesSuccess = createAction('[Eligible Ancillaries] Load Success', props<{ payload: Ancillaries }>());
export const loadEligibleAncillariesFail = createAction('[Eligible Ancillaries] Load Fail', props<{ payload: MessageModel[] }>());

// Load Confirmed Ancillaries
export const confirmedAncillaries = createAction('[Confirm] Load');
export const confirmedAncillariesSuccess = createAction('[Confirm] Load Success', props<{ payload: AncillariesResponse }>());
export const confirmedAnclillariesFail = createAction('[Confirm] Load Fail', props<{ payload: MessageModel[] }>());

// Load Countries Data
export const loadCountries = createAction('[Countries] Load');
export const loadCountriesSuccess = createAction('[Countries] Load Success', props<{ payload: CountryDetail[] }>());
export const loadCountriesFail = createAction('[Countries] Load Fail', props<{ payload: MessageModel[] }>());

// Load System Parameters
export const editableConfiguration = createAction('[Configuration] Load');
export const editableConfigurationSuccess = createAction('[Configuration] Load Success', props<{ payload: EditableConfiguration }>());
export const editableConfigurationFail = createAction('[Configuration] Load Fail', props<{ payload: MessageModel[] }>());
