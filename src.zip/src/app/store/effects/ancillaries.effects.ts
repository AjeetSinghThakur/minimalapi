import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, catchError, switchMap, tap } from 'rxjs/operators';
import { AuthService, AncillariesService } from '@app/core/services';
import {
  HandshakeRequest,
  MessageCategory,
  HandshakeResponse,
  Ancillaries,
  AncillariesResponse,
  TripResponse,
  CountryDetail
} from '@app/models';
import { of } from 'rxjs';
import { AncillariesActions as ancillariesActions } from '../actions';
import { AbstractQaNotificationService } from '@app/shared/services';
import { HttpResponse } from '@angular/common/http';
import { EditableConfiguration } from '@app/shared/configurations';
import { showComponents } from '@app/superwifi/store';
import { urlNavigation, routerNavigation } from '../actions/ancillaries.actions';
import { Router } from '@angular/router';

@Injectable()
export class AncillariesEffects {

  retrieveHandshakeData$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ancillariesActions.authToken),
      map(action => action.payload),
      switchMap((handshakeRequest: HandshakeRequest) => this.authService.handshakeRequest(handshakeRequest)),
      switchMap((handshakeResponse: HttpResponse<HandshakeResponse>) => handshakeResponse && handshakeResponse.body.errorObject ?
      [
        showComponents({ payload : false }),
        ancillariesActions.authTokenFail({
            payload: this.qaNotificationService.createNotifications(
              handshakeResponse.body.errorObject, MessageCategory.Error) })
      ] :
      [
        ancillariesActions.authTokenSuccess({ payload: handshakeResponse.headers.get('Authorization') }),
        ancillariesActions.loadTrip(),
      ]),
      catchError(err => of(ancillariesActions.loadTripFail({
        payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
      })))
    )
  );
  loadEligibleAncillaries$ = createEffect(() =>
      this.actions$.pipe(
        ofType(ancillariesActions.loadEligibleAncillaries),
        switchMap(() => this.ancillariesService.retrieveEligibleAncillaries()),
        switchMap((ancillaries: Ancillaries) => ancillaries && ancillaries.errorObject ?
        [
          showComponents({ payload : false }),
          ancillariesActions.loadEligibleAncillariesFail({ payload:
            this.qaNotificationService.createNotifications(ancillaries.errorObject, MessageCategory.Error)})
        ] :
        [
          ancillariesActions.loadEligibleAncillariesSuccess({ payload: ancillaries })
        ]),
        catchError(err => of(ancillariesActions.loadEligibleAncillariesFail({
          payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
        })))
      )
    );
    loadConfirmedAncillaries$ = createEffect(() =>
      this.actions$.pipe(
        ofType(ancillariesActions.confirmedAncillaries),
        switchMap(() => this.ancillariesService.ancillariesConfirm()),
        switchMap((ancillaries: AncillariesResponse) => ancillaries && ancillaries.errorObject ?
        [
          ancillariesActions.confirmedAnclillariesFail({
            payload: this.qaNotificationService.createNotifications(ancillaries.errorObject, MessageCategory.Error)
          })
        ] :
        [
          ancillariesActions.loadTripSuccess({ payload: ancillaries.tripObj }),
          ancillariesActions.loadEligibleAncillariesSuccess({ payload: ancillaries.eligibleAncillaryResponse}),
          ancillariesActions.manageBookingDeepLink({ payload: ancillaries.redirectDeeplinkUrl }),
          ancillariesActions.podCountry({ payload: ancillaries.podCountry }),
          ancillariesActions.confirmedAncillariesSuccess({ payload: ancillaries }),
        ]),
        catchError(err => of(ancillariesActions.confirmedAnclillariesFail({
          payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
        })))
      )
    );
    loadCountries$ = createEffect(() =>
      this.actions$.pipe(
        ofType(ancillariesActions.loadCountries),
        switchMap(action =>
          this.ancillariesService.loadCountriesInfo().pipe(
            map((countries: CountryDetail[]) => {
              // Sort the countires data by name
              countries.sort((sort, order) => (sort.countryName > order.countryName) ? 1 : -1);
              return ancillariesActions.loadCountriesSuccess({ payload: countries });
            }),
            catchError(err => of(ancillariesActions.loadCountriesFail({
              payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
            })))
          )
        )
      )
    );
    loadDefaultConfigurations$ = createEffect(() =>
      this.actions$.pipe(
        ofType(ancillariesActions.editableConfiguration),
        switchMap(action =>
          this.ancillariesService.loadEditableAncillariesConfig().pipe(
            map((config: EditableConfiguration) => {
              return ancillariesActions.editableConfigurationSuccess({ payload: config });
            }),
            catchError(err => of(ancillariesActions.editableConfigurationFail({
              payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
            })))
          )
        )
      )
    );
    loadTrip$ = createEffect(() =>
      this.actions$.pipe(
        ofType(ancillariesActions.loadTrip),
        switchMap(() =>  this.ancillariesService.loadTrip()),
        switchMap((tripResponse: TripResponse) =>  tripResponse && tripResponse.trip ?
        [
           ancillariesActions.loadTripSuccess({ payload: tripResponse.trip }),
           ancillariesActions.manageBookingDeepLink({ payload: tripResponse.redirectDeeplinkUrl }),
           // ancillariesActions.loadEligibleAncillaries()
        ] :
        [
          showComponents({ payload : false }),
          ancillariesActions.loadTripFail({
            payload: this.qaNotificationService.createNotifications(tripResponse.errorObject,
              MessageCategory.Error) })
        ]),
        catchError(err => of(ancillariesActions.loadTripFail({
          payload: this.qaNotificationService.createNotifications(err, MessageCategory.Error)
        })))
      )
    );
    urlNavigation$ = createEffect(() =>
      this.actions$.pipe(
        ofType(urlNavigation),
        map(action => action.payload),
        tap((redirectionUrl) => { location.href = redirectionUrl; } )
      ),
     { dispatch: false }
   );
   routerNavigation$ = createEffect(() =>
      this.actions$.pipe(
        ofType(routerNavigation),
        map(action => action.payload),
        tap((routerName) => { this.router.navigate([`/${routerName}`]); })
      ),
     { dispatch: false }
   );
  constructor(private actions$: Actions,
              private router: Router,
              private authService: AuthService,
              private ancillariesService: AncillariesService,
              private qaNotificationService: AbstractQaNotificationService) {}
}
