import { Injectable, Inject } from '@angular/core';
import { fromEvent, merge, timer } from 'rxjs';
import { map, switchMapTo, tap } from 'rxjs/operators';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { UserActions as userActions } from '../actions';
import { ModalComponent } from '@app/shared/components';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';

@Injectable()
export class UserEffects {
  clicks$ = fromEvent(document, 'click');
  keys$ = fromEvent(document, 'keydown');
  mouse$ = fromEvent(document, 'mousemove');
  scroll$ = fromEvent(document, 'scroll');

  idle$ = createEffect(() =>
    merge(this.clicks$, this.keys$, this.mouse$, this.scroll$).pipe(
      switchMapTo(timer(this.environmentConfiguration.userInteractivityTimeOut)),
      map(() => userActions.idleTimeout())
    )
  );

  logoutIdleUser$ = createEffect(() =>
  this.actions$.pipe(
    ofType(userActions.idleTimeout),
    tap(authed => {
      const modalRef = this.modalService.open(ModalComponent,
        { backdrop : 'static', keyboard : false , centered: true });
      modalRef.componentInstance.isSession = true;
    }),
  ),
  { dispatch: false }
  );
  constructor(private actions$: Actions,
              private modalService: NgbModal,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration) {}
}
