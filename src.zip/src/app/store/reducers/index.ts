import { createSelector,
  createFeatureSelector,
  ActionReducer,
  MetaReducer,
  Action,
  ActionReducerMap,
} from '@ngrx/store';
import { RouterStateSnapshot } from '@angular/router';
import * as fromRouter from '@ngrx/router-store';
import * as fromAncillaries from './ancillaries.reducer';
import { InjectionToken } from '@angular/core';
import { RouterStateUrl } from './router.reducer';
import { Ancillaries, AnclillaryDetail, SuperWifi } from '@app/models';
import { WIFI, WIFI_ROUTER, WIFI_IMAGE } from '@app/shared/constants';

export interface CoreState {
  router: fromRouter.RouterReducerState<RouterStateSnapshot>;
  ancillaries: fromAncillaries.State;
}

export const ROOT_REDUCERS = new InjectionToken<ActionReducerMap<CoreState, Action>>('Root reducers token', {
  factory: () => ({
    router: fromRouter.routerReducer,
    ancillaries: fromAncillaries.reducer
  }),
});

// console.log all actions
export function logger(reducer: ActionReducer<CoreState>): ActionReducer<CoreState> {
  return (state, action) => {
    const result = reducer(state, action);
    console.groupCollapsed(action.type);
    console.log('prev state', state);
    console.log('action', action);
    console.log('next state', result);
    console.groupEnd();

    return result;
  };
}

export const metaReducers: MetaReducer<CoreState>[] = [];

/**
 * Ancillaries Reducer
 */
export const getAncillariesState = createFeatureSelector<CoreState, fromAncillaries.State>('ancillaries');
export const getAuthToken = createSelector( getAncillariesState, fromAncillaries.authToken );
export const getCurrentLang = createSelector( getAncillariesState, fromAncillaries.currentLang);
export const getTrip = createSelector( getAncillariesState, fromAncillaries.trip );
export const getAncillaries = createSelector( getAncillariesState, fromAncillaries.ancillaries );
export const getErrors = createSelector( getAncillariesState, fromAncillaries.errors);
export const getConfirmedAncillaries = createSelector( getAncillariesState, fromAncillaries.confirmedAncillaries);
export const getCountries = createSelector( getAncillariesState, fromAncillaries.countries);
export const getEditableConfig = createSelector( getAncillariesState, fromAncillaries.editableConfig);
export const getLoading = createSelector(getAncillariesState, fromAncillaries.isLoading );
export const getPodCountry = createSelector(getAncillariesState, fromAncillaries.podCountry);
export const getManagebookingUrl = createSelector(getAncillariesState, fromAncillaries.manageBookingUrl );
export const getEligibleAncillaries = createSelector(getAncillaries, (ancillaries: Ancillaries) => {
    const anclillaryDetails: AnclillaryDetail[] = [];
    if (ancillaries && ancillaries.superWifi) {
      const superWifi: SuperWifi  = ancillaries.superWifi[0];
      anclillaryDetails.push({ amount : superWifi.price.amounts, currencyCode: superWifi.price.currency,
      name: WIFI, wifiImage: WIFI_IMAGE, routerName: WIFI_ROUTER });
    }
    return anclillaryDetails;
});

/**
 * Router Reducer
 */
export const routerState = createFeatureSelector<CoreState, fromRouter.RouterReducerState<RouterStateUrl>>('router');
export const getRouterState = createSelector(routerState, (router): RouterStateUrl => router.state);

