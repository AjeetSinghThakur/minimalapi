import { createReducer, on } from '@ngrx/store';
import { AncillariesActions as ancillariesActions } from '../actions';
import { MessageModel, Trip, Ancillaries, AncillariesResponse, CountryDetail } from '@app/models';
import { EditableConfiguration } from '@app/shared/configurations';

export interface State {
  authToken: string | null;
  trip: Trip | null;
  currentLang: string;
  manageBookingDeepLink: string;
  ancillaries: Ancillaries | null;
  confirmedAncillaries: AncillariesResponse | null;
  countries: CountryDetail[];
  error: MessageModel[];
  editableConfiguration: EditableConfiguration;
  podCountry: string;
  loading: boolean;
}

const initialState: State = {
  authToken: null,
  trip: null,
  error: [],
  countries: [],
  ancillaries: null,
  confirmedAncillaries: null,
  loading: false,
  currentLang: '',
  podCountry: '',
  manageBookingDeepLink: '',
  editableConfiguration: null
};

export const reducer = createReducer(
  initialState,
  on(ancillariesActions.currentLang, (state, { payload }) => {
    return {
      ...state,
      currentLang: payload,
      error: [],
      loading: false
    };
  }),
  on(ancillariesActions.authToken, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.buildValidationErrors, (state, { payload }) => ({
    ...state,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.authTokenSuccess, (state, { payload }) => ({
    ...state,
    authToken: payload,
    error: []
  })),
  on(ancillariesActions.podCountry, (state, { payload }) => ({
    ...state,
    podCountry: payload,
    error: []
  })),
  on(ancillariesActions.manageBookingDeepLink, (state, { payload }) => ({
    ...state,
    manageBookingDeepLink: payload,
    error: []
  })),
  on(ancillariesActions.authTokenFail, (state, { payload }) => ({
    ...state,
    authToken: null,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.editableConfiguration, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.editableConfigurationSuccess, (state, { payload }) => ({
    ...state,
    editableConfiguration: payload,
    error: [],
  })),
  on(ancillariesActions.editableConfigurationFail, (state, { payload }) => ({
    ...state,
    editableConfiguration: null,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.loadCountries, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.loadCountriesSuccess, (state, { payload }) => ({
    ...state,
    countries: payload,
    error: []
  })),
  on(ancillariesActions.loadCountriesFail, (state, { payload }) => ({
    ...state,
    countries: null,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.loadTrip, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.loadTripSuccess, (state, { payload }) => ({
    ...state,
    trip: payload,
    error: []
  })),
  on(ancillariesActions.loadTripFail, (state, { payload }) => ({
    ...state,
    trip: null,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.loadEligibleAncillaries, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.loadEligibleAncillariesSuccess, (state, { payload }) => ({
    ...state,
    ancillaries: payload,
    error: [],
    loading: false
  })),
  on(ancillariesActions.loadEligibleAncillariesFail, (state, { payload }) => ({
    ...state,
    ancillaries: null,
    error: payload,
    loading: false
  })),
  on(ancillariesActions.confirmedAncillaries, state => ({
    ...state,
    loading: true
  })),
  on(ancillariesActions.confirmedAncillariesSuccess, (state, { payload }) => ({
    ...state,
    confirmedAncillaries: payload,
    error: [],
    loading: false
  })),
  on(ancillariesActions.confirmedAnclillariesFail, (state, { payload }) => ({
    ...state,
    confirmedAncillaries: null,
    error: payload,
    loading: false
  })),
);

export const authToken = (state: State) => state.authToken;
export const currentLang = (state: State) => state.currentLang;
export const trip = (state: State) => state.trip;
export const ancillaries = (state: State) => state.ancillaries;
export const errors = (state: State) => state.error;
export const confirmedAncillaries = (state: State) => state.confirmedAncillaries;
export const countries = (state: State) => state.countries;
export const editableConfig = (state: State) => state.editableConfiguration;
export const podCountry = (state: State) => state.podCountry;
export const isLoading = (state: State) => state.loading;
export const manageBookingUrl = (state: State) => state.manageBookingDeepLink;



