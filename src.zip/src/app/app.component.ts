import {Component, OnDestroy, OnInit, ElementRef} from '@angular/core';
import {Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { Configuration } from './shared/configurations';
import { AncillariesStoreFacade } from './store/ancillaries-store.facade';
import { loadCountries, editableConfiguration } from './store/actions/ancillaries.actions';

@Component({
  selector: 'qa-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, OnDestroy {
  protected subscriptions: Subscription[] = [];
  loading: boolean;

  constructor(public configuration: Configuration,
              public router: Router,
              private el: ElementRef,
              private ancillariesStoreFacade: AncillariesStoreFacade) {}

  ngOnInit() {
    this.subscriptions.push(this.ancillariesStoreFacade.currentLang$.subscribe(lang => {
      this.ancillariesStoreFacade.configureLanguageService(this.el, lang, true);
    }));
    // this.ancillariesStoreFacade.dispatch(editableConfiguration());
    // this.ancillariesStoreFacade.dispatch(loadCountries());
    this.subscriptions.push(this.router.events.subscribe((event) => this.setLoadingIndicator(event)));
    this.subscriptions.push(this.router.events.pipe(filter((event) =>
    event instanceof NavigationEnd)).subscribe((event) => window.scrollTo(0, 0)));
  }

  setLoadingIndicator(event: Event) {
    if (event instanceof NavigationStart) {
      this.loading = true;
    } else if (event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError) {
      this.loading = false;
    }
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
