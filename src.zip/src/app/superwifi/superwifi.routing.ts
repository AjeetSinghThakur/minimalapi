import { Routes } from '@angular/router';
import * as components from './container';

export const wifiRoutes: Routes = [{ path: '', component: components.ContentComponent }];
