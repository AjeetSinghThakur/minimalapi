import {Component, OnInit, ChangeDetectionStrategy, ViewChild, OnDestroy, ElementRef, Inject } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { VouchersComponent } from '@app/superwifi/presentational';
import {
  VALID,
  BOOKING_REFERENCE,
  MOBILE,
  EMAIL,
  SUPERWIFI,
  TRNX_CANCEL_CODE,
  TRNX_ERROR_TYPE,
  SUPER_WIFI_LANDING_PAGE,
  SHORT_ANDROID,
  SHORT_IPHONE,
  MOBILE_WEBSITE,
  DESKTOP_WEBSITE,
  GLOBAL
} from '@app/shared/constants';
import {
  MessageModel,
  TripViewModel,
  AmountOverView,
  VoucherFormViewModel,
  HandshakeRequest,
  AncillariesResponse,
  CountryDetail,
  ContactDetail,
  SuperWifiRequest
} from '@app/models';
import { SUPERWIFI_VALIDATION_KEY } from '@app/shared/validators';
import { WifiStoreFacade } from '@app/superwifi/store/superwifi-store.facade';
import { AncillariesStoreFacade } from '@app/store/ancillaries-store.facade';
import { EditableConfiguration, LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';
import { saveWifiDetail, unblockInventory } from '@app/superwifi/store';
import {
  authToken,
  urlNavigation,
  loadTrip,
  authTokenSuccess,
  buildValidationErrors,
  routerNavigation
} from '@app/store/actions/ancillaries.actions';
import { StorageService, AbstractEventBusService } from '@app/shared/services';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from '@app/shared/components';
import { UtilityService } from '@app/core/services';
import { CookieService } from 'ngx-cookie-service';
import { RouterStateUrl } from '@app/store/reducers/router.reducer';

@Component({
  selector: 'qa-superwifi-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContentComponent implements OnInit, OnDestroy {
  @ViewChild(VouchersComponent) public vouchersComponent: VouchersComponent;
  protected subscriptions: Subscription[] = [];
  // Observables for all presentational components.
  totalAmountOverView: AmountOverView;
  voucherDetail$: Observable<VoucherFormViewModel>;
  tripDetails$: Observable<TripViewModel>;
  routerState$: Observable<RouterStateUrl>;
  errorMessage$: Observable<MessageModel[]>;
  showComponent$: Observable<boolean>;
  confirmedAncillaries$: Observable<AncillariesResponse>;
  countries$: Observable<CountryDetail[]>;
  editableConfig$: Observable<EditableConfiguration>;
  loading$: Observable<boolean>;
  manageBookingUrl$: Observable<string>;
  pnr: string;
  invalidVoucher: boolean;
  pageName = SUPER_WIFI_LANDING_PAGE;
  routerState: RouterStateUrl = null;

  constructor(private el: ElementRef,
              private modalService: NgbModal,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration,
              private wifiStoreFacade: WifiStoreFacade,
              private storageService: StorageService,
              private cookieService: CookieService,
              private eventService: AbstractEventBusService,
              private utilityService: UtilityService,
              private ancillariesStoreFacade: AncillariesStoreFacade) {}

  ngOnInit(): void {
    this.routerState$ = this.ancillariesStoreFacade.routerState$;
    this.tripDetails$ = this.wifiStoreFacade.tripDetailView$;
    this.voucherDetail$ = this.wifiStoreFacade.voucherDetail$;
    this.showComponent$ = this.wifiStoreFacade.showComponent$;
    this.countries$ = this.wifiStoreFacade.countries$;
    this.editableConfig$ = this.ancillariesStoreFacade.editableConfig$;
    this.errorMessage$ = this.ancillariesStoreFacade.errorMessage$;
    this.loading$ = this.ancillariesStoreFacade.loading$;
    this.manageBookingUrl$ = this.ancillariesStoreFacade.manageBookingUrl$;
    this.eventService.scrollToTop();
  }
  configureRouteState(routerState: RouterStateUrl ) {
    this.routerState = routerState;
  }
  loadPageData(tripDetail: TripViewModel) {
    this.pnr = this.routerState.params.pnr;
    if (!tripDetail) {
      const request: HandshakeRequest = {
        searchType: BOOKING_REFERENCE,
        searchValue: this.routerState.params.pnr,
        lastName: this.routerState.params.lastName,
        lang: this.routerState.params.lang,
        principal : this.routerState.params.pnr
      };
      this.ancillariesStoreFacade.configureAncillaries(this.el, request.lang);
      if (this.routerState.params.token) {
        this.ancillariesStoreFacade.dispatch(authTokenSuccess({ payload: this.routerState.params.token }));
        this.ancillariesStoreFacade.dispatch(loadTrip());
      } else {
        this.ancillariesStoreFacade.dispatch(authToken({ payload: request }));
      }
      if (this.routerState.params && this.routerState.params.platform &&
        (SHORT_ANDROID === this.routerState.params.platform.toLowerCase() ||
        SHORT_IPHONE === this.routerState.params.platform.toLowerCase() )) {
          this.utilityService.setPlatform(this.routerState.params.platform.toLowerCase());
      }
      if (this.routerState.queryParams && this.routerState.queryParams.errorCode === TRNX_CANCEL_CODE &&
        this.routerState.queryParams.errorType === TRNX_ERROR_TYPE)  {
        this.ancillariesStoreFacade.dispatch(unblockInventory());
      }
    }
  }

  submitVoucherForm() {
    this.vouchersComponent.formGroup.status === VALID ? this.saveForm() :
    this.ancillariesStoreFacade.buildErrors(SUPERWIFI_VALIDATION_KEY, this.vouchersComponent.formGroup);
  }
  continueShopping() {
    let redirectionUrl = `dashboard/${this.routerState.params.pnr}/${this.routerState.params.lastName}/${this.routerState.params.lang}`;
    redirectionUrl = this.routerState.params.token ? redirectionUrl + '/' + this.routerState.params.token : redirectionUrl;

    if (this.vouchersComponent.formGroup.status === VALID) {
      this.configureLocalStorage();
      this.ancillariesStoreFacade.dispatch(routerNavigation({ payload: redirectionUrl }));
    } else {
      this.ancillariesStoreFacade.buildErrors(SUPERWIFI_VALIDATION_KEY, this.vouchersComponent.formGroup);
    }
  }
  validateForm() {
    this.ancillariesStoreFacade.buildErrors(SUPERWIFI_VALIDATION_KEY, this.vouchersComponent.formGroup, true );
  }
  clearFormValidations() {
    this.ancillariesStoreFacade.dispatch(buildValidationErrors({ payload: null }));
  }

  navigateToUrl(deepLink: string) {
    if (this.vouchersComponent.formGroup.touched) {
      const modalRef = this.modalService.open(ModalComponent, { centered: true });
      modalRef.componentInstance.redirectionRequired = true;
      this.subscriptions.push(modalRef.componentInstance.parentEntry.subscribe((redirect: boolean) => {
        if (redirect) {
          this.ancillariesStoreFacade.dispatch(urlNavigation({ payload: deepLink ?
            deepLink : this.ancillariesStoreFacade.navigateToManageBooking() }));
        }
      }));
    } else {
      this.ancillariesStoreFacade.dispatch(urlNavigation({ payload: deepLink ?
        deepLink : this.ancillariesStoreFacade.navigateToManageBooking() }));
    }
  }
  saveForm() {
    const details: ContactDetail[] = [];
    const voucherDetail = this.vouchersComponent.formGroup.value;
    // code commented as UI dont have any mobile field
    // if (voucherDetail.mobileNumber) {
    //   details.push({ contactType: MOBILE, countryCode: voucherDetail.countryCode.isdCode, value: voucherDetail.mobileNumber });
    // }
    // Ajeet : This is to support the code of qore service having mobile as mandatory for payment.
    details.push({ contactType: MOBILE, countryCode: '0', value: '0' });

    if (voucherDetail.email) {
      details.push({ contactType: EMAIL.toUpperCase(), value: voucherDetail.email });
    }
    const superWifiRequestList: SuperWifiRequest[] = [];
    superWifiRequestList.push({ contactDetails: details, voucherQuantity: voucherDetail.voucherQuantity, productCode: SUPERWIFI });

    const platform = this.utilityService.platform && (SHORT_IPHONE === this.utilityService.platform ||
      SHORT_ANDROID === this.utilityService.platform) ?  this.utilityService.getPlatForm() :
      this.utilityService.isMobileTablet() ? MOBILE_WEBSITE : DESKTOP_WEBSITE;

    const preferedCountry = this.cookieService.get('Language-Preferred') ?
    this.cookieService.get('Language-Preferred').toLowerCase() : GLOBAL;

    const payloadRequest = {
      ancillaryRequest: { superWifiRequests: superWifiRequestList}, platform, preferedCountry
    };
    this.wifiStoreFacade.dispatch(saveWifiDetail({ payload: payloadRequest }));
    this.configureLocalStorage();

  }

  totalAmount(amountDetail: AmountOverView) {
    this.totalAmountOverView = amountDetail;
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
  configureLocalStorage() {
    const pnr: string = this.storageService.getItem('pnr');
    if (!pnr || pnr !== this.pnr) {
      this.storageService.setItem('pnr', this.pnr);
      this.storageService.setItem(this.storageService.getItem('pnr'), this.vouchersComponent.formGroup.value);
    }
  }
}
