import { ContentComponent } from './content/content.component';

export const allContainerComponents: any[] = [
  ContentComponent
];

export * from './content/content.component';
