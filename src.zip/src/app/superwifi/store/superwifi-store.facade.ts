import { Injectable } from '@angular/core';
import { select, Store, Action } from '@ngrx/store';
import { CoreState, getCountries } from '@app/store/reducers';
import { getTripDetailView, getVoucherDetail, getComponentView } from '@app/superwifi/store';
@Injectable({
  providedIn: 'root'
})
export class WifiStoreFacade {
  tripDetailView$ = this.store.pipe(select(getTripDetailView));
  voucherDetail$ = this.store.pipe(select(getVoucherDetail));
  showComponent$ = this.store.pipe(select(getComponentView));
  countries$ = this.store.pipe(select(getCountries));

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
  constructor(private store: Store<CoreState>) {}
}
