import { createAction, props } from '@ngrx/store';
import { MessageModel, AncillaryRequest } from '@app/models';

// UI related actions
export const showComponents = createAction('[Components] Valid', props<{ payload: boolean }>());

// Effects related actions
export const saveWifiDetail = createAction('[Voucher] Save Initiated', props<{ payload: AncillaryRequest }>());
export const saveWifiDetailSuccess = createAction('[Voucher] Save Success', props<{ payload: string }>());
export const saveWifiDetailFail = createAction('[Voucher] Save Fail', props<{ payload: MessageModel[] }>());


// Unblock inventory
export const unblockInventory = createAction('[Unblock] Inventory');
export const unblockInventorySuccess = createAction('[Unblock] Success');
export const unblockInventoryFail = createAction('[Unblock] Fail', props<{ payload: MessageModel[] }>());
