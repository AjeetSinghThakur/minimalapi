import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as superwifiActions from './superwifi.actions';
import { map, catchError, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { AncillariesService } from '@app/core/services';
import { AncillaryRequest, PaymentResult, MessageCategory, InventoryResponse } from '@app/models';
import { urlNavigation, buildValidationErrors } from '@app/store/actions/ancillaries.actions';
import { AbstractQaNotificationService } from '@app/shared/services';

@Injectable()
export class SuperwifiEffects {
  constructor(private actions$: Actions,
              private qaNotificationService: AbstractQaNotificationService,
              private ancillariesService: AncillariesService) {}

  proceedWithPayment$ = createEffect(() =>
    this.actions$.pipe(
      ofType(superwifiActions.saveWifiDetail),
      map(action => action.payload),
      switchMap((ancillaryRequest: AncillaryRequest) => this.ancillariesService.proceedWithPayment(ancillaryRequest)),
      switchMap((paymentResult: PaymentResult) => paymentResult && paymentResult.errorObject ?
      [
        buildValidationErrors({ payload:
          this.qaNotificationService.createNotifications(paymentResult.errorObject, MessageCategory.Error)})
      ] :
      [
        urlNavigation({ payload: paymentResult.paymentRedirectUrl })
      ]),
      catchError(err => of(superwifiActions.saveWifiDetailFail({ payload: err })))
    )
  );
  unblockInventory$ = createEffect(() =>
    this.actions$.pipe(
      ofType(superwifiActions.unblockInventory),
      switchMap(() => this.ancillariesService.unblockInventory()),
      switchMap((response: InventoryResponse) => response && response.errorObject ?
      [
        buildValidationErrors({ payload: this.qaNotificationService.createNotifications(response.errorObject, MessageCategory.Error)})
      ] :
      [
        superwifiActions.unblockInventorySuccess()
      ]),
      catchError(err => of(superwifiActions.unblockInventoryFail({ payload: err })))
    )
  );
}
