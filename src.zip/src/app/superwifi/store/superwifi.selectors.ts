import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import { ReducerSuperwifiState, superwifiReducer } from './superwifi.reducer';
import { CoreState, getTrip, getAncillaries } from '@app/store/reducers';
import {
  Ancillaries,
  TripViewModel,
  Trip,
  SuperwifiAvailability,
  FlightList,
  FlightListViewModel,
  VoucherFormViewModel,
  Journey
} from '@app/models';
import { MULTICITY, WIFI_NOINFO, WIFI_AVAILABLE, RETURN_TRIP, ARRIVAL, DEPART } from '@app/shared/constants';

export interface AppState extends CoreState { superWifi: SuperWifiState; }
export const featureSuperwifiStateName = 'superwifiFeature';
export interface SuperWifiState { superWifi: ReducerSuperwifiState; }
export const superwifiReducers: ActionReducerMap<SuperWifiState> = { superWifi: superwifiReducer };
export const getSuperwifiFeatureState = createFeatureSelector<SuperWifiState>(featureSuperwifiStateName);
export const getSuperwifiState = createSelector(getSuperwifiFeatureState, (state: SuperWifiState) => state.superWifi);


export const getTripDetailView = createSelector(
  getTrip,
  getAncillaries,
  (trip: Trip, ancillaries: Ancillaries) => {
    if (trip && ancillaries && ancillaries.superWifi) {
      const tripView: TripViewModel = {};
      tripView.tripReference = trip.tripReference;
      tripView.tripType = trip.tripType;
      // Building Flight list for superwifi.
      const wifiList: SuperwifiAvailability[] = ancillaries.superWifi.reduce((anc, wifi) => [ ...anc, ...wifi.superwifiAvailability], []);
      const flightList: FlightList[] = trip.journeys.reduce((tr, journey) => [ ...tr, ...journey.flightList], []);
      if (tripView.tripType !== MULTICITY) {
        const departureJourney: Journey = trip.journeys[0];
        const arrivalJourney: Journey = tripView.tripType === RETURN_TRIP ? trip.journeys[1] : null ;
        tripView.destinationDetails = {
          arrivalAirportCode: departureJourney.arrivalStationCode,
          arrivalCity: arrivalJourney ? arrivalJourney.flightList.find(x =>
            x.departureStation.airportCode === departureJourney.arrivalStationCode).departureStation.city :
          departureJourney.flightList.slice(-1)[0].arrivalStation.city,
          returnTrip: arrivalJourney ? true : false,
          arrivalDate: arrivalJourney ? arrivalJourney.departureDate : departureJourney.arrivalDate,
          departureDate: departureJourney.departureDate,
          departureCity: departureJourney.flightList.find(x => x).departureStation.city,
          departureCodeAirportCode: departureJourney.departureStationCode
        };
        if (flightList && wifiList) {
          tripView.flights = [];
          flightList.forEach(flight => {
            const wifi = wifiList.find(x => x.flightIdentifier.uniqueIdentifier === flight.flightIdentifier.uniqueIdentifier);
            tripView.flights.push({
              arrivalStation: flight.arrivalStation.airportCode,
              departureStation: flight.departureStation.airportCode,
              departureCity: flight.departureStation.city,
              arrivalCity: flight.arrivalStation.city,
              flightNumber: flight.flightNumber,
              flightType: departureJourney.flightList.find(x =>
                x.flightNumber === flight.flightNumber) ? DEPART : ARRIVAL,
              operatingCarrier: flight.carrier.carrier,
              wifiStatus: wifi ? wifi.eligibleStatus : WIFI_NOINFO });
          });
          const wifiFlights = tripView.flights.filter(x => x.wifiStatus === WIFI_AVAILABLE);
          tripView.allWifiFlight = wifiFlights.length === flightList.length ? true : false;
        }
      } else if (tripView.tripType === MULTICITY) {
        tripView.journeyList = [];
        trip.journeys.forEach(journey => {
            const departureFlight = journey.flightList[0];
            const arrivalFlight = journey.flightList.slice(-1)[0];
            const flighList: FlightListViewModel[] = [];
            if (journey.flightList) {
              journey.flightList.forEach(flight => {
                const wifi = wifiList.find(x => x.flightIdentifier.uniqueIdentifier === flight.flightIdentifier.uniqueIdentifier);
                flighList.push({
                  arrivalStation: flight.arrivalStation.airportCode,
                  departureStation: flight.departureStation.airportCode,
                  departureCity: flight.departureStation.city,
                  arrivalCity: flight.arrivalStation.city,
                  flightNumber: flight.flightNumber,
                  operatingCarrier: flight.carrier.carrier,
                  wifiStatus: wifi ? wifi.eligibleStatus : WIFI_NOINFO });
              });
            }
            tripView.journeyList.push({
              flights: flighList,
              arrivalAirportCode: arrivalFlight.arrivalStation.airportCode,
              arrivalCity: arrivalFlight.arrivalStation.city,
              departureCity: departureFlight.departureStation.city,
              departureCodeAirportCode: departureFlight.departureStation.airportCode,
            });
          });
        const wifiFlights = tripView.journeyList.reduce((tr, jr) =>
        [ ...tr, ...jr.flights.filter(x => x.wifiStatus === WIFI_AVAILABLE )], []);
        tripView.allWifiFlight = wifiFlights.length === flightList.length ? true : false;
      }
      return tripView;
    }
  }
);
export const getVoucherDetail = createSelector(
  getTrip,
  getAncillaries,
  (trip: Trip, ancillaries: Ancillaries) => {
    if (trip && ancillaries && ancillaries.superWifi) {
      // Build superwifi voucher form.
      const contactEmail = !trip.bookingInfo.groupBooking ?
      trip.contactDetails.find(x => x.contactType === 'EMAIL') : null;
      const voucherFormViewModel: VoucherFormViewModel = {
        email: contactEmail ? contactEmail.value : '' ,
        priceConfig: ancillaries.superWifi[0].price
      };
      return voucherFormViewModel;
    }
  }
);
export const getComponentView = createSelector(
  getTripDetailView,
  (tripView: TripViewModel ) => {
    if (tripView) {
      const iswifiAvailable: boolean = tripView.tripType === MULTICITY &&
      tripView.journeyList.reduce((tr, journey) => [ ...tr, ...journey.flights], []).find(x =>
      x.wifiStatus === WIFI_AVAILABLE) ? true : tripView.tripType !== MULTICITY &&
      tripView.flights.find(x => x.wifiStatus === WIFI_AVAILABLE) ? true : false;

      return iswifiAvailable;
    }
  }
);
