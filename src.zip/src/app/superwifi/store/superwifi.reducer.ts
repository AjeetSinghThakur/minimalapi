import * as superwifiActions from './superwifi.actions';
import { createReducer, on, Action } from '@ngrx/store';
import { MessageModel } from '@app/models';

export interface ReducerSuperwifiState {
  cpgSuccessUrl: string;
  isViewAvailable: boolean;
  error: MessageModel[];
  loading: boolean;
}

export const initialState: ReducerSuperwifiState = {
  cpgSuccessUrl: '',
  error: [],
  loading: false,
  isViewAvailable: true
};

const superwifReducerInternal = createReducer(
  initialState,
  on(superwifiActions.saveWifiDetailSuccess, (state, { payload }) => ({
    ...state,
    cpgSuccessUrl: payload,
    error: [],
    loading: false
  })),
  on(superwifiActions.saveWifiDetailFail, (state, { payload }) => ({
    ...state,
    ancillaries: null,
    error: payload,
    loading: false
  })),
  on(superwifiActions.showComponents, (state, { payload }) => ({
    ...state,
    isViewAvailable: payload,
    error: [],
    loading: false
  }))
);

export function superwifiReducer(
  state: ReducerSuperwifiState | undefined,
  action: Action
) {
  return superwifReducerInternal(state, action);
}
