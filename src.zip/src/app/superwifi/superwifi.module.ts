import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { wifiRoutes } from '@app/superwifi/superwifi.routing';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { SharedModule } from '@app/shared/shared.module';
import { featureSuperwifiStateName, superwifiReducers, SuperwifiEffects } from './store';
import { allContainerComponents } from './container';
import { allPresComponents } from './presentational';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    RouterModule.forChild(wifiRoutes),
    StoreModule.forFeature(featureSuperwifiStateName, superwifiReducers),
    EffectsModule.forFeature([SuperwifiEffects]),
    SharedModule
  ],
  declarations: [
    ...allContainerComponents,
    ...allPresComponents,
  ],
  exports: [
    ...allContainerComponents,
    ...allPresComponents,
  ]
})
export class SuperwifiModule { }
