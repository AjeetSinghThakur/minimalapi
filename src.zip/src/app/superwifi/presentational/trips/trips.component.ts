import { Component, Input, OnChanges, OnInit, Output, EventEmitter } from '@angular/core';
import { TripViewModel } from '@app/models';
import { OmnitureService } from '@app/core/services';

@Component({
  selector: 'qa-trips',
  templateUrl: './trips.component.html',
  styleUrls: ['./trips.component.css']
})
export class TripsComponent implements OnInit , OnChanges {
  @Input() tripDetail: TripViewModel;
  @Input() loading: boolean;
  @Input() pageName: string;
  @Output() pageDataEmitter: EventEmitter<TripViewModel> = new EventEmitter();


  constructor(private omnitureService: OmnitureService) {
  }
  ngOnInit() {
    this.omnitureService.setDefaultAnalytics();
  }
  ngOnChanges(changes: any) {
    if (changes.tripDetail) {
      this.pageDataEmitter.emit(changes.tripDetail.currentValue);
      if (changes.tripDetail.currentValue) {
        const events = 'event125';
        this.omnitureService.setSuperwifiAnalytics(changes.tripDetail.currentValue, this.pageName, events);
      }
    }
  }
}
