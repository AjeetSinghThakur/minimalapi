import { Component, Input } from '@angular/core';

@Component({
  selector: 'qa-purchase-conditions',
  templateUrl: './purchase-conditions.component.html',
  styleUrls: ['./purchase-conditions.component.css'],
})
export class PurchaseConditionsComponent {
  @Input() showComponent: boolean;
  @Input() loading: boolean;
  isActive = true;

  addActive() {
    this.isActive = !this.isActive;
  }
}
