import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RouterStateUrl } from '@app/store/reducers/router.reducer';
@Component({
  selector: 'qa-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {
  constructor() {}

  formGroup: FormGroup;
  termsConditions = false;
  @Input() loading: boolean;
  @Input() showComponent: boolean;
  @Input() deepUrl: string;
  @Input() routerStateUrl: RouterStateUrl;
  @Output() proceedToPaymentEmitter = new EventEmitter<string>();
  @Output() navigationEmitter = new EventEmitter<string>();
  @Output() continueShoppingEmitter = new EventEmitter<RouterStateUrl>();

  saveVouchers() {
    this.proceedToPaymentEmitter.emit();
  }
  ngOnInit(): void {
    this.formGroup = new FormGroup({
      termsConditions: new FormControl(false, [Validators.required])
    });
  }
  navigate(deepLink: string) {
    this.navigationEmitter.emit(deepLink);
  }
  continueShopping(routerStateUrl: RouterStateUrl) {
    this.continueShoppingEmitter.emit(routerStateUrl);
  }
}
