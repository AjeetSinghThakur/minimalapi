import { Component, OnInit, Input, Output, EventEmitter, OnChanges, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { MessageModel, AmountOverView, VoucherFormViewModel, CountryDetail } from '@app/models';
import { CustomValidator } from '@app/shared/validators';
import { EMPTY_STRING, EMAIL, REPEAT_EMAIL, BLUR, INVALID, VALID, COUNTRY_CODE } from '@app/shared/constants';
import { EditableConfiguration, LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { StorageService } from '@app/shared/services';
@Component({
  selector: 'qa-vouchers',
  templateUrl: './vouchers.component.html',
  styleUrls: ['./vouchers.component.css']
})
export class VouchersComponent implements OnInit, OnChanges {
  @Input() voucherDetail: VoucherFormViewModel;
  @Input() editableConfig: EditableConfiguration;
  @Input() showComponent: boolean;
  @Input() loading: boolean;
  @Input() countries: CountryDetail[];
  @Output() totalAmountEmitter: EventEmitter<AmountOverView> = new EventEmitter();
  @Output() validateFormEmitter = new EventEmitter<string>();
  @Output() clearValidationEmitter = new EventEmitter<string>();
  formGroup: FormGroup;
  @Input() messages: MessageModel[];
  submitted = false;

  constructor(private formBuilder: FormBuilder,
              private storageService: StorageService,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration) {}

  ngOnInit() {
    this.buildForm();
  }
  ngOnChanges(changes: any) {
    if (changes.voucherDetail && this.formGroup && !this.formGroup.get('email').value) {
      const detail = changes.voucherDetail.currentValue as VoucherFormViewModel;
      this.formGroup.get('email').setValue(detail ? detail.email : '');
    }
    // if (changes.voucherDetail && this.formGroup && this.formGroup.get('voucherQuantity')) {
    //   this.formGroup.get('voucherQuantity').setValidators(Validators.max(this.editableConfig.configuredVouchers));
    // }
  }
  buildForm() {
    const voucherFormViewModel =
    this.storageService.getItem(this.storageService.getItem('pnr')) as VoucherFormViewModel;

    this.formGroup = this.formBuilder.group({
        voucherQuantity: new FormControl(voucherFormViewModel ? voucherFormViewModel.voucherQuantity : EMPTY_STRING, {
          validators: [Validators.required, Validators.min(1), Validators.max(20)],
          updateOn: BLUR
        }),
        email: new FormControl(voucherFormViewModel ? voucherFormViewModel.email : EMPTY_STRING, {
          validators: [Validators.required, Validators.email],
          updateOn: BLUR
        })
        // repeatEmail: new FormControl(voucherFormViewModel ? voucherFormViewModel.email : EMPTY_STRING, {
        //   validators: [Validators.required, Validators.email],
        //   updateOn: BLUR
        // }),
        // countryCode: new FormControl(voucherFormViewModel ? voucherFormViewModel.countryCode : EMPTY_STRING, {
        //   validators: [Validators.required],
        //   updateOn: BLUR
        // }),
        // mobileNumber: new FormControl(voucherFormViewModel ? voucherFormViewModel.mobileNumber : EMPTY_STRING, {
        //   validators: [Validators.required, Validators.minLength(5), Validators.min(5)],
        //   updateOn: BLUR
        // })
      },
      // {
      //   validator: [CustomValidator.emailCheck(EMAIL, REPEAT_EMAIL), CustomValidator.autoPopulateValueCheck(COUNTRY_CODE)]
      // }
    );
  }
  validateFormFields(formControl?: AbstractControl) {
    let formStatus = true;
    for (const controlKey in this.formGroup.controls) {
      if (this.formGroup.get(controlKey).touched && this.formGroup.get(controlKey).status === INVALID) {
        formStatus = false;
      }
    }
    if (formStatus && formControl.status === VALID) {
      const formGroup = formControl.parent.controls;
      const controlName = Object.keys(formGroup).find(name => formControl === formGroup[name]);
      if (this.messages && this.messages.length === 1 && this.messages[0].errors.find(x => x.detail.split('.')[2] === controlName)) {
        this.clearValidationEmitter.emit();
      }
    } else if (formControl.status === INVALID && formControl.value !== '') {
      this.validateFormEmitter.emit();
    } else if (formControl.status === VALID && this.messages && this.messages.length > 0  &&
      this.messages[0].errors.find(x => this.formGroup.get(x.detail.split('.')[2]) === formControl)) {
        this.validateFormEmitter.emit();
    }
  }
  calculateTotal(numberOfVouchers: number) {
  if (this.voucherDetail && this.voucherDetail.priceConfig) {
    const amountDetail: AmountOverView = {
      currency: this.voucherDetail.priceConfig.currency,
      totalAmount: numberOfVouchers * this.voucherDetail.priceConfig.amounts
    };
    this.validateFormFields(this.formGroup.get('voucherQuantity'));
    this.totalAmountEmitter.emit(amountDetail);
  }
  }
  search(text$: Observable<string>): Observable<CountryDetail[]> {
    return this.filterLocations(text$);
  }
  formatter(result: any) {
    return this.formatResult(result);
  }
  inputFormatter(result: any) {
    return this.formatResult(result);
  }
  filterLocations(text$: Observable<string>): Observable<CountryDetail[]> {
    return text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map((term) => term === '' ? [] : (this.countries.filter((country: CountryDetail) =>
        this.countryMatchesAsPrefix(country, term))).slice( 0, this.environmentConfiguration.dropdownOptions)
      )
    );
  }
  countryMatchesAsPrefix(country: CountryDetail, userInput: string) {
    return (
      (country.countryName && country.countryName.toUpperCase().startsWith(userInput.toUpperCase())) ||
      (country.isdCode && country.isdCode.includes(userInput.toUpperCase())) ||
      this.formatResult(country).includes(userInput.toUpperCase())
    );
  }
  formatResult(result: any) {
    let formattedResult = '';
    if (result &&  result.countryName && result.isdCode) {
      formattedResult = `(+${result.isdCode}) ${result.countryName}`;
    }
    return formattedResult;
  }
  verifyCountry() {
    const formControl = this.formGroup.get('countryCode');
    if (formControl && typeof formControl.value === 'string') {
      const isdCode = formControl.value.split(' ')[0] ?
      formControl.value.split(' ')[0].replace('+', '').replace('(', '').replace(')', '') : '' ;
      const countryName = formControl.value.split(' ')[1] ? formControl.value.split(' ')[1] : '';
      const country = this.countries.find(x => x.countryName === countryName && x.isdCode === isdCode);
      country ? formControl.patchValue(country) : this.formGroup.get('countryCode');
    }
    this.validateFormFields(formControl);
  }
}
