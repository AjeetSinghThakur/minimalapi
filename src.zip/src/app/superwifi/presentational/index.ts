import { TermsComponent } from './terms/terms.component';
import { PurchaseConditionsComponent } from './purchase-conditions/purchase-conditions.component';
import { TripsComponent } from './trips/trips.component';
import { TotalpriceComponent } from './total-price/total-price.component';
import { VouchersComponent } from './vouchers/vouchers.component';

export const allPresComponents: any[] = [
  TermsComponent,
  PurchaseConditionsComponent,
  TripsComponent,
  TotalpriceComponent,
  VouchersComponent
];

export * from './terms/terms.component';
export * from './purchase-conditions/purchase-conditions.component';
export * from './trips/trips.component';
export * from './total-price/total-price.component';
export * from './vouchers/vouchers.component';
