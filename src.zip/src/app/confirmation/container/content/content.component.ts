import { Component, OnInit, ElementRef, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { AncillariesStoreFacade } from '@app/store/ancillaries-store.facade';
import { AncillariesResponse, MessageModel, TripViewModel } from '@app/models';
import { authTokenSuccess, confirmedAncillaries, urlNavigation } from '@app/store/actions/ancillaries.actions';
import { StorageService } from '@app/shared/services';
import { PurchaseOverviewComponent } from '@app/confirmation/presentational';
import { WifiStoreFacade } from '@app/superwifi/store/superwifi-store.facade';
import { OmnitureService, UtilityService } from '@app/core/services';
import { SUPER_WIFI_CONFIRMATION_PAGE, SHORT_ANDROID, SHORT_IPHONE } from '@app/shared/constants';
import { RouterStateUrl } from '@app/store/reducers/router.reducer';

@Component({
  selector: 'qa-confirmationpage',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContentComponent implements OnInit {
  @ViewChild(PurchaseOverviewComponent, { static: false }) public purchaseOverviewComponent: PurchaseOverviewComponent;
  constructor(private el: ElementRef,
              private storageService: StorageService,
              private wifiStoreFacade: WifiStoreFacade,
              private omnitureService: OmnitureService,
              private utilityService: UtilityService,
              private ancillariesStoreFacade: AncillariesStoreFacade) {}

    confirmedAncillaries$: Observable<AncillariesResponse>;
    routerState$: Observable<RouterStateUrl>;
    tripDetails$: Observable<TripViewModel>;
    errorMessage$: Observable<MessageModel[]>;
    manageBookingUrl$: Observable<string>;
    podCountry$: Observable<string>;
    loading$: Observable<boolean>;
    showComponent$: Observable<boolean>;
    routerState: RouterStateUrl = null;

    ngOnInit(): void {
      this.routerState$ = this.ancillariesStoreFacade.routerState$;
      this.errorMessage$ = this.ancillariesStoreFacade.errorMessage$;
      this.loading$ = this.ancillariesStoreFacade.loading$;
      this.manageBookingUrl$ = this.ancillariesStoreFacade.manageBookingUrl$;
      this.tripDetails$ = this.wifiStoreFacade.tripDetailView$;
      this.podCountry$ = this.ancillariesStoreFacade.podCountry$;
      this.confirmedAncillaries$ = this.ancillariesStoreFacade.confirmedAncillaries$;

      this.storageService.removeItem(this.storageService.getItem('pnr'));
      this.storageService.removeItem('pnr');
    }
    configureRouteState(routerState: RouterStateUrl ) {
      this.routerState = routerState;
    }
    loadPageData() {
      this.ancillariesStoreFacade.configureAncillaries(this.el, this.routerState.params.lang);
      if (this.routerState.params && this.routerState.params.platform &&
          (SHORT_ANDROID === this.routerState.params.platform.toLowerCase() ||
          SHORT_IPHONE === this.routerState.params.platform.toLowerCase() )) {
            this.utilityService.setPlatform(this.routerState.params.platform.toLowerCase());
      }
      this.omnitureService.setDefaultAnalytics();
      this.ancillariesStoreFacade.dispatch(authTokenSuccess({ payload: this.routerState.params.conversationToken }));
      this.ancillariesStoreFacade.dispatch(confirmedAncillaries());
    }
    setSuperwifiAnalytics() {
      const events = `event127,event128,event129`;
      this.omnitureService.setSuperwifiAnalytics(this.purchaseOverviewComponent.tripDetail,
      SUPER_WIFI_CONFIRMATION_PAGE, events, this.purchaseOverviewComponent.ancillaries, this.purchaseOverviewComponent.podCountry);
    }
    navigateToUrl(deepLink: string) {
      this.ancillariesStoreFacade.dispatch(urlNavigation({ payload:
        deepLink ? deepLink : this.ancillariesStoreFacade.navigateToManageBooking() }));
    }
}
