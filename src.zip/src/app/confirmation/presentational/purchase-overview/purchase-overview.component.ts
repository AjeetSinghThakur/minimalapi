import { Component, Input, OnInit, OnChanges, Output, EventEmitter } from '@angular/core';
import { SuperWifiResponse, GlxProdVouchersResponse, TripViewModel } from '@app/models';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from '@app/shared/components';

@Component({
  selector: 'qa-purchase-overview',
  templateUrl: './purchase-overview.component.html',
  styleUrls: ['./purchase-overview.component.css'],
})
export class PurchaseOverviewComponent implements OnInit, OnChanges {
  @Input() ancillaries: SuperWifiResponse;
  @Input() podCountry: string;
  @Input() loading: boolean;
  @Input() tripDetail: TripViewModel;
  @Output() superwifiAnalyticsEmitter = new EventEmitter<string>();
  @Output() pageDataEmitter = new EventEmitter();
  constructor(private modalService: NgbModal) {}

  ngOnInit(): void {
    this.pageDataEmitter.emit();
  }
  ngOnChanges(changes: any) {
    if (changes.ancillaries && changes.ancillaries.currentValue) {
      this.superwifiAnalyticsEmitter.emit();
    }
  }
 displayVoucherDetails(glxProdVouchersResponse: GlxProdVouchersResponse[]) {
  if (glxProdVouchersResponse) {
    const modalRef = this.modalService.open(ModalComponent, { centered: true });
    modalRef.componentInstance.glxProdVouchers = glxProdVouchersResponse;
  }
 }
}

