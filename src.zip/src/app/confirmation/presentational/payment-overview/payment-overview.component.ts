import { Component, Input } from '@angular/core';
import { PaymentRecords } from '@app/models';

@Component({
  selector: 'qa-payment-overview',
  templateUrl: './payment-overview.component.html',
  styleUrls: ['./payment-overview.component.css'],
})
export class PaymentOverviewComponent {
  @Input() payment: PaymentRecords;
}

