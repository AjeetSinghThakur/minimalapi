import { Routes } from '@angular/router';
import { ContentComponent } from './container';

export const confirmationRoutes: Routes = [{ path: '', component: ContentComponent }];
