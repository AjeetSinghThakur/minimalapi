import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { confirmationRoutes } from './confirmation.routing';
import { SharedModule } from '@app/shared/shared.module';
import { ContentComponent } from '@app/confirmation/container';
import { PaymentOverviewComponent, PurchaseOverviewComponent } from './presentational';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(confirmationRoutes),
    SharedModule,
  ],
  exports: [
    ContentComponent,
    PaymentOverviewComponent,
    PurchaseOverviewComponent

  ],
  declarations: [
    ContentComponent,
    PaymentOverviewComponent,
    PurchaseOverviewComponent
  ],
  providers: [],
})
export class ConfirmationModule {}
