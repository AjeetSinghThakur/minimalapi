
export interface Dictionaries {
  equipment: Equipment;
  farefamily: Farefamily;
  location: Location;
  segmentDetails: SegmentDetails;
}
export interface Equipment {
  key: string;
  value: Value;
}
export interface Value {
  value: string;
}

export interface Equipment {
    key: string;
    value: Value;
}
export interface Farefamily {
  key: string;
  value: FamilyFareValue;
}
export interface FamilyFareValue {
  cabinClass: string;
  colourCode: string;
  name: string;
}
export interface SegmentDetails {
  key: string;
  value: SegmentValue;
}
export interface SegmentValue {
  arrivalDateScheduled: Date;
  arrivalDateScheduledUTC: Date;
  arrivalStation: string;
  arrivalTerminal: string;
  carrier: Carrier;
  depTerminal: string;
  departureDateScheduled: Date;
  departureDateScheduledUTC: Date;
  departureStation: string;
  durationInMinutes: number;
  equipmentCode: string;
  flightNumber: string;
  qSuite: boolean;
  segmentId: string;
  technicalStops: string[];
}
export interface Carrier {
  carrier: string;
  carrierName: string;
  flightNumber: string;
  operatingCarrier: string;
  operatingCarrierName: string;
}
