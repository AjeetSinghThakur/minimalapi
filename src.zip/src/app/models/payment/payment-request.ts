export interface PaymentRequest {
  cancelRedirectUrl: string;
  failureRedirectUrl: string;
  keepAliveURL: string;
  successRedirectUrl: string;
  termsAndConditionsUrl: string;
}
