import { Warning } from '../notifications';
import { ErrorObject } from '../trip-detail';

export interface HandshakeResponse {
  conversationToken: string;
  errorObject: ErrorObject;
  warnings: Warning[];
}

