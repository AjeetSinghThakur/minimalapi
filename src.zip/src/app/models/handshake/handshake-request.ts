
export interface HandshakeRequest {
  searchType?: string;
  searchValue?: string;
  lastName?: string;
  lang?: string;
  principal?: string;
  requestType?: string;
  conversationToken?: string;
}
