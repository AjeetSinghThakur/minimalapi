
export class AncillaryDetailsRequest {
 ancillaryProducts?: string[] = [];
}





