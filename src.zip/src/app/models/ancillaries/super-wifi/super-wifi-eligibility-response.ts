import { FlightIdentifier, ErrorObject } from '@app/models';
export interface SuperWifi {
  price: Price;
  productCode: string;
  superwifiAvailability: SuperwifiAvailability[];
  uniqueId: string;
}
export interface SuperwifiAvailability {
  eligibleStatus: string;
  flightIdentifier: FlightIdentifier;
}
export interface Price {
  amountInUSD: number;
  amounts: number;
  currency: string;
  usdExchangeRate: number;
}
export interface InventoryResponse {
  errorObject: ErrorObject;
}


