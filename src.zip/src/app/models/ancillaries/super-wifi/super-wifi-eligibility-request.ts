import { ContactDetail, PaxFlightIdentifier, Amount } from '@app/models';

export interface SuperWifiRequest {
  amount?: Amount;
  contactDetails: ContactDetail[];
  paxFlightIdentifiers?: PaxFlightIdentifier[];
  productCode: string;
  uniqueId?: string;
  voucherQuantity: number;
}

