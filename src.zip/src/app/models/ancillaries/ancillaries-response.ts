  import { Warning } from '../notifications';
  import { SuperWifi, SuperWifiRequest } from './super-wifi';
  import { Amount, TransactionInfo, PaymentRecords, ErrorObject, Trip } from '../trip-detail';

  export interface Ancillaries {
      errorObject: ErrorObject;
      warnings: Warning[];
      superWifi: SuperWifi[];
      loading: true;
  }
  export interface AncillariesResponse {
    tripObj: Trip;
    transactionInfo: TransactionInfo;
    eligibleAncillaryResponse: Ancillaries;
    superWifiResponse: SuperWifiResponse;
    paymentRecords: PaymentRecords;
    podCountry: string;
    platform: string;
    redirectDeeplinkUrl: string;
    errorObject: ErrorObject;
  }
  export interface SuperWifiResponse {
    glxProdVouchersResponse: GlxProdVouchersResponse[];
    totalAmount: TotalAmount;
  }
  export interface GlxProdVouchersResponse {
    voucherCode: string;
    voucherDescription: string;
    voucherExpiry: number;
    voucherExpiryUTC: number;
  }
  export interface TotalAmount {
    currency: string;
    amounts: number;
    amountInUSD: number;
  }
  export interface TripAncillaries {
  superWifiRequests: SuperWifiRequest[];
  totalAmount: Amount;
}
