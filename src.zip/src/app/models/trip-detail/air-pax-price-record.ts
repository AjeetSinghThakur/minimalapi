import { BaseFare, Fee, Surcharge, TotalFare } from '.';

export interface AirPaxTypePriceRecord {
  baseFare: BaseFare[];
  fee: Fee[];
  surcharge: Surcharge[];
  totalFare: TotalFare[];
  travellerType: string;
}
