export interface BookingInfo {
  bookingReferenceNumber: string;
  createdDate: Date;
  createdOfficeId: string;
  createdOnline: boolean;
  groupBooking: boolean;
  remarks: Remark[];
  skElement: string[];
}
export interface Remark {
  remarkText: string;
  remarkType: string;
}
