import { ContactDetail, EmergencyContactDetail } from './contact-details';
import {
  Journey,
  Passenger,
  PassengerFlightMapping,
  AirPaxTypePriceRecord,
  AirPriceRecord,
  BookingInfo
} from '.';
import { TripAncillaries } from '../ancillaries';

export interface Trip {
  journeyCount: number;
  tripStatus?: string;
  tripType?: string;
  contactDetails: ContactDetail[];
  emergencyContactDetails?: EmergencyContactDetail;
  journeys: Journey[];
  passengers: Passenger[];
  bookingInfo?: BookingInfo;
  passengerFlightMapping: PassengerFlightMapping[];
  tripBookingType: string;
  ancillaries?: TripAncillaries;
  airPaxTypePriceRecord?: AirPaxTypePriceRecord[];
  airPriceRecord?: AirPriceRecord;
  tripIdentifier?: TripIdentifier;
  tripReference: string;
  remarks: string[];
  skElements?: string[];
  paymentRecords?: PaymentRecords;
  eligibilityInfo?: any;
  tripName: string;
  tripCompletedOn: Date;
  transactionInfo: TransactionInfo;
  captchaRequired: boolean;
}
export interface PaymentRecords {
  cardNumber: string;
  cardHolderName: string;
  debitCard: boolean;
  authCode: string;
  paymentType: string;
  expirationMonth: string;
  expirationYear: string;
}
export interface TripIdentifier {
  uniqueIdentifier: string;
}

export interface TransactionInfo {
  appInfo1: string;
  appInfo2: string;
  appInfo3: string;
  transactionId: string;
}

export interface TripResponse {
  trip: Trip;
  errorObject: ErrorObject;
  redirectDeeplinkUrl: string;
}
export interface ErrorObject {
  errorCategory: string;
  errorDescription: string;
  errorName: string;
}
