import { PassengerIdentifier } from './passenger';

export class ContactDetail {
  passengerIdentifier?: PassengerIdentifier;
  primaryContactName?: string;
  contactType: string;
  countryCode?: string;
  value: string;
}
export class EmergencyContactDetail {
 firstName: string;
 contactCountry: string;
 contactNumber: string;
 updatingEmDetails: boolean;
 contactType: string;
 lastName: string;
}
