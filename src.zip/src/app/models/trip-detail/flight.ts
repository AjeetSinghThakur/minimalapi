export class FlightList {
  arrivalDateActual: Date;
  arrivalDateActualUTC: Date;
  arrivalDateEstimated: Date;
  arrivalDateEstimatedUTC: Date;
  arrivalDateScheduled: Date;
  arrivalDateScheduledUTC: Date;
  arrivalStation: Station;
  arrivalTerminal: string;
  boardingStatus: string;
  bookingInfo: FlightBookingInfo;
  cabinClass: string;
  carrier: Carrier;
  checkInInfo: CheckInInfo;
  connDurationInMinutes: number;
  depTerminal: string;
  departureDateActual: Date;
  departureDateActualUTC: Date;
  departureDateEstimated: Date;
  departureDateEstimatedUTC: Date;
  departureDateScheduled: Date;
  departureDateScheduledUTC: Date;
  departureStation: Station;
  durationInMinutes: number;
  equipmentDetails: EquipmentDetails;
  flightBookingStatus: string;
  flightIdentifier: FlightIdentifier;
  flightNumber: string;
  flightStatus: string;
  wifiAvailbilityStatus: string;
  lastUpdatedOn: Date;
  lastUpdatedSource: string;
  myTripsInfo: any;
  spiked: boolean;
  technicalStops: TechnicalStop[];
}
export class FlightIdentifier {
  productIdentifier?: string;
  uniqueIdentifier: string;
}
export interface Station {
  airport: string;
  airportCode: string;
  airportLongName: string;
  airportSearchMetaData: string;
  city: string;
  cityCode: string;
  citySearchMetaData: string;
  country: string;
  countryCode: string;
  iataCode: string;
  offSetInMinutes: number;
  onlineStation: boolean;
  searchMetaData: string;
  shorthand: string;
  stationType: string;
  terminal: string;
}
export interface FlightBookingInfo {
  bassinetAllowedForInfants: boolean;
  earnedMiles: number;
  eligibileForMealSelection: boolean;
  eligibleForUpgrade: boolean;
  fareBasis: string;
  flightLineNumber: string;
  flownIndicator: boolean;
  jbPartner: boolean;
  operatedOn: string;
  partnerAirline: boolean;
  partnerType: string;
  tatoo: string;
}
export class Carrier {
  carrier: string;
  carrierName?: string;
  operatingCarrier?: string;
  operatingCarrierName?: string;
  flightNumber: string;
}
export interface CheckInInfo {
  acceptanceCloseTime: Date;
  acceptanceCloseTimeUTC: Date;
  acceptanceOpenTime: Date;
  acceptanceOpenTimeUTC: Date;
  boardingCloseTime: Date;
  boardingCloseTimeUTC: Date;
  boardingOpenTime: Date;
  boardingOpenTimeUTC: Date;
  checkInStatus: string;
  checkInStatusDCS: string;
  connectFlightIdentifier: ConnectFlightIdentifier;
  fastBaggageCounterTime: Date;
  gateCloseTime: Date;
  isSeatMapEnabled: boolean;
  onlineAcceptanceCloseTime: Date;
  onlineAcceptanceCloseTimeUTC: Date;
  onlineAcceptanceOpenTime: Date;
  onlineAcceptanceOpenTimeUTC: Date;
  securityCloseTime: Date;
}
export class ConnectFlightIdentifier {
  productIdentifier: string;
  uniqueIdentifier?: string;
}
export interface EquipmentDetails {
  equipmentCode: string;
  equipmentName: string;
}
export class TechnicalStop {
  airportCode?: string;
  airportName?: string;
  airportCity?: string;
  onlineStation?: boolean;
  railStation?: boolean;
  busStation?: boolean;
  qrStation?: boolean;
  active?: boolean;
}
