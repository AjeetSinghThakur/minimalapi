import { FlightList } from './flight';

export interface Journey {
  journeyId: number;
  arrivalCity: string;
  arrivalCountryCode: string;
  arrivalDate: Date;
  arrivalDateETD: Date;
  arrivalStationCode: string;
  bookingInfo: JourneyBookingInfo;
  checkInStatus: string;
  departureCity: string;
  departureCountryCode: string;
  departureDate: Date;
  departureDateETD: Date;
  departureStationCode: string;
  durationInMinutes: number;
  flightList: FlightList[];
  journeyDirection: string;
  journeyStatus: string;
  myTripsInfo: any;
  technicalStops: number;
  transitPoints: number;
  uniqueJourneyIdentifier: UniqueJourneyIdentifier;
}
export class UniqueJourneyIdentifier {
  productIdentifier: string;
  uniqueIdentifier: string;
}
export interface JourneyBookingInfo {
  allowJourneyRebook: boolean;
  fareFamily: string;
}
