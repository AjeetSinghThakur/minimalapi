import { FlightIdentifier } from './flight';
import { TripIdentifier } from './trip';

/* Passenger */
export interface Passenger {
  address: Address[];
  apisInformation: ApisInformation;
  apisRequirements: ApisRequirements;
  associatedInfantIdentifier: AssociatedInfantIdentifier;
  booking: Booking;
  checkIn: CheckIn;
  dateOfBirth: Date;
  firstName: string;
  gender: string;
  lastName: string;
  middleName: string;
  myTrips: any;
  passengerIdentifier: PassengerIdentifier;
  passengerType: string;
  primaryPassenger: boolean;
  profileDetails: ProfileDetails;
  redressNumber: string;
  staffPassengerDetails: StaffPassengerDetails;
  title: string;
}
export class Address {
  city: string;
  country: string;
  journeyIdentifiers: string[];
  state: string;
  street: string;
  type: string;
  zipCode: string;
}
export interface ApisInformation {
  countryOfResidenceCodes?: string;
  nationalityCode?: string;
  documents: Document[];
}
export interface ApisRequirements {
  applicableCountryReqd: boolean;
  countryOfResidenceDisplay: boolean;
  countryOfResidenceReqd: boolean;
  destinationAddressReqd: boolean;
  destinationCityReqd: boolean;
  destinationCountryReqd: boolean;
  destinationStateReqd: boolean;
  destinationStreetReqd: boolean;
  destinationZipReqd: boolean;
  dobDisplay: boolean;
  dobReqd: boolean;
  genderReqd: boolean;
  givenNameReqd: boolean;
  homeAddressReqd: boolean;
  homeCityReqd: boolean;
  homeCountryReqd: boolean;
  homeStateReqd: boolean;
  homeStreetReqd: boolean;
  homeZipReqd: boolean;
  nationalityDisplay: boolean;
  nationalityReqd: boolean;
  passportCountryOfIssueReqd: boolean;
  passportExpiryDateReqd: boolean;
  passportIssueDateReqd: boolean;
  passportNumberReqd: boolean;
  passportReqd: boolean;
  placeOfBirthReqd: boolean;
  purposeOfVisitReqd: boolean;
  redressNumberDisplay: boolean;
  redressNumberReqd: boolean;
  surnameReqd: boolean;
  titleReqd: boolean;
  visaCityIssueReqd: boolean;
  visaCountryOfIssueReqd: boolean;
  visaExpiryDateReqd: boolean;
  visaIssueDateReqd: boolean;
  visaNumberReqd: boolean;
  visaReqd: boolean;
  visaSource: string;
}
export interface AssociatedInfantIdentifier {
  uniqueIdentifier: string;
}
export interface Booking {
  passengerAgeValidation: PassengerAgeValidation;
}
export interface PassengerAgeValidation {
  adultMaxAgeLimit: number;
  adultMinAgeLimit: number;
}
export class Document {
  applicableCountry: string;
  category: string;
  cityOfIssue: string;
  countryOfIssue: string;
  documentIdentifier: DocumentIdentifier;
  documentReferenceNumber: string;
  documentRequirements: DocumentRequirements;
  documentSource: string;
  documentType: string;
  expiryDate: Date;
  issuedDate: Date;
  journeyIdentifiers: string[];
  placeOfIssue: string;
  purposeOfVisit: string;
  remarks: string;
  scope: string;
  seqNo: string;
  tripIdentifier: TripIdentifier;
  valid: boolean;
}
export interface DocumentIdentifier {
  uniqueIdentifier: string;
}
export class DocumentRequirements {
  documentNumberReqd?: boolean;
  documentNumberDisplay?: boolean;
  expiryDateReqd?: boolean;
  expiryDateDisplay?: boolean;
  issuedDateReqd?: boolean;
  issuedDateDisplay?: boolean;
  placeOfIssueReqd?: boolean;
  placeOfIssueDisplay?: boolean;
  countryOfIssueReqd?: boolean;
  countryOfIssueDisplay?: boolean;
  cityOfIssueReqd?: boolean;
  cityOfIssueDisplay?: boolean;
}
export class PassengerIdentifier {
  productIdentifier: string;
  uniqueIdentifier?: string;
  eRetaiIdentifier?: string;
}
export class StaffPassengerDetails {
 staffId?: string;
 ticketType?: string;
 staffCategory: string;
 companyCode?: string;
 upgradable: boolean;
}
export class ProfileDetails {
  customerProfileId?: number;
  ffpCarrierCode?: string;
  ffpNumber?: string;
  owTierCode?: string;
  qbizCode?: string;
  qrTierCode?: string;
}
export interface CheckIn {
  apisDetailsComplete: boolean;
  bpNotIssuedReason: string;
  countryCode: string;
  editFields: string[];
  emReqFlightList: string[];
  emailId: string;
  inCompleteField: string;
  mobileNumber: string;
  nonTransactionPassReason: string;
  offloadAvailable: boolean;
  seatChangeAvailable: boolean;
  specialServiceRequestDetails: SpecialServiceRequestDetail[];
  timaticStatus: string;
  visaEvaluationMessages: string[];
}

/* Passenger flight mapping  */
export interface PassengerFlightMapping {
  checkInInfo?: PassengerCheckInInfo;
  checkedInBaggage?: CheckedInBaggage[];
  couponDetail?: CouponDetail;
  excessBaggageDetail?: ExcessBaggageDetail[];
  mealPreference?: MealPreference;
  noOfBags: number;
  pasengerTimelineInfo?: PasengerTimelineInfo;
  passengerRegraded: boolean;
  paxFlightIdentifier: PaxFlightIdentifier;
  remarks?: PassengerRemark[];
  seatPreference?: SeatPreference;
  specialServiceRequestDetails?: SpecialServiceRequestDetail[];
  travelCabinClass: string;
}
export interface SeatPreference {
  assignedSeat: string;
  assignedSeatType: string[];
  preferredSeat: string;
  preferredSeatType: string[];
  requestedSeat: string;
  requestedSeatType: string[];
  seatSsrStatus: string;
}
export interface PassengerRemark {
  remarkText: string;
  remarkType: string;
}
export interface MealPreference {
  mealCode: string;
  mealDescription: string;
  status: string;
}
export interface ExcessBaggageDetail {
  blockSize: number;
  journeyIdentifier: JourneyIdentifier;
  maxWeight: number;
  minWeight: number;
  pieces: number;
  productCode: string;
  uniqueId: string;
}
export interface JourneyIdentifier {
  journeyIndex: number;
  uniqueIdentifier: string;
}
export interface SpecialServiceRequestDetail {
  amount: Amount;
  category: string;
  chargeable: boolean;
  code: string;
  description: string;
  eligibilityKeyIndex: string;
  lineNumber: number;
  remarks: string;
  selectionKeyKeyIndex: string;
  serviceIdentifier: ServiceIdentifier;
  serviceType: string;
  status: string;
  subCategory: string;
}
export interface Amount {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}
export class ServiceIdentifier {
  uniqueIdentifier: string;
}
export class CheckedInBaggage {
  baggageRefId?: string;
  baggageUId?: string;
  external?: boolean;
  bagTagNo?: string;
  bagStatus?: string;
  weight?: number;
  isSelected?: boolean;
}
export class PaxFlightIdentifier {
  productIdentifier?: any;
  uniqueIdentifier?: any;
  passengerIdentifier: PassengerIdentifier;
  flightIdentifier: FlightIdentifier;
}
export class CouponDetail {
  couponNumber: string;
  couponStatus: string;
  couponUsed: boolean;
  eticketNumber: string;
  validFrom: Date;
  validTo: Date;
}
export class PasengerTimelineInfo {
  boardingStatus: string;
  bookingStatus: string;
  checkinStatus: string;
  dcsCheckinStatus: string;
}
export class PassengerCheckInInfo {
  adcAction: string;
  apiFlagPresent: boolean;
  baggageAllowance: BaggageAllowance[];
  baggageDetail: BaggageDetail[];
  barCode: string;
  boardingId: string;
  comments: Comment[];
  issuedDocs: IssuedDoc[];
  rbd: string;
  securityNumber: string;
  zoneInfo: string;
}
export interface BaggageDetail {
  bagStatus: string;
  bagTagIdentifier: string;
  bagTagIssuerCode: string;
  bagTagNo: string;
  baggageRefId: string;
  baggageType: string;
  baggageUId: string;
  carrierCode: string;
  external: boolean;
  finalDestinationStationCode: string;
  generatedFrom: string;
  originStationCode: string;
  piecies: number;
  serialNumber: string;
  weight: number;
}
export interface IssuedDoc {
  boardingPassIssued: boolean;
  documentCode: string;
  documentDesc: string;
  documentSubVariant: string;
  documentType: string;
  documentVariant: string;
  documentVariantReason: string;
}
export class BaggageAllowance {
  totalWeight?: number;
  unit?: string;
  baggageType?: string;
  dimension?: string;
  pieceQuantity?: number;
}
