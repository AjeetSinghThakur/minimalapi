export interface BaseFare {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}

export interface Fee {
  amount: number;
  code: string;
  currency: string;
  description: string;
}

export interface Surcharge {
  amount: number;
  code: string;
  currency: string;
  description: string;
}

export interface TotalFare {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}

export interface ResidualFare {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}

export interface TotalFee {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}
export interface AdditionalFareToCollect {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}
export interface TotalSurcharge {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}
export interface Totaltax {
  amount: number;
  amountInUSD: number;
  currency: string;
  usdExchangeRate: number;
}
