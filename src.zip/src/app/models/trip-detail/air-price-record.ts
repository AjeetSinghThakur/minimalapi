import {
  BaseFare,
  TotalFare,
  ResidualFare,
  TotalFee,
  AdditionalFareToCollect,
  TotalSurcharge,
  Totaltax
} from '.';

export interface AirPriceRecord {
  additionalFareToCollect: AdditionalFareToCollect[];
  baseFare: BaseFare[];
  residualFare: ResidualFare[];
  totalFare: TotalFare[];
  totalFee: TotalFee[];
  totalSurcharge: TotalSurcharge[];
  totaltax: Totaltax[];
}
