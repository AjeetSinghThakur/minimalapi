import { Aircraft } from '../seats';
export interface JourneyViewModel {
  journeyId: number;
  arrivalAirportCode: string;
  departureAirportCode: string;
  arrivalStation: string;
  departureStation: string;
  departureDate: Date;
  arrivalDate: Date;
  changeFlight?: boolean;
  flights?: FlightViewModel[];
}

export interface FlightViewModel {
  uniqueIdentifier: string;
  wifiStatus?: string;
  operatingCarrier?: string;
  flightNumber?: string;
  departureStation: string;
  arrivalStation: string;
  departureCity?: string;
  arrivalCity?: string;
  flightType?: string;
  isAccordianOn?: boolean;
  aircraft: Aircraft;
  passengers?: PassengerViewModel[];
}

export interface DestinationDetailModel {
  departureDate?: Date;
  arrivalDate?: Date;
  departureCity?: string;
  arrivalCity?: string;
  returnTrip?: boolean;
  departureCodeAirportCode: string;
  arrivalAirportCode: string;
}

export interface PassengerViewModel {
  uniqueIdentifier: string;
  productIdentifier: string;
  seatNo?: string;
  firstName: string;
  lastName: string;
  title: string;
  gender: string;
  paxType: string;
  deckLocation?: string;
  row?: string;
  amount?: string;
  currency?: string;
}
export interface AmountView {
  totalAmount: number;
  currency: string;
}
export interface FlightGroup {
  rowGroupList: RowGroupData[];
}
export interface RowGroupData {
  rowHeaderGroup: string;
  rowNumber?: string;
  columnGroupList: ColumnGroupData[];
  isExit?: boolean;
  isQuadeSeat?: boolean;
  isBassinet?: boolean;
}
export interface ColumnGroupData {
  columnFullName: string;
  columnName: string;
  columnNumber: string;
  display: string;
  uiDisplay?: string;
  isSelectedPaxSeat?: boolean;
  isCoPassengerSeat?: boolean;
  seatPlacement?: string;
  // uiRearFace?: string;
  // restricted?: boolean;
  isAisleSeat?: boolean;
  seatChar?: string[];
  amount?: string;
  currency?: string;
  extendedSeatDetail?: string;
  buttonText?: string;
  assigneeName?: string;
}
export interface SelectedFlightGroup {
  rowNumber: string;
  rowGroupList: RowGroupData[];
}
export interface SeatConfig {
  quadSeats: QuadSeat[];
}
export interface QuadSeat {
   column: string;
   number: string;
}
export interface FlightGroup {
  rowGroupList: RowGroupData[];
}
export interface RBDCodes {
  alphabet: string;
  isAisle: boolean;
}
