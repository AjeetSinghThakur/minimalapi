import { Price } from '../ancillaries';

export interface FlightListViewModel {
    wifiStatus: string;
    operatingCarrier: string;
    flightNumber?: string;
    departureStation?: string;
    arrivalStation?: string;
    departureCity?: string;
    arrivalCity?: string;
    flightType?: string;
}

export interface DestinationDetailsViewModel {
    departureDate?: Date;
    arrivalDate?: Date;
    departureCity?: string;
    arrivalCity?: string;
    returnTrip?: boolean;
    departureCodeAirportCode: string;
    arrivalAirportCode: string;
}

export interface TripViewModel {
    tripType?: string;
    tripReference?: string;
    destinationDetails?: DestinationDetailsViewModel;
    // One way and Two flights
    flights?: FlightListViewModel[];
    // Multicity Flights inside it
    journeyList?: JourneModel[];
    allWifiFlight?: boolean;
}

export interface VoucherFormViewModel {
    voucherQuantity?: number;
    email: string;
    repeatedEmail?: string;
    countryCode?: string;
    mobileNumber?: string;
    priceConfig: Price;
}
export interface AmountOverView {
  totalAmount: number;
  currency: string;
}
export interface JourneModel {
  arrivalAirportCode: string;
  arrivalCity: string;
  departureCity: string;
  departureCodeAirportCode: string;
  flights?: FlightListViewModel[];
}
