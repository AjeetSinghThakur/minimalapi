import { ErrorObject } from '../trip-detail';

export interface SeatMapResponse {
  seatMap: SeatMap;
  errorObject: ErrorObject;
}
export interface Aircraft {
  equipmentCode: string;
  equipmentName: string;
}
export interface Column {
  column: string;
  number: string;
  display: string;
  seatCharacteristic: string[];
  amount?: string;
  currency: string;
  higherCharge: boolean;
}

export interface Row {
  rowNumber: string;
  columns: Column[];
  rowCharacteristics: string[];
}

export interface DeckCabin {
  deckLocation: string;
  rows: Row[];
  columnsList: string[];
  aisleColumns: string[];
}

export interface Deck {
  deckLocation: string;
  deckCompartment: DeckCabin[];
}

export interface SeatMap {
  location?: string;
  cabinClass: string;
  decks: Deck[];
  paxs?: any;
  seatString: string;
  groupBooking: boolean;
}




