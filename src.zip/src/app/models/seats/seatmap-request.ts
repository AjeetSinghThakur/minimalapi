import { FlightIdentifier } from '../trip-detail';

export interface SeatMapRequest {
  flightIdentifier: FlightIdentifier;
}
