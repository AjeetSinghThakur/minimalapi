import { Message } from './base.message';

export interface InfoMessage extends Message  {
}
