import { WarningMessage } from './warning-message';
import { ErrorMessage } from './error-message';
import { InfoMessage } from './info-message';
import { SuccessMessage } from './success-message';

export interface MessageModel {
  seqNumber?: number;
  category: MessageCategory;
  errors?: ErrorMessage[];
  warnings?: WarningMessage[];
  success?: SuccessMessage[];
  infos?: InfoMessage[];
}
export { ErrorMessage } from './error-message';
export { WarningMessage } from './warning-message';
export { SuccessMessage } from './success-message';
export { InfoMessage } from './info-message';

export enum MessageCategory { Error = 'error', Warning = 'warning', Success = 'success', info = 'info'}
