  export interface Source {
    parameter: string;
    pointer: string;
}
  export interface Error {
    code: string;
    detail: string;
    source: Source;
    status: string;
    title: string;
}
  export interface Warning {
    code: string;
    detail: string;
    source: Source;
    title: string;
}
