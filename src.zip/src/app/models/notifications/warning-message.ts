import { Message } from './base.message';

export interface WarningMessage extends Message {
}
