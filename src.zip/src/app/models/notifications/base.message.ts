export interface Message {
   /** An application-specific error code */
   code?: string;
   /** A short summary of the error */
   title: string;
   /** Explanation of the error */
   detail?: string;
}
