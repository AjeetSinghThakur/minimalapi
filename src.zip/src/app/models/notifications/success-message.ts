import { Message } from './base.message';

export interface SuccessMessage extends Message {
}
