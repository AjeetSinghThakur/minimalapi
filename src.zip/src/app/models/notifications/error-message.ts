import { Message } from './base.message';
export interface ErrorMessage extends Message {
  /** HTTP status code associated */
  status?: string;
}
export interface ErrorDetail {
  errorCategory: string;
  errorName: string;
}
