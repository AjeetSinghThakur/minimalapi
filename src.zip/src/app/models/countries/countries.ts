export interface CountryDetail {
    countryCode: string;
    countryName: string;
    isdCode: string;
}

