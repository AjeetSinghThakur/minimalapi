export interface AnclillaryDetail {
    name: string;
    currencyCode: string;
    amount: number;
    routerName: string;
    wifiImage: string;

}

