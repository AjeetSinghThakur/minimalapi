import { SuperWifiRequest } from '../ancillaries';
import { Amount, ErrorObject } from '../trip-detail';
import { PaymentRequest } from '../payment';

export interface AncillaryRequest {
  superWifiRequests?: SuperWifiRequest[];
  platform ?: string;
  preferedCountry?: string;
  totalAmount?: Amount;
}
export interface PaymentResult {
  paymentRedirectUrl: string;
  errorObject: ErrorObject;
}
