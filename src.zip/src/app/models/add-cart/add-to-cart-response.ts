import { Warning, Error } from '../notifications';
import {
 AirPaxTypePriceRecord,
 AirPriceRecord,
 BookingInfo,
 ContactDetail,
 EmergencyContactDetail,
 Journey,
 PassengerFlightMapping,
 Passenger
} from '../trip-detail';
import { TripAncillaries } from '../ancillaries';

export interface AddToCartResponse {
  errors?: Error[];
  warnings?: Warning[];
  data: CartData;
}
export interface CartData {
  airPaxTypePriceRecord: AirPaxTypePriceRecord[];
  airPriceRecord: AirPriceRecord[];
  ancillaries?: TripAncillaries;
  bookingInfo: BookingInfo;
  cartIdentifier: CartIdentifier;
  contactDetails: ContactDetail[];
  emergencyContactDetails: EmergencyContactDetail[];
  journeyCount: number;
  journeys: Journey[];
  passengerFlightMapping: PassengerFlightMapping[];
  passengers: Passenger[];
  tripBookingType: string;
  tripStatus: string;
  tripType: string;
}
export interface CartIdentifier {
  uniqueIdentifier: string;
}

