import { Injectable } from '@angular/core';
import { Router, PreloadingStrategy, Route, NavigationEnd } from '@angular/router';
import { Observable, of } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';

export interface OnDemandPreloadingData {
  preloadOn: string[] | '*';
}

export function hasPreloadingOnDemand(data: any): data is OnDemandPreloadingData {
  return !!data &&
  ((Array.isArray(data.preloadOn) && !!data.preloadOn.length) || data.preloadOn === '*');
}

@Injectable({
  providedIn: 'root'
})
export class OnNavigationPreloadingStrategy implements PreloadingStrategy {

  constructor(private router: Router) {}

  /** @inheritDoc */
  preload(route: Route, preload: () => Observable<any>): Observable<any> {

    if (route.path && hasPreloadingOnDemand(route.data)) {
      // On application landing page, check the route to preload
      if (route.data.preloadOn === '*' || route.data.preloadOn.indexOf(this.router.routerState.snapshot.url) !== -1) {
        return preload();
      }

      // On route navigation end, load the routes to preload for the current route
      return this.router.events
        .pipe(
          filter((r) => r instanceof NavigationEnd && route.data!.preloadOn.indexOf(r.url) !== -1),
          switchMap(() => preload())
        );
    }
    return of(null);
  }
}
