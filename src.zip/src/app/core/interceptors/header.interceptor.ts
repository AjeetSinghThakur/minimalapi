import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { first, mergeMap } from 'rxjs/operators';
import { AncillariesStoreFacade } from '@app/store/ancillaries-store.facade';

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  constructor(private ancillariesStoreFacade: AncillariesStoreFacade) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return this.ancillariesStoreFacade.authToken$.pipe(
      first(),
      mergeMap(authToken => {
        const authReq = !!authToken ? request.clone({
          setHeaders: { Authorization: 'Bearer ' + authToken },
        }) : request;
        return next.handle(authReq);
      })
    );
  }
}

