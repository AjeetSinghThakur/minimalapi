import { Inject } from '@angular/core';
import { EnvironmentConfiguration, LOCALIZATION_ENVIRONMENT_TOKEN } from '@app/shared/configurations';
import { HttpWrapperService } from '@app/shared/services';

export abstract class ConfigService {
  constructor(private http: HttpWrapperService,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration) {
  }
  protected get httpWrapper() { return this.http; }
  protected get getApiUrl() { return this.environmentConfiguration.apiUrl; }
  protected get getOfferUrl() { return this.environmentConfiguration.offerUrl; }
  protected get getSystemPathUrl() { return this.environmentConfiguration.systemPathUrl; }
}
