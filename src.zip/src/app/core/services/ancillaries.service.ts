import { Inject, Injectable } from '@angular/core';
import { EnvironmentConfiguration, LOCALIZATION_ENVIRONMENT_TOKEN, EditableConfiguration } from '@app/shared/configurations';
import { HttpWrapperService } from '@app/shared/services';
import { Observable } from 'rxjs';
import {
  Ancillaries,
  AncillaryRequest,
  AncillariesResponse,
  TripResponse,
  CountryDetail,
  PaymentResult,
  InventoryResponse,
  SeatMapResponse
} from '@app/models';
import { ConfigService } from './config.service';
@Injectable({
  providedIn: 'root'
})
export class AncillariesService extends ConfigService {
  constructor(http: HttpWrapperService,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) environmentConfiguration: EnvironmentConfiguration) {
                super(http, environmentConfiguration);
  }

  retrieveEligibleAncillaries(): Observable<Ancillaries> {
    return this.httpWrapper.post<Ancillaries>(this.getApiUrl + '/ancillaries', {});
  }
  proceedWithPayment(ancillaryRequest: AncillaryRequest): Observable<PaymentResult> {
    return this.httpWrapper.post<PaymentResult>(this.getApiUrl + '/payment', ancillaryRequest);
  }
  ancillariesConfirm(): Observable<AncillariesResponse> {
    return this.httpWrapper.post<AncillariesResponse>(this.getApiUrl + '/confirm', {});
  }
  loadTrip(): Observable<TripResponse> {
    return this.httpWrapper.get<TripResponse>(location.origin + '/' + this.getSystemPathUrl + '/trip.json');
  }
  loadEditableAncillariesConfig(): Observable<EditableConfiguration> {
    return this.httpWrapper.get<EditableConfiguration>(location.origin + '/' + this.getSystemPathUrl + '/editableConfig.json');
  }
  loadSeatMap(): Observable<SeatMapResponse> {
    return this.httpWrapper.get<SeatMapResponse>(location.origin + '/' + this.getSystemPathUrl + '/seat-map.json');
  }
  loadCountriesInfo(): Observable<CountryDetail[]> {
    return this.httpWrapper.get<CountryDetail[]>(this.getApiUrl + '/countries');
  }
  unblockInventory(): Observable<InventoryResponse> {
    return this.httpWrapper.get<InventoryResponse>(this.getApiUrl + '/unblock');
  }
}
