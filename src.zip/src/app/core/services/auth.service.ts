import { Injectable, Inject } from '@angular/core';
import { HttpWrapperService } from '@app/shared/services';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';
import { HandshakeRequest, HandshakeResponse } from '@app/models';
import { Observable } from 'rxjs';
import { ConfigService } from './config.service';
import { HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService extends ConfigService {

  constructor(http: HttpWrapperService, @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) environmentConfiguration: EnvironmentConfiguration) {
    super(http, environmentConfiguration);
  }

  handshakeRequest(request: HandshakeRequest): Observable<HttpResponse<HandshakeResponse>> {
    return this.httpWrapper.postWithHttpResponse<HandshakeResponse>(this.getApiUrl + '/handshake',
    request, { observe: 'response' });
  }
}
