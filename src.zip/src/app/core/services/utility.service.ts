import { Injectable } from '@angular/core';
import { SHORT_IPHONE, IPHONE_OPERATING_SYSTEM, SHORT_ANDROID, ANDROID } from '@app/shared/constants';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  platform: string;

  isMobileTablet(): boolean {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        return true;
    }
    return false;
  }
  setPlatform(platform: string) {
    this.platform = platform ? platform : '';
  }
  isMobileApp() {
    return this.platform &&  (this.platform === SHORT_ANDROID || this.platform === SHORT_IPHONE) ? true : false;
  }
  getPlatForm() {
      return SHORT_IPHONE === this.platform ? IPHONE_OPERATING_SYSTEM : ANDROID;
  }
}
