import { Injectable, OnInit } from '@angular/core';
import { UtilityService } from './utility.service';
import {
  SHORT_IPHONE,
  IPHONE,
  IPHONE_OPERATING_SYSTEM,
  SHORT_ANDROID,
  ANDROID,
  MOBILE_WEBSITE,
  DESKTOP_WEBSITE,
  SCODE,
  ONEWAY_CODE,
  ONEWAY_VALUE,
  RETURN_CODE,
  RETURN_VALUE,
  MULTICITY_CODE,
  MULTICITY_VALUE,
  MULTICITY,
  WIFI_AVAILABLE,
  WIFI,
  WIFI_CHANNEL,
  TOUCH_POINT,
  PAGE_CATEGORY,
  GLOBAL
} from '@app/shared/constants';
import { TripViewModel, FlightListViewModel, SuperWifiResponse } from '@app/models';
import { AbstractLocalizationService } from '@app/shared/services';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class OmnitureService implements OnInit {
  private s = window[SCODE];
  constructor(private utilityService: UtilityService,
              private cookieService: CookieService,
              private abstractLocalizationService: AbstractLocalizationService) { }

  ngOnInit(): void {
  }
  setDefaultAnalytics(): void {
    this.clearAnalytics();
    this.s.eVar35 = this.utilityService.isMobileTablet() ? MOBILE_WEBSITE : DESKTOP_WEBSITE;
    this.setMobileTrackingData();
  }
  setMobileTrackingData() {
    if (SHORT_IPHONE === this.utilityService.platform && this.utilityService.isMobileApp()) {
      this.s.eVar35 = IPHONE;
      this.s.evar36 = IPHONE_OPERATING_SYSTEM;
    } else if (SHORT_ANDROID === this.utilityService.platform  && this.utilityService.isMobileApp()) {
      this.s.eVar35 =  this.s.evar36 = ANDROID;
    }
  }
  setSuperwifiAnalytics(trip: TripViewModel, pageName?: string, events?: string,
                        superwifi: SuperWifiResponse = null, podCountry = '' ): void {
    if (trip) {
      const preferredLang = this.cookieService.get('Language-Preferred') ?
      this.cookieService.get('Language-Preferred').toLowerCase() : GLOBAL;
      if (trip && trip.destinationDetails) {
        this.s.eVar59 = trip.destinationDetails.departureCodeAirportCode.toLowerCase();
        this.s.eVar60 = trip.destinationDetails.arrivalAirportCode.toLowerCase();
      } else {
        this.s.eVar59 = trip.journeyList[0].departureCodeAirportCode.toLowerCase();
        this.s.eVar60 = trip.journeyList[trip.journeyList.length - 1 ].arrivalAirportCode.toLowerCase();
      }
      this.s.channel = WIFI_CHANNEL;
      this.s.eVar86 = this.s.pageName = pageName;
      this.s.events = events;
      this.s.eVar11 = trip.tripReference.toLowerCase();
      this.s.eVar7 = trip.tripType ? this.getTripType(trip.tripType) : '' ;
      this.s.eVar1 = this.abstractLocalizationService.getCurrentLanguage();
      this.s.eVar52 = TOUCH_POINT;
      this.s.eVar100 = PAGE_CATEGORY;
      this.s.eVar10 = preferredLang;
      if (superwifi) {
        const wifiFlights: FlightListViewModel[] = trip.tripType === MULTICITY ?
        trip.journeyList.reduce((tr, jr) => [ ...tr, ...jr.flights.filter(x => x.wifiStatus === WIFI_AVAILABLE )], []) :
        trip.flights.filter(x => x.wifiStatus === WIFI_AVAILABLE);

        if (wifiFlights) {
        let flights: string;
        wifiFlights.forEach(flight => { !flights ? flights = flight.operatingCarrier + flight.flightNumber :
        flights = flights + '|' + flight.operatingCarrier + flight.flightNumber; });
        this.s.eVar111 = flights;
        }
        this.s.products = this.buildProductsAnalytics(podCountry, trip, superwifi);
      }
      this.s.t();
    }
  }
  buildProductsAnalytics(podCountry: string, trip: TripViewModel, superwifi: SuperWifiResponse ): string {
    const country: string = podCountry ? podCountry.toLowerCase() : '';
    const departureCity = trip && trip.destinationDetails ? trip.destinationDetails.departureCodeAirportCode.toLowerCase() :
    trip.journeyList[0].departureCodeAirportCode.toLowerCase();
    const arrivalCity = trip && trip.destinationDetails ? trip.destinationDetails.arrivalAirportCode.toLowerCase() :
    trip.journeyList[trip.journeyList.length - 1 ].arrivalAirportCode.toLowerCase();
    const numberOfVoucherPurchased = superwifi.glxProdVouchersResponse.length;
    const amount = numberOfVoucherPurchased * superwifi.totalAmount.amountInUSD;
    return `${country};${departureCity}-${arrivalCity}-${WIFI};;;event128=${amount}|event129=${numberOfVoucherPurchased}`;
  }
  getTripType(tripType: string) {
    return ONEWAY_CODE === tripType ? ONEWAY_VALUE : RETURN_CODE === tripType ?
    RETURN_VALUE : MULTICITY_CODE === tripType ? MULTICITY_VALUE : '';
  }
  clearAnalytics() {
    this.s.clearVars();
  }
}
