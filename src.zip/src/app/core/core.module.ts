import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { HeaderInterceptor, ErrorInterceptor } from './interceptors';
import { EnsureModuleLoadedOnceGuard } from '@app/shared/guards';
import { LOCALIZATION_ENVIRONMENT_TOKEN, DEFAULT_ENVIRONMENT_CONFIGURATION } from '@app/shared/configurations';

@NgModule({
  imports: [],
  exports: [],
  declarations: [],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HeaderInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: LOCALIZATION_ENVIRONMENT_TOKEN, useValue: DEFAULT_ENVIRONMENT_CONFIGURATION }
  ],
})

export class CoreModule extends EnsureModuleLoadedOnceGuard {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    super(parentModule);
  }
}

