import { Routes } from '@angular/router';
import * as sharedcomponents from './shared/components';

export const appRoutes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/notfound',
    data: { title: 'Super Wifi' }
  },
  {
    path: 'seats',
    loadChildren: () => import('@app/seats/seats.module').then(m => m.SeatsModule),
    data: { title: 'Seats' }
  },
  {
    path: 'checkout',
    loadChildren: () => import('@app/checkout/checkout.module').then(m => m.CheckoutModule),
    data: { title: 'checkout' }
  },
  {
    path: 'dashboard/:pnr/:lastName/:lang',
    loadChildren: () => import('@app/dashboard/dashboard.module').then(m => m.DashboardModule),
    data: { title: 'dashboard' }
  },
  {
    path: 'dashboard/:pnr/:lastName/:lang/:token',
    loadChildren: () => import('@app/dashboard/dashboard.module').then(m => m.DashboardModule),
    data: { title: 'dashboard' }
  },
  {
    path: 'superwifi/:pnr/:lastName/:lang/:platform',
    loadChildren: () => import('@app/superwifi/superwifi.module').then(m => m.SuperwifiModule),
    data: { title: 'Super Wifi' }
  },
  {
    path: 'superwifi/:pnr/:lastName/:lang/:token/:platform',
    loadChildren: () => import('@app/superwifi/superwifi.module').then(m => m.SuperwifiModule),
    data: { title: 'Super Wifi' }
  },
  {
    path: 'confirmation/:conversationToken/:lang/:platform',
    loadChildren: () => import('@app/confirmation/confirmation.module').then(m => m.ConfirmationModule),
    data: { title: 'Confirmation', preloadOn: ['/superwifi'] }
  },
  {
    path: 'notfound',
    component: sharedcomponents.PageNotFoundComponent,
    data: { title: 'Not Found' }
  },
  {
    path: '**',
    component: sharedcomponents.PageNotFoundComponent,
    data: { title: 'Not Found' }
  }
];
