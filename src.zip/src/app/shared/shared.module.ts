import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { translateLoaderProvider } from './translations';
import {
  HeaderComponent,
  CartComponent,
  BannerComponent,
  PageNotFoundComponent,
  FooterComponent,
  JourneyComplementComponent,
  QaNotificationComponent,
  ModalComponent,
  PaxListComponent,
  FlightDetailsComponent,
  JourneyDetailsComponent,
  PriceOverviewComponent
} from './components';
import { TextDirectionDirective, NumberOnlyDirective, FieldValidationDirective } from './directives';
import { FilterPipe, LocalizationTranslatePipe, DurationPipe } from './pipes';
import { Configuration, LOCALIZATION_CONFIGURATION_TOKEN, DEFAULT_LOCALIZATION_CONFIGURATION } from './configurations';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule.forChild({loader: translateLoaderProvider}),
  ],
  exports: [
    TranslateModule,
    HeaderComponent,
    CartComponent,
    BannerComponent,
    PageNotFoundComponent,
    FooterComponent,
    JourneyComplementComponent,
    QaNotificationComponent,
    ModalComponent,
    TextDirectionDirective,
    FilterPipe,
    LocalizationTranslatePipe,
    DurationPipe,
    NumberOnlyDirective,
    FieldValidationDirective,
    PaxListComponent,
    FlightDetailsComponent,
    JourneyDetailsComponent,
    PriceOverviewComponent
  ],
  declarations: [
    HeaderComponent,
    CartComponent,
    BannerComponent,
    PageNotFoundComponent,
    FooterComponent,
    JourneyComplementComponent,
    QaNotificationComponent,
    ModalComponent,
    TextDirectionDirective,
    FilterPipe,
    LocalizationTranslatePipe,
    DurationPipe,
    NumberOnlyDirective,
    FieldValidationDirective,
    PaxListComponent,
    FlightDetailsComponent,
    JourneyDetailsComponent,
    PriceOverviewComponent
  ],
  providers: [
    Configuration,
    { provide: LOCALIZATION_CONFIGURATION_TOKEN, useValue: DEFAULT_LOCALIZATION_CONFIGURATION }
  ],
})
export class SharedModule {
}
