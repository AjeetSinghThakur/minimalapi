import { environment } from '@env/environment';

export interface EnvironmentConfiguration {
  apiUrl: string;
  offerUrl: string;
  userInteractivityTimeOut: number;
  systemPathUrl: string;
  dropdownOptions: number;
  externalUrls: ExternalUrls;
}
export const DEFAULT_ENVIRONMENT_CONFIGURATION: EnvironmentConfiguration = {
  apiUrl: environment.ancillariesUrl,
  offerUrl: environment.offerUrl,
  userInteractivityTimeOut: environment.userInteractivityTimeOut,
  externalUrls: environment.externalUrls,
  dropdownOptions: environment.dropdownOptions,
  systemPathUrl: environment.systemParamUrl
};
export interface ExternalUrls {
  manageBookingUrl: string;
  manageBookingMobileUrl: string;
}
export interface EditableConfiguration {
  configuredVouchers: number;
}
