
import { InjectionToken } from '@angular/core';
import { EnvironmentConfiguration } from './environment';

// Default configuration providers for the application.
export const LOCALIZATION_ENVIRONMENT_TOKEN = new InjectionToken<EnvironmentConfiguration>('Localization environment injection token');
