export function lowerFirst(str?: string) {
  return str && str.length ? str[0].toLowerCase() + str.slice(1) : str;
}

export function upperFirst(str?: string) {
  return str && str.length ? str[0].toUpperCase() + str.slice(1) : str;
}

export function kebabCase(str?: string) {
  // tslint:disable-next-line: no-non-null-assertion
  return str && lowerFirst(str)!.replace(/([A-Z])/g, '-$1').toLowerCase();
}

export function snakeCase(str?: string) {
  // tslint:disable-next-line: no-non-null-assertion
  return str && lowerFirst(str)!.replace(/([A-Z])/g, '_$1').toLowerCase();
}

export function camelCase(str?: string) {
  return str && str.replace(/(?:^\w|[A-Z]|\b\w)/g, (letter, index) =>
    index === 0 ? letter.toLowerCase() : letter.toUpperCase()
  ).replace(/\s+/g, '');
}
