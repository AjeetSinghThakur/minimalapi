import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'duration'})
export class DurationPipe implements PipeTransform {
  transform(value?: number) {
    const val = value || 0;
    const h = Math.floor(val / 3600);
    const m = Math.floor(val % 3600 / 60);

    return String(h) + ':' + padNum(m, 2);
  }
}

function padNum(num: number, digits: number) {
  let strNum = String(num);
  while (strNum.length < digits) {
    strNum = '0' + strNum;
  }
  return strNum;
}
