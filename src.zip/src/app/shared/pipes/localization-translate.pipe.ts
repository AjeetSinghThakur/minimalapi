import {ChangeDetectorRef, Pipe} from '@angular/core';
import {TranslatePipe, TranslateService} from '@ngx-translate/core';

@Pipe({name: 'translate', pure: false})
export class LocalizationTranslatePipe extends TranslatePipe {
  constructor(translate: TranslateService, ref: ChangeDetectorRef) {
    super(translate, ref);
  }

  transform(query: string, ...args: any[]): any {
    const value = super.transform(query, ...args);
    return value;
  }
}
