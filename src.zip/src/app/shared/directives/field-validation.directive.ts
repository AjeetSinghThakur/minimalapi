import { Directive, HostListener, EventEmitter, Output } from '@angular/core';
@Directive({
  selector: '[qa-field-validation]'
})
export class FieldValidationDirective {

  @Output() validateFormFieldEmitter = new EventEmitter<string>();

  @HostListener('blur', [ '$event' ])
  onBlur(event: any) {
    this.validateFormFieldEmitter.emit();
  }

}
