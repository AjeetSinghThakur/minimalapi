import { Injectable } from '@angular/core';
import { QaNotificationService } from './qa.notification.service';
import { MessageCategory, MessageModel } from '@app/models';

@Injectable({
  providedIn: 'root',
  useFactory: qaNotificationFactory,
})

export abstract class AbstractQaNotificationService {
  abstract createNotifications(notifications: any, category: MessageCategory): MessageModel[];
  abstract clearNotification(): void;
}

export function qaNotificationFactory(): AbstractQaNotificationService {
  return new QaNotificationService();
}

