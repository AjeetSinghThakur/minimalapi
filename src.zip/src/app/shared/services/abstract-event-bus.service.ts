import { Injectable } from '@angular/core';
import { EventBusService } from './event-bus.service';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '../configurations';

@Injectable({
  providedIn: 'root',
  useFactory: eventFactory,
  deps: [LOCALIZATION_ENVIRONMENT_TOKEN],
})

export abstract class AbstractEventBusService implements IEventProviderService {
  abstract registerIdleTimeOut(): void;
  abstract scrollToTop(): void;
}
export interface IEventProviderService {
  registerIdleTimeOut(): void;
  scrollToTop(): void;
}

export function eventFactory(environmentConfiguration: EnvironmentConfiguration): AbstractEventBusService {
  return new EventBusService(environmentConfiguration);
}
