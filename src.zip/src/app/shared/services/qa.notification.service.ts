import { Injectable } from '@angular/core';
import { AbstractQaNotificationService } from './abstract-qa.notification.service';
import { MessageModel, MessageCategory, ErrorMessage } from '@app/models';
import { ERROR, INTERNAL_ERROR, SERVICE_ERROR } from '../constants';
import { COMMON_ERROR_KEY, SERVICE_ERROR_KEY, SPECIFIC_ERROR_KEY, SPECIFIC_ERROR } from '../validators';

@Injectable({
  providedIn: 'root',
})
export class QaNotificationService implements AbstractQaNotificationService {
  messages: MessageModel[] = [];
  createNotifications(notifications: any, category: MessageCategory): MessageModel[] {
    this.clearNotification();
    if (notifications instanceof Array) {
      const errorMessages: ErrorMessage[] = [];
      if (notifications && notifications.length > 0 && category === ERROR) {
        notifications.forEach((error: any) => {
          errorMessages.push({
            code: error.errorCategory,
            title: error.errorName,
            detail:
            error.errorName && error.errorCategory && error.errorCategory === SERVICE_ERROR && error.errorName === SPECIFIC_ERROR &&
            error.errorName === SPECIFIC_ERROR  ? SPECIFIC_ERROR_KEY :
            error.errorName && error.errorCategory && error.errorCategory === SERVICE_ERROR ? COMMON_ERROR_KEY :
            error.errorCategory && error.errorCategory === INTERNAL_ERROR ? COMMON_ERROR_KEY :  error
          });
        });
      }
      // Logic to make sure there need to be only one category for notification.
      if (this.messages.length === 0 && errorMessages.length > 0 ) {
        this.messages.push({ category, errors: errorMessages });
      } else if (this.messages.length > 0 && errorMessages.length > 0) {
          const categoryExist = this.messages.find(x => x.category === category);
          if (categoryExist) {
            categoryExist.errors.concat(errorMessages);
          }
        } else if (errorMessages.length > 0) {
          this.messages.push({ category: MessageCategory.Error, errors: errorMessages });
        }
    }
    return this.messages;
  }
  clearNotification(): void {
    this.messages = [];
  }
}
