import { Injectable } from '@angular/core';

const APP_PREFIX = 'OS-';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  private storage: Storage;

  constructor() {
    this.storage = localStorage;
  }

  setItem(key: string, value: any): void {
    this.storage.setItem(`${APP_PREFIX}${key}`, JSON.stringify(value));
  }

  removeItem(key: string): void {
    this.storage.removeItem(`${APP_PREFIX}${key}`);
  }

  getItem(key: string): any {
    return JSON.parse(localStorage.getItem(`${APP_PREFIX}${key}`));
  }
}
