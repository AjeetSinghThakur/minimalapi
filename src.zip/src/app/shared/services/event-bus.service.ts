import { AbstractEventBusService } from './abstract-event-bus.service';
import { fromEvent, merge, timer } from 'rxjs';
import { switchMapTo } from 'rxjs/operators';
import { Inject, Injectable } from '@angular/core';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '../configurations';

export class EventBusService implements AbstractEventBusService {
  constructor(@Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration) {
  }

  clicks$ = fromEvent(document, 'click'); keys$ = fromEvent(document, 'keydown');
  mouse$ = fromEvent(document, 'mousemove'); scroll$ = fromEvent(document, 'scroll');

  scrollToTop() {
    const isIE = /msie\s|trident\//i.test(window.navigator.userAgent);
    if (isIE) {
        window.scrollTo(0, 0);
    } else {
      // This logic is working in all browser need to test it in mobile browsers lately once deployed to SIT/UAT
    const scrollToTop = () => {
        const c = document.documentElement.scrollTop || document.body.scrollTop;
        if (c > 0) {
          window.requestAnimationFrame(scrollToTop);
          window.scrollTo(0, c - c / 8);
        }
      };
    scrollToTop();
    }
  }

  registerIdleTimeOut(): void {
    merge(this.clicks$, this.keys$, this.mouse$, this.scroll$).pipe(
      switchMapTo(timer(this.environmentConfiguration.userInteractivityTimeOut))).subscribe(event => this.idleTimeout());
  }

  idleTimeout() {
  }
}
