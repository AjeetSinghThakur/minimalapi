import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpWrapperService {
  get<T>(url: string, options?: { headers?: HttpHeaders | { [header: string]: string | string[] };
    observe?: 'body';
    params?: HttpParams | { [param: string]: string | string[] };
    reportProgress?: boolean;
    responseType?: 'json';
    withCredentials?: boolean;
    }) {
    return this.http.get<T>(url, options);
  }
  post<T>(url: string, body: any): Observable<T> { return this.http.post<T>(url, body); }

  // This is used when we need to read http response header for some parameters like authorization with final result.
  postWithHttpResponse<T>(url: string, body: any | null, options: {
    headers?: HttpHeaders | { [header: string]: string | string[]; };
    observe: 'response';
    params?: HttpParams | { [param: string]: string | string[]; };
    reportProgress?: boolean;
    responseType?: 'json';
    withCredentials?: boolean;
  }): Observable<HttpResponse<T>> { return this.http.post<T>(url, body, { observe: 'response' }); }

  put<T>(url: string, body: any): Observable<T> { return this.http.put<T>(url, body); }
  delete<T>(url: string): Observable<T> { return this.http.delete<T>(url); }
  patch<T>(url: string, body: string): Observable<T> { return this.http.patch<T>(url, body); }
  constructor(private http: HttpClient) {}
}
