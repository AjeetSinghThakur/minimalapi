import { Component, Input, OnChanges, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Price } from '@app/models';
import { RouterStateUrl } from '@app/store/reducers/router.reducer';

@Component({
  selector: 'qa-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css'],
})
export class BannerComponent implements OnChanges {
  constructor(public router: Router) {}
  @Input() priceConfig: Price;
  @Input() loading: boolean;
  @Input() routerStateUrl: RouterStateUrl;
  @Output() routerStateEmitter = new EventEmitter<string>();

  ngOnChanges(changes: SimpleChanges) {
    if (changes.routerStateUrl) {
      this.routerStateEmitter.emit(changes.routerStateUrl.currentValue);
    }
  }
}

