import { Component } from '@angular/core';
import { AbstractLocalizationService } from '@app/shared/services';

@Component({
  selector: 'qa-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'],
})
export class FooterComponent {
  currentYear: number = new Date().getFullYear();
}


