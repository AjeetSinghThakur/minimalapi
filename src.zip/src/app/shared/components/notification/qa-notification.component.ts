import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { MessageModel } from '@app/models';
import { AbstractEventBusService } from '@app/shared/services';


@Component({
  selector: 'qa-notification',
  templateUrl: './qa-notification.component.html',
  styleUrls: ['./qa-notification.component.css']
})
export class QaNotificationComponent implements OnChanges {

  constructor(private eventBusService: AbstractEventBusService) { }
  @Input() messages: MessageModel[];

  ngOnChanges(changes: any) {
    if (changes.messages.currentValue && changes.messages.currentValue.length > 0) {
      this.eventBusService.scrollToTop();
    }
  }
}
