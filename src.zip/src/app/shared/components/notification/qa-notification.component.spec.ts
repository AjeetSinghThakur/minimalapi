import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QaNotificationComponent } from './qa-notification.component';

describe('QaNotificationComponent', () => {
  let component: QaNotificationComponent;
  let fixture: ComponentFixture<QaNotificationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ QaNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QaNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
