import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { PassengerViewModel } from '@app/models';

@Component({
  selector: 'qa-pax-list',
  templateUrl: './pax-list.component.html',
  styleUrls: ['./pax-list.component.css'],
})
export class PaxListComponent implements OnInit {
  @Input() paxlist: PassengerViewModel[];
  @Output() passengerEmitter = new EventEmitter<PassengerViewModel>();
  selectedPaxId: string;

  constructor() {}

  ngOnInit() {
    if (this.paxlist) { this.selectPassenger(this.paxlist[0]); }
  }

  selectPassenger(pax: PassengerViewModel) {
    this.selectedPaxId = pax.productIdentifier;
    this.passengerEmitter.emit(pax);
  }
}

