import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'qa-price-overview',
  templateUrl: './price-overview.component.html',
  styleUrls: ['./price-overview.component.css'],
})
export class PriceOverviewComponent {
  constructor(public router: Router) {}
  // @Input() priceConfig: Price;
  // @Input() loading: boolean;
}

