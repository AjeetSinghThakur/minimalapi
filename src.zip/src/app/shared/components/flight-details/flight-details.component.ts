import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FlightViewModel } from '@app/models';
@Component({
  selector: 'qa-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.css'],
})
export class FlightDetailsComponent {
  @Input() flight: FlightViewModel;
  @Input() selectedFlight: FlightViewModel;
  @Output() currentFlightEmitter = new EventEmitter<string>();
  showSeatPlan(uniqueIdentifier: string) {
    this.flight.isAccordianOn = this.selectedFlight.uniqueIdentifier === uniqueIdentifier ?
    !this.flight.isAccordianOn :  true;
    if (this.flight.isAccordianOn) {
      this.currentFlightEmitter.emit(uniqueIdentifier);
    }
  }
}

