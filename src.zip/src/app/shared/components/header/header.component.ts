import { Component } from '@angular/core';
import { AbstractLocalizationService } from '@app/shared/services';
import { Router } from '@angular/router';

@Component({
  selector: 'qa-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  constructor(private router: Router) {
  }
  redirectToCheckout() {
    this.router.navigate(['/checkout']);
  }
}


