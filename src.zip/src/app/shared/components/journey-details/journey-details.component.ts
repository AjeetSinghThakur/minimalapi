import { Component, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { JourneyViewModel } from '@app/models';

@Component({
  selector: 'qa-journey-detail',
  templateUrl: './journey-details.component.html',
  styleUrls: ['./journey-details.component.css'],
})
export class JourneyDetailsComponent implements OnChanges {
  @Input() journey: JourneyViewModel;
  @Output() currentFlightEmitter = new EventEmitter<string>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.journey && changes.journey.currentValue) {
      this.currentFlightEmitter.emit(this.journey.flights[0].uniqueIdentifier);
    }
  }
}

