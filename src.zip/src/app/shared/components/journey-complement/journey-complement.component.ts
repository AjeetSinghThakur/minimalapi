import { Component, Output, EventEmitter, Input } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'qa-journey-complement',
  templateUrl: './journey-complement.component.html',
  styleUrls: ['./journey-complement.component.css']
})
export class JourneyComplementComponent {
  @Input() deepUrl: string;
  @Output() navigationEmitter = new EventEmitter<string>();

  constructor(config: NgbCarouselConfig) {
    // customize default values of carousels used by this component tree
    config.interval = 10000;
    config.wrap = false;
    config.keyboard = true;
    config.pauseOnHover = false;
    config.showNavigationIndicators = false;
    config.showNavigationArrows = true;
  }
  navigate(deepUrl: string) {
    this.navigationEmitter.emit(deepUrl);
  }
}


