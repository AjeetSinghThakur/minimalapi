import { Component } from '@angular/core';
@Component({
  selector: 'qa-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent {

}


