import { Component, OnInit, Input, Inject, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GlxProdVouchersResponse } from '@app/models';
import { LOCALIZATION_ENVIRONMENT_TOKEN, EnvironmentConfiguration } from '@app/shared/configurations';
import { UtilityService } from '@app/core/services';

@Component({
  selector: 'qa-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  constructor(private modalService: NgbModal,
              private utilityService: UtilityService,
              @Inject(LOCALIZATION_ENVIRONMENT_TOKEN) private environmentConfiguration: EnvironmentConfiguration) { }
  @Input() public glxProdVouchers: GlxProdVouchersResponse[];
  @Input() public isSession: boolean;
  @Input() public redirectionRequired: boolean;
  @Output() parentEntry: EventEmitter<any> = new EventEmitter();

  ngOnInit() {
  }
  dismissAll() {
    this.parentEntry.emit(false);
    this.modalService.dismissAll();
    if (this.isSession) {
      location.href = this.utilityService.isMobileTablet() ? this.environmentConfiguration.externalUrls.manageBookingMobileUrl :
       this.environmentConfiguration.externalUrls.manageBookingUrl;
    }
  }
  redirectTo() {
    this.modalService.dismissAll();
    this.parentEntry.emit(true);
  }
}
