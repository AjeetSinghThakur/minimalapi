import { FormGroup } from '@angular/forms';
import { CountryDetail } from '@app/models';
import { element } from 'protractor';

export class CustomValidator {
    // To check both email and repeat email is same
  static emailCheck(emailCtrl: string, repeatEmailCtrl: string) {
    return (group: FormGroup) => {
      const email = group.controls[emailCtrl];
      const repeatEmail = group.controls[repeatEmailCtrl];
      if (!email.value) {
        return repeatEmail.setErrors({ required: true });
      } else if (email.value !== repeatEmail.value) {
        return repeatEmail.setErrors({ notEquivalent: true });
      } else {
        return repeatEmail.setErrors(null);
      }
    };
  }
  static autoPopulateValueCheck(ctrl: string) {
    return (group: FormGroup) => {
      const formControl = group.get(ctrl);
      if (formControl && typeof formControl.value === 'string') {
          group.controls.countryCode.setErrors({ nomatch: true });
      } else {
        group.controls.countryCode.setErrors(null);
      }
    };
  }
}

