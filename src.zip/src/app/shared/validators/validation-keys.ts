export const SUPERWIFI_VALIDATION_KEY = 'superwifi.qa-validation-messages';
export const COMMON_ERROR_KEY = 'common-errors.qa-internal-error';
export const SPECIFIC_ERROR_KEY = 'common-errors.qa-specific-error';
export const SERVICE_ERROR_KEY = 'service-errors';
export const SPECIFIC_ERROR = 'ANC_0202008';
