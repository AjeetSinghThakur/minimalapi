import { FormGroup } from '@angular/forms';
import { INVALID } from '../constants';

export class GenericValidator {
  static processMessages(validationKey: string, container: FormGroup, isPartialValidation: boolean = false)  {
    const messages = [];
    for (const controlKey in container.controls) {
      if (container.controls.hasOwnProperty(controlKey)) {
        if (container.status === INVALID) {
            if (container.controls[controlKey].status === INVALID) {
              if (container.controls[controlKey].errors) {
                for (const error in container.controls[controlKey].errors) {
                  if (container.controls[controlKey].errors.hasOwnProperty(error)) {
                    if (isPartialValidation) {
                      if (container.value[controlKey]) {
                        messages.push(validationKey + '.'.concat(controlKey).concat('.').concat(error));
                        container.controls[controlKey].markAsTouched();
                      }
                    } else {
                      messages.push(validationKey + '.'.concat(controlKey).concat('.').concat(error));
                      container.controls[controlKey].markAsTouched();
                    }
                  }
                }
              }
            }
          }
      }
    }
    return messages;
  }
}
