export const SHORT_ANDROID = 'a';
export const ANDROID = 'android';
export const SHORT_IPHONE = 'i';
export const IPHONE = 'iphone';
export const IPHONE_OPERATING_SYSTEM = 'ios';
export const MOBILE_WEBSITE = 'mobile website';
export const DESKTOP_WEBSITE = 'desktop website';
export const SCODE = 'scode';
export const ONEWAY_CODE = 'ONE_WAY';
export const ONEWAY_VALUE = 'oneway';
export const RETURN_CODE = 'RETURN_TRIP';
export const RETURN_VALUE = 'return';
export const MULTICITY_CODE = 'MULTICITY';
export const MULTICITY_VALUE = 'multicity';
export const SUPER_WIFI_LANDING_PAGE = 'wifi selection page';
export const SUPER_WIFI_CONFIRMATION_PAGE = 'wifi purchase confirmation page';
export const WIFI = 'Super Wi-Fi';
export const WIFI_IMAGE = 'wifi';
export const WIFI_ROUTER = 'superwifi';
export const UPGRADE = 'Upgrade';
export const WIFI_CHANNEL = 'purchase-wifi';
export const TOUCH_POINT = 'check-in';
export const PAGE_CATEGORY = 'purchase-wifi';
export const GLOBAL = 'global';
export const LOWER = 'LOWER';
export const UPPER = 'UPPER';
export const OCCUPIED = 'OCCUPIED';
export const AISLE = 'AISLE';
export const CENTER_SEAT = 'CENTER_SEAT';
export const WINDOW = 'WINDOW';
export const WINDOW_AISLE = 'WINDOW_AISLE';
export const BULKHEAD = 'BULKHEAD';
export const EXIT_ROW_SEAT = 'EXIT_ROW_SEAT';
export const HANDICAPPED = 'HANDICAPPED';
export const QUODE_SEAT = 'QUODE_SEAT';
export const REAR_FACING = 'REAR_FACING';
export const NON_INFANT = 'NON_INFANT';
export const NON_MEDICAL = 'NON_MEDICAL';
export const NON_UAMR = 'NON_UAMR';
export const RESTRICTED_RECLAIN = 'RESTRICTED_RECLAIN';
export const DEPORTEE = 'DEPORTEE';
export const RESTRICTED = 'RESTRICTED';
export const SELECT_SEAT = 'SELECT_SEAT';
export const REMOVE_SEAT = 'REMOVE_SEAT';
export const CHARGEABLE_AVAILABLE = 'CHARGEABLE_AVAILABLE';
export const AVAILABLE = 'AVAILABLE';
export const COMFORT_SEAT = 'comfort_seat';
export const EXTRA_SEAT = 'extra_seat';
export const WEELCHAIR = 'weelchair';
export const NEXT = 'next';
export const PREVIOUS = 'prev';









