
export const CONFIRMATION_PAGE = '/confirmation';
