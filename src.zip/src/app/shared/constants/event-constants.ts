export const  BLUR = 'blur';
