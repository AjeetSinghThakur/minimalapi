export const INVALID = 'INVALID';
export const VALID = 'VALID';
export const EMAIL = 'email';
export const REPEAT_EMAIL = 'repeatEmail';
export const COUNTRY_CODE = 'countryCode';
export const EMPTY_STRING = '';
export const ERROR = 'error';
export const WARNING = 'warning';
export const SUCCESS = 'success';
export const INFO = 'info';
export const RETURN_TRIP = 'RETURN_TRIP';
export const ONEWAY = 'ONEWAY';
export const MULTICITY = 'MULTICITY';
export const INBOUND = 'INBOUND';
export const OUTBOUND = 'OUTBOUND';
export const WIFI_AVAILABLE = 'AL';
export const WIFI_NOINFO = 'NA';
export const DEPART = 'DEPART';
export const ARRIVAL = 'ARRIVAL';
export const SUPERWIFI = 'WIFI';
export const MOBILE = 'MOBILE';
export const BOOKING_REFERENCE = 'BOOKINGREFERENCENUMBER';
export const INTERNAL_ERROR = 'INTERNAL_ERROR';
export const SERVICE_ERROR = 'SERVICE_ERROR';
export const TRNX_CANCEL_CODE = 'GOO7';
export const TRNX_ERROR_TYPE = 'G';



