import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { seatsRoutes } from './seats.routing';
import { SharedModule } from '@app/shared/shared.module';
import { ContentComponent } from '@app/seats/container';
import { SeatPlanComponent, SeatPreviewComponent } from './presentational';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { featureSeatStateName, seatsReducer, SeatsEffects } from './store';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(seatsRoutes),
    StoreModule.forFeature(featureSeatStateName, seatsReducer),
    EffectsModule.forFeature([SeatsEffects]),
    SharedModule,
    NgbModule,
  ],
  exports: [],
  declarations: [
    ContentComponent,
    SeatPlanComponent,
    SeatPreviewComponent
  ],
  providers: [],
})
export class SeatsModule {}
