import { Component, Input, Output, EventEmitter, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { NgbPopover, NgbPopoverConfig, NgbCarousel } from '@ng-bootstrap/ng-bootstrap';
import { FlightGroup, Deck, RBDCodes, ColumnGroupData, PassengerViewModel, RowGroupData, FlightViewModel } from '@app/models';
import {
  OCCUPIED,
  CHARGEABLE_AVAILABLE,
  AVAILABLE,
  COMFORT_SEAT,
  EXTRA_SEAT,
  SELECT_SEAT,
  REMOVE_SEAT,
  HANDICAPPED,
  WEELCHAIR
} from '@app/shared/constants';

@Component({
  selector: 'qa-seat-plan',
  templateUrl: './seat-plan.component.html',
  styleUrls: ['./seat-plan.component.css'],
})
export class SeatPlanComponent implements OnChanges {
  @ViewChild('seatCarousel') seatCarousel: NgbCarousel;
  @Input() selectedPaxRow: string;
  @Input()  selectedPassenger: PassengerViewModel;
  @Input()  seatGroups: Array<{deckLocation: string, rowHeaderIdentifier: string, data: FlightGroup }>;
  @Input()  decks: Deck[];
  @Input()  currentDeck: string;
  @Input()  currentSeatGroup: string;
  @Input()  rbdCodes: RBDCodes[];
  @Input() paxlist: PassengerViewModel[];
  @Input() flightIds: string;
  @Input() currentFlight: FlightViewModel;
  @Output() setNextFlightId = new EventEmitter<string>();
  @Output() deckEmitter = new EventEmitter<string>();
  @Output() seatGroupEmitter = new EventEmitter<string>();
  currentGroupIndex: number;

  currSelectedSeat: ColumnGroupData;
  selectedPopover: NgbPopover;
  showAllLegends = false;
  showLegendsModal = false;
  hasNextFlight = true;

  constructor(config: NgbPopoverConfig) {
    config.autoClose = 'outside';
    config.container = 'body';
    config.triggers = 'manual';
  }

  ngOnChanges(changes: SimpleChanges) {
    if ((changes.seatGroups && changes.seatGroups.currentValue)) {
      this.selectSeatOnLoad(changes.seatGroups.currentValue);
    }
    if (this.seatGroups && (changes.currentSeatGroup || changes.selectedPassenger)) {
      this.selectSeatOnLoad(this.seatGroups);
    }
    if (changes.currentFlight) {
      const ind: number = this.flightIds.indexOf(this.currentFlight.uniqueIdentifier);
      this.hasNextFlight = ((ind + 1) >= 0 && (ind + 1) < this.flightIds.length) ? true : false;
    }
  }
  selectSeatOnLoad(seatGroups: Array<{deckLocation: string, rowHeaderIdentifier: string, data: FlightGroup }>) {
    if (this.paxlist && this.selectedPassenger) {
      if (this.selectedPassenger && this.selectedPassenger.seatNo) {
        let seatGroup = seatGroups.find(group => this.selectedPassenger.row >= group.rowHeaderIdentifier.split('-')[0] &&
        this.selectedPassenger.row <= group.rowHeaderIdentifier.split('-')[1]);
        if (this.currentSeatGroup) {
          seatGroup = seatGroups.find(group => group.rowHeaderIdentifier === this.currentSeatGroup);
        }
        seatGroup ? this.seatGroupEmitter.emit(seatGroup.rowHeaderIdentifier) :
        this.seatGroupEmitter.emit(this.seatGroups[0].rowHeaderIdentifier);
        this.currentGroupIndex = seatGroup ? this.seatGroups.indexOf(seatGroup)  : 0;
        if (this.seatCarousel) {
          this.seatCarousel.activeId = seatGroup ?
          seatGroup.rowHeaderIdentifier  : this.seatGroups[0].rowHeaderIdentifier;
        }
        const rowGroupList: RowGroupData[] = this.seatGroups.reduce((tr, cabin) => [ ...tr, ...cabin.data.rowGroupList], []);
        const columnGroupList: ColumnGroupData[] = rowGroupList.reduce((tr, row) => [ ...tr, ...row.columnGroupList], []);
        this.paxlist.forEach(pax => {
        const seatData = pax.seatNo ? columnGroupList.find(x => x.columnFullName === pax.seatNo) : null;
        if (seatData && pax.productIdentifier === this.selectedPassenger.productIdentifier) {
          seatData.isSelectedPaxSeat = true;
          seatData.isCoPassengerSeat  = false;
          seatData.display = OCCUPIED;
        } else if (seatData) {
          seatData.isCoPassengerSeat  = true;
          seatData.isSelectedPaxSeat = false;
          seatData.display = OCCUPIED;
        }
      });
      }
    }
  }

  populateDeck(deckLocation: string) {
    this.deckEmitter.emit(deckLocation);
  }

  openSeatInfo(popover: NgbPopover, seat: ColumnGroupData) {
    if (seat && seat.extendedSeatDetail === HANDICAPPED) {
        popover.popoverClass = WEELCHAIR;
    }
    if (popover.isOpen()) {
      popover.close();
    } else {
      if (seat.isCoPassengerSeat || seat.isSelectedPaxSeat || seat.display !== OCCUPIED) {
        this.currSelectedSeat = seat;
        this.currSelectedSeat.buttonText =  seat.display === OCCUPIED ? REMOVE_SEAT : SELECT_SEAT;
        if (!this.currSelectedSeat.assigneeName) {
          const passenger = this.paxlist.find(x => x.seatNo === this.currSelectedSeat.columnFullName);
          if (passenger) { this.currSelectedSeat.assigneeName = passenger.firstName + ' ' + passenger.lastName; }
        }
        this.selectedPopover = popover;
        popover.open();
      }
    }
  }

  goToNextRange(seatGroup: string) {
    if (seatGroup === 'next') {
      this.seatCarousel.next();
      this.currentGroupIndex++;
    } else if (seatGroup === 'prev') {
      this.seatCarousel.prev();
      this.currentGroupIndex--;
    }
    this.seatGroupEmitter.emit(this.seatGroups[this.currentGroupIndex].rowHeaderIdentifier);
  }

  selectSeat(selected: boolean = false) {
    if (selected) {
      const seatGroup = this.seatGroups[this.currentGroupIndex];
      if (seatGroup) {
        const flightGroup: FlightGroup = seatGroup.data;
        const columnGroupList: ColumnGroupData[] =
        flightGroup.rowGroupList.reduce((tr, row) => [ ...tr, ...row.columnGroupList], []);
        if (this.currSelectedSeat.display === OCCUPIED && this.currSelectedSeat.buttonText === REMOVE_SEAT) {
          const passenger = this.paxlist.find(x => x.seatNo === this.currSelectedSeat.columnFullName);
          const seatData: ColumnGroupData = columnGroupList.find(x => x.columnFullName === this.currSelectedSeat.columnFullName);
          seatData.isSelectedPaxSeat = false;
          seatData.display = seatData.uiDisplay === COMFORT_SEAT || seatData.uiDisplay === EXTRA_SEAT ? CHARGEABLE_AVAILABLE : AVAILABLE;
          passenger.seatNo = null;
          passenger.amount = null;
        }
        if (this.currSelectedSeat.display !== OCCUPIED && this.currSelectedSeat.buttonText === SELECT_SEAT) {
          const passenger = this.paxlist.find(x => x.productIdentifier === this.selectedPassenger.productIdentifier);
          const oldSeatGroup = this.seatGroups.find(group => passenger.row >= group.rowHeaderIdentifier.split('-')[0] &&
          passenger.row <= group.rowHeaderIdentifier.split('-')[1]);
          const oldSeatRow = oldSeatGroup.data.rowGroupList.find(x => x.rowNumber === passenger.row);
          const oldSeatData = oldSeatRow.columnGroupList.find(x => x.columnFullName === passenger.seatNo);
          if (oldSeatData) {
            oldSeatData.isSelectedPaxSeat = false;
            oldSeatData.display = oldSeatData.uiDisplay === COMFORT_SEAT ||
            oldSeatData.uiDisplay === EXTRA_SEAT ? CHARGEABLE_AVAILABLE : AVAILABLE;
            passenger.seatNo = null;
            passenger.amount = null;
          }
          let columnData: ColumnGroupData = columnGroupList.find(x => x.columnFullName === this.currSelectedSeat.columnFullName);
          if (!columnData) {
            const rowGroupList: RowGroupData[] =
            this.seatGroups.reduce((tr, group) => [ ...tr, ...group.data.rowGroupList], []);
            columnData = rowGroupList.reduce((tr, rowGroup) =>
            [ ...tr, ...rowGroup.columnGroupList], []).find(x =>
              x.columnFullName === this.currSelectedSeat.columnFullName);
          }
          columnData.display = OCCUPIED;
          columnData.isSelectedPaxSeat = true;
          columnData.assigneeName = passenger ? (passenger.firstName + ' ' + passenger.lastName) : null;
          passenger.amount = this.currSelectedSeat.amount;
          passenger.currency = this.currSelectedSeat.currency;
          passenger.seatNo = this.currSelectedSeat.columnFullName;
          passenger.deckLocation = seatGroup.deckLocation;
          passenger.row = passenger.seatNo ? passenger.seatNo.substring(0, passenger.seatNo.length - 1) : '';
        }
      }
    }
    this.selectedPopover.close();
  }

  showNextFlight() {
    const currentFlightIndex = this.flightIds.indexOf(this.currentFlight.uniqueIdentifier);
    this.hasNextFlight ? this.setNextFlightId.emit(this.flightIds[currentFlightIndex + 1]) :
    this.setNextFlightId.emit(this.flightIds[currentFlightIndex - 1]);
  }
}
