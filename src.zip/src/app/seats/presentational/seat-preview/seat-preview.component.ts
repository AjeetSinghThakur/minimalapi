import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FlightGroup, PassengerViewModel } from '@app/models';
@Component({
  selector: 'qa-seat-preview',
  templateUrl: './seat-preview.component.html',
  styleUrls: ['./seat-preview.component.css'],
})
export class SeatPreviewComponent implements OnChanges {
  @Input()  selectedPaxRow: string;
  @Input()  seatGroups: Array<{deckLocation: string, rowHeaderIdentifier: string, data: FlightGroup }>;
  @Input()  currentDeck: string;
  @Input() paxlist: PassengerViewModel[];
  @Input()  currentSeatGroup: string;
  @Output() seatGroupEmitter = new EventEmitter<string>();

  ngOnChanges(changes: SimpleChanges) {
  }

  goToRange(range: string) {
    this.seatGroupEmitter.emit(range);
  }
}

