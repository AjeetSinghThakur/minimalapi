import { createFeatureSelector, createSelector, ActionReducerMap, select } from '@ngrx/store';
import {
  SeatReducerState,
  seatReducer,
  getSeatMapLoading,
  getDeck,
  getPassengerId,
  getFlightId,
  getSeatmapResponse
} from './seats.reducer';
import { CoreState, getTrip } from '@app/store/reducers';
import {
  JourneyViewModel,
  FlightViewModel,
  PassengerViewModel,
  FlightGroup,
  Deck,
  Row,
  RowGroupData,
  ColumnGroupData,
  RBDCodes,
  Trip,
  SeatMap,
} from '@app/models';
import {
  LOWER,
  UPPER,
  AISLE,
  CENTER_SEAT,
  WINDOW,
  WINDOW_AISLE,
  BULKHEAD,
  EXIT_ROW_SEAT,
  HANDICAPPED,
  QUODE_SEAT,
  REAR_FACING,
  NON_UAMR,
  NON_INFANT,
  NON_MEDICAL,
  RESTRICTED_RECLAIN,
  DEPORTEE,
  RESTRICTED
} from '@app/shared/constants';

export interface AppState extends CoreState { seats: SeatReducerState; }
export interface SeatState { seats: SeatReducerState; }
export const featureSeatStateName = 'seatFeature';
export const seatsReducer: ActionReducerMap<SeatState> = { seats: seatReducer };
export const getFeatureSelector = createFeatureSelector<SeatState>(featureSeatStateName);
export const getSeatState = createSelector(getFeatureSelector, (state: SeatState) => state.seats );
export const getSeatMapResponse = createSelector(getSeatState, getSeatmapResponse );
export const getLoading = createSelector(getSeatState, getSeatMapLoading );
export const getCurrentFlightId = createSelector(getSeatState, getFlightId );
export const getCurrentPassengerId = createSelector(getSeatState, getPassengerId );
export const getCurrentDeck = createSelector(getSeatState, getDeck );

export const getJourneysView = createSelector(getTrip, (trip: Trip) => {
  const journeyList: JourneyViewModel[] = [];
  if (trip && trip.journeys) {
    trip.journeys.forEach(journey => {
      const journeyViewModel: JourneyViewModel = {
        journeyId: journey.journeyId,
        arrivalAirportCode: journey.arrivalCity,
        departureAirportCode: journey.departureCity,
        arrivalStation: journey.arrivalStationCode,
        departureStation: journey.departureStationCode,
        departureDate: journey.departureDate,
        arrivalDate: journey.arrivalDate,
      };
      if (journey.flightList && trip.passengerFlightMapping && trip.passengers) {
        journeyViewModel.flights = [];
        journey.flightList.forEach(flight => {
          const flightViewModel: FlightViewModel = {
            uniqueIdentifier: flight.flightIdentifier.uniqueIdentifier,
            operatingCarrier: flight.carrier.operatingCarrier,
            flightNumber: flight.flightNumber,
            departureStation: flight.departureStation.airportCode,
            arrivalStation: flight.arrivalStation.airportCode,
            departureCity: flight.departureStation.city,
            arrivalCity: flight.arrivalStation.city,
            flightType: flight.flightStatus,
            aircraft: flight.equipmentDetails,
            isAccordianOn: true,
          };
          const passengerMappingList = trip.passengerFlightMapping.filter(x =>
            x.paxFlightIdentifier.flightIdentifier.uniqueIdentifier === flight.flightIdentifier.uniqueIdentifier);

          if (passengerMappingList) {
            flightViewModel.passengers = [];
            trip.passengers.forEach(passenger => {
              const passengerMapping = passengerMappingList.find(x =>
                x.paxFlightIdentifier.passengerIdentifier.productIdentifier === passenger.passengerIdentifier.productIdentifier);
              if (passengerMapping) {
                flightViewModel.passengers.push({
                  uniqueIdentifier: passenger.passengerIdentifier.uniqueIdentifier,
                  productIdentifier: passenger.passengerIdentifier.productIdentifier,
                  row: passengerMapping.seatPreference && passengerMapping.seatPreference.assignedSeat
                  ? passengerMapping.seatPreference.assignedSeat.substring(0, passengerMapping.seatPreference.assignedSeat.length - 1) : '',
                  seatNo: passengerMapping.seatPreference ? passengerMapping.seatPreference.assignedSeat : null,
                  firstName: passenger.firstName,
                  lastName: passenger.lastName,
                  title: passenger.title,
                  gender: passenger.gender,
                  paxType: passenger.passengerType,
                });
              }
            });
          }
          journeyViewModel.flights.push(flightViewModel);
        });
      }
      journeyList.push(journeyViewModel);
    });
  }
  return journeyList;
});
export const getSelectedFlight = createSelector(getJourneysView, getCurrentFlightId,
  ((journeys: JourneyViewModel[], currentFlightId: string) => {
  if (journeys && currentFlightId) {
    return currentFlightId ? journeys.reduce((tr, journey) =>
    [ ...tr, ...journey.flights], []).find(x => x.uniqueIdentifier === currentFlightId) as FlightViewModel : null;
  }
}));
export const getAllFlightIds = createSelector(getJourneysView, ((journeys: JourneyViewModel[]) => {
  if (journeys) {
    const flights: FlightViewModel[] = journeys.reduce((tr, journey) => [ ...tr, ...journey.flights], []);
    return flights.map(x => x.uniqueIdentifier);
  }
}));
export const getCurrentPassenger = createSelector(getSelectedFlight, getCurrentPassengerId,
  (flight: FlightViewModel, productIdentifier: string) => {
    if (flight && productIdentifier) {
      return flight.passengers.find(x => x.productIdentifier === productIdentifier);
    }
});
export const getSeatMap = createSelector(getSeatMapResponse, getCurrentDeck,
   (seatMap: SeatMap, deckLocation: string) => {
    if (seatMap && seatMap.decks) {
    const seatMapGroups: Array<{deckLocation: string, rowHeaderIdentifier: string, data: FlightGroup}> = [];
    const deckConfig: Deck = seatMap.decks.find(x => x.deckLocation === deckLocation);
    if (deckConfig) {
      return buildRowGroupConfigData(deckConfig, seatMapGroups);
    }
  }
});
export const getDeckInfo = createSelector(getSeatMapResponse, (seatMap: SeatMap) => {
  if (seatMap) {
    return seatMap.decks;
  }
});

export const getSelectedPassengerRow = createSelector(getCurrentPassenger,
  (selectedPassenger: PassengerViewModel) => {
    if (selectedPassenger) {
      return selectedPassenger.seatNo ?
      selectedPassenger.seatNo.substring(0, selectedPassenger.seatNo.length - 1) : selectedPassenger.seatNo;
    }
});
export const getRBDCodes = createSelector(getDeckInfo, getCurrentDeck,
  (decks: Deck[], deckLocation: string) => {
  if (decks && deckLocation) {
    const deckConfig: Deck = decks.find(x => x.deckLocation === deckLocation);
    const rbdCodes: RBDCodes[] = [];
    if (deckConfig) {
      deckConfig.deckCompartment.forEach(cabin => {
      if (cabin.aisleColumns && cabin.columnsList) {
        cabin.columnsList.forEach(column => {
          const rbdCode = rbdCodes.find(x => x.alphabet === column);
          if (!rbdCode) {
            rbdCodes.push({
              alphabet: column,
              isAisle: cabin.aisleColumns.find(x => x === column) ? true : false
            });
          }
        });
      }
      });
    }
    return rbdCodes;
  }
});
export function buildRowGroupConfigData(
  decksConfig: Deck,
  seatMapGroups: Array<{deckLocation: string, rowHeaderIdentifier: string, data: FlightGroup}>) {
  if (decksConfig.deckCompartment) {
    const rows: Row[] = decksConfig.deckCompartment.reduce((tr, cabin) => [ ...tr, ...cabin.rows], []);
    const rowDecimal = Number((rows.length / 8).toFixed(1).split('.')[1]);
    const rowBlocks = rowDecimal > 0 && rowDecimal < 5 ? Math.round(rows.length / 8) + 1 : Math.round(rows.length / 8);
    let startPoint = 0; let endPoint = 8;
    for (let index = 0; index < rowBlocks; index++) {
      startPoint = index === 0 ? startPoint : startPoint + 8;
      endPoint = index === 0 ? endPoint : endPoint > rows.length ? endPoint + endPoint - rows.length : endPoint + 8;
      const startRow = rows[startPoint].rowNumber;
      const endRow =  endPoint < rows.length ? rows[endPoint - 1].rowNumber : rows[rows.length - 1].rowNumber;
      const groupHeader = startRow + '-' + endRow;

      const cabin = decksConfig.deckCompartment.find(x => x.rows.find(y => y.rowNumber === startRow));
      const aisleColumns: string[] = cabin.aisleColumns;
      seatMapGroups.push({
        deckLocation: decksConfig.deckLocation,
        rowHeaderIdentifier: groupHeader,
        data: prepareRowBreakUp(rows.slice(startPoint, endPoint), groupHeader, aisleColumns)
      });
    }
  }
  return seatMapGroups;
}
export function prepareRowBreakUp(
  rows: Row[],
  groupHeader: string,
  aisleColumns: string[]): FlightGroup {
    const rowGroupList: RowGroupData[] = [];
    let columnDataList: ColumnGroupData[];
    if (rows.length) {
      const exitRows = rows.filter(row => row.rowCharacteristics.findIndex(x => x === 'EXIT') >= 0 );
      exitRows.forEach(x => {
        if (rows.indexOf(x) > 0 ) {
          rows.splice(rows.indexOf(x), 0, { rowNumber: '-1', columns: [], rowCharacteristics: ['exitRow'] });
        }
      });
      rows.forEach(row => {
        columnDataList = [];
        const rowGroupData: RowGroupData = { rowHeaderGroup: groupHeader, rowNumber: row.rowNumber, columnGroupList: [] };
        row.columns.forEach(column => {
          const chargableOption: string = column.higherCharge && column.amount !== null ? 'comfort_seat' :
            !column.higherCharge && column.amount !== null ? 'extra_seat' : '';

          const aisleColumn = aisleColumns.find(x => x === column.column);
          const seatPlacement = column.seatCharacteristic.find(x => x === AISLE ||
            x === CENTER_SEAT || x === WINDOW || x === WINDOW_AISLE);
          const extendedSeatDetail = column.seatCharacteristic.find(x => x === BULKHEAD ||
            x === EXIT_ROW_SEAT || x === HANDICAPPED || x === QUODE_SEAT || x === REAR_FACING);

          const seatCharacteristics = column.seatCharacteristic &&
          column.seatCharacteristic.length > 0  ? column.seatCharacteristic
          .filter(x => x !== NON_UAMR)
          .filter(x => x !== NON_INFANT)
          .filter(x => x !== NON_MEDICAL)
          .filter(x => x !== DEPORTEE)
          .filter(x => x !== RESTRICTED)
          .filter(x => x !== RESTRICTED_RECLAIN) : column.seatCharacteristic;
          columnDataList.push({
            columnFullName: column.number + column.column,
            columnNumber: column.number,
            columnName: column.column,
            display: column.display,
            uiDisplay: chargableOption ? chargableOption : '',
            isAisleSeat: aisleColumn ? true : false,
            amount: column.amount,
            currency: column.currency,
            seatPlacement,
            extendedSeatDetail,
            seatChar: seatCharacteristics
          });
        });
        rowGroupData.columnGroupList = columnDataList;
        rowGroupList.push(rowGroupData);
      });
    }
    return { rowGroupList };
}
