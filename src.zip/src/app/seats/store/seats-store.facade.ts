import { Injectable } from '@angular/core';
import { select, Store, Action } from '@ngrx/store';
import { CoreState, getCountries, getErrors } from '@app/store/reducers';
import {
  getJourneysView,
  getLoading,
  getSeatMap,
  getDeckInfo,
  getCurrentDeck,
  getRBDCodes,
  getSelectedFlight,
  getSelectedPassengerRow,
  getCurrentPassenger,
  getAllFlightIds
} from './seats.selectors';
@Injectable({
  providedIn: 'root'
})
export class SeatsStoreFacade {
  journeys$ = this.store.pipe(select(getJourneysView));
  countries$ = this.store.pipe(select(getCountries));
  errorMessage$ = this.store.select(getErrors);
  loading$ = this.store.pipe(select(getLoading));
  seatGroups$ = this.store.pipe(select(getSeatMap));
  decks$ = this.store.pipe(select(getDeckInfo));
  currentDeck$ = this.store.pipe(select(getCurrentDeck));
  rbdCodes$ = this.store.pipe(select(getRBDCodes));
  currentFlight$ = this.store.pipe(select(getSelectedFlight));
  selectedPaxRow$ = this.store.pipe(select(getSelectedPassengerRow));
  selectedPassenger$ = this.store.pipe(select(getCurrentPassenger));
  flightIds$ = this.store.pipe(select(getAllFlightIds));

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
  constructor(private store: Store<CoreState>) {}
}
