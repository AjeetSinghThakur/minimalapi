import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as seatsActions from './seats.actions';
import { catchError, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { AncillariesService } from '@app/core/services';
import { MessageCategory, SeatMapResponse } from '@app/models';
import { buildValidationErrors } from '@app/store/actions/ancillaries.actions';
import { AbstractQaNotificationService } from '@app/shared/services';

@Injectable()
export class SeatsEffects {
  constructor(private actions$: Actions,
              private ancillariesService: AncillariesService,
              private qaNotificationService: AbstractQaNotificationService) {}

  loadSeatMap$ = createEffect(() =>
    this.actions$.pipe(
      ofType(seatsActions.loadSeatMap),
      switchMap(() => this.ancillariesService.loadSeatMap()),
      switchMap((response: SeatMapResponse) => response && response.errorObject ?
      [
        buildValidationErrors({ payload: this.qaNotificationService.createNotifications(response.errorObject, MessageCategory.Error)})
      ] :
      [
        seatsActions.loadSeatMapSuccess({ payload: response.seatMap }),
      ]),
      catchError(err => of(seatsActions.loadSeatMapFail({ payload: err })))
    )
  );
}
