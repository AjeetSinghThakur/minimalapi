import * as seatsActions from './seats.actions';
import { createReducer, on, Action } from '@ngrx/store';
import { MessageModel, SeatMap } from '@app/models';

export interface SeatReducerState {
  seatMap: SeatMap;
  currentFlightId: string | null;
  currentPassengerId: string | null;
  currentDeck: string | null;
  error: MessageModel[];
  loading: boolean;
}

export const initialState: SeatReducerState = {
  seatMap: null,
  currentFlightId: null,
  currentPassengerId: null,
  currentDeck: null,
  error: [],
  loading: false,
};

const seatsReducerInternal = createReducer(
  initialState,
  on(seatsActions.loadSeatMap, state => ({
    ...state,
    loading: true
  })),
  on(seatsActions.loadSeatMapSuccess, (state, { payload }) => ({
    ...state,
    seatMap: payload,
    error: [],
    loading: false
  })),
  on(seatsActions.loadSeatMapFail, (state, { payload }) => ({
    ...state,
    error: payload,
    loading: false
  })),
  on(seatsActions.currentFlightId, (state, { payload }) => ({
    ...state,
    currentFlightId: payload,
    error: [],
    loading: false
  })),
  on(seatsActions.currentPassengerId, (state, { payload }) => ({
    ...state,
    currentPassengerId: payload,
    error: [],
    loading: false
  })),
  on(seatsActions.currentDeck, (state, { payload }) => ({
    ...state,
    currentDeck: payload,
    error: [],
    loading: false
  }))
);

export function seatReducer(state: SeatReducerState | undefined, action: Action) {
  return seatsReducerInternal(state, action);
}
export const getSeatmapResponse = (state: SeatReducerState) => state.seatMap;
export const getSeatMapLoading = (state: SeatReducerState) => state.loading;
export const getFlightId = (state: SeatReducerState) => state.currentFlightId;
export const getPassengerId = (state: SeatReducerState) => state.currentPassengerId;
export const getDeck = (state: SeatReducerState) => state.currentDeck;
