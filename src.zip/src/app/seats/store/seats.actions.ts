import { createAction, props } from '@ngrx/store';
import { MessageModel, SeatMap, SeatMapRequest } from '@app/models';


// Effects related actions
export const loadSeatMap = createAction('[SeatMap] Load Initiated', props<{ payload: SeatMapRequest }>());
export const loadSeatMapSuccess = createAction('[SeatMap] Load Success', props<{ payload: SeatMap }>());
export const loadSeatMapFail = createAction('[SeatMap] Load Fail', props<{ payload: MessageModel[] }>());

// Set current values
export const currentFlightId = createAction('[Flight] Set Current Flight', props<{ payload: string }>());
export const currentDeck = createAction('[Deck] Set Current Deck', props<{ payload: string }>());
export const currentPassengerId = createAction('[Pax] Set Current Pax', props<{ payload: string }>());
