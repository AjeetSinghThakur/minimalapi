import { Routes } from '@angular/router';
import { ContentComponent } from './container';

export const seatsRoutes: Routes = [{ path: '', component: ContentComponent }];
