import { Component, OnInit, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { SeatsStoreFacade } from '@app/seats/store/seats-store.facade';
import { currentDeck, currentPassengerId, currentFlightId, loadSeatMap } from '@app/seats/store';
import {
  MessageModel,
  JourneyViewModel,
  FlightGroup,
  Deck,
  PassengerViewModel,
  RBDCodes,
  HandshakeRequest,
  FlightViewModel,
  SeatMapRequest,
  FlightIdentifier,
} from '@app/models';
import { AncillariesStoreFacade } from '@app/store/ancillaries-store.facade';
import { authToken, loadTrip } from '@app/store/actions/ancillaries.actions';
import { SeatPlanComponent } from '@app/seats/presentational';
@Component({
  selector: 'qa-seats',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ContentComponent implements OnInit {
  @ViewChild(SeatPlanComponent) public seatPlanComponent: SeatPlanComponent;
  journeys$: Observable<JourneyViewModel[]>;
  errorMessage$: Observable<MessageModel[]>;
  loading$: Observable<boolean>;
  decks$: Observable<Deck[]>;
  rbdCodes$: Observable<RBDCodes[]>;
  currentDeck$: Observable<string>;
  currentFlight$: Observable<FlightViewModel>;
  selectedPaxRow$: Observable<string>;
  flightIds$: Observable<string[]>;
  seatGroups$: Observable<{ deckLocation: string; rowHeaderIdentifier: string; data: FlightGroup; }[]>;
  currentSeatGroup: string;
  selectedPassenger$: Observable<PassengerViewModel>;
  constructor(private seatsStoreFacade: SeatsStoreFacade,
              private ancillariesStoreFacade: AncillariesStoreFacade) { }

  ngOnInit() {
    this.journeys$ = this.seatsStoreFacade.journeys$;
    this.seatGroups$ = this.seatsStoreFacade.seatGroups$;
    this.decks$ = this.seatsStoreFacade.decks$;
    this.currentDeck$ = this.seatsStoreFacade.currentDeck$;
    this.rbdCodes$ = this.seatsStoreFacade.rbdCodes$;
    this.errorMessage$ = this.seatsStoreFacade.errorMessage$;
    this.loading$ = this.seatsStoreFacade.loading$;
    this.currentFlight$ = this.seatsStoreFacade.currentFlight$;
    this.selectedPassenger$ = this.seatsStoreFacade.selectedPassenger$;
    this.selectedPaxRow$ = this.seatsStoreFacade.selectedPaxRow$;
    this.flightIds$ = this.seatsStoreFacade.flightIds$;
    // const request: HandshakeRequest = { requestType: 'TestRequest', conversationToken: 'sampletoken-123abc'};
    // this.ancillariesStoreFacade.dispatch(authToken({ payload: request }));
    this.ancillariesStoreFacade.dispatch(loadTrip());
  }
  selectedDeck(deckLocation: string) {
    this.seatsStoreFacade.dispatch(currentDeck({ payload: deckLocation }));
  }
  selectCurrentFlight(uniqueIdentifier: string) {
    this.seatsStoreFacade.dispatch(currentFlightId({ payload: uniqueIdentifier }));
    const flightIdentifier: FlightIdentifier = { uniqueIdentifier };
    const request: SeatMapRequest = { flightIdentifier };
    this.seatsStoreFacade.dispatch(loadSeatMap({ payload: request }));
  }
  selectedPassenger(passenger: PassengerViewModel) {
    this.seatsStoreFacade.dispatch(currentPassengerId({ payload: passenger.productIdentifier }));
    this.seatsStoreFacade.dispatch(currentDeck({ payload: 'LOWER' }));
    if (this.seatPlanComponent && this.seatPlanComponent.seatGroups) {
      const seatGroup = this.seatPlanComponent.seatGroups.find(group => passenger.row >=
        group.rowHeaderIdentifier.split('-')[0] && passenger.row <= group.rowHeaderIdentifier.split('-')[1]);
      this.setSeatGroupPreview(seatGroup.rowHeaderIdentifier);
    }
  }
  setSeatGroupPreview(rowHeaderIdentifier: string) {
    if (this.seatPlanComponent && this.seatPlanComponent.seatCarousel) {
      this.seatPlanComponent.seatCarousel.select(rowHeaderIdentifier);
    }
    this.currentSeatGroup = rowHeaderIdentifier;
  }
  setSeatGroup(rowHeaderIdentifier: string) {
    this.currentSeatGroup = rowHeaderIdentifier;
  }
}
