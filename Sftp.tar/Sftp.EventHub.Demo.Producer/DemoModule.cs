﻿using Autofac;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Threading;
using System;
using Sftp.EventHub.Demo.DataContracts;

namespace Sftp.EventHub.Demo.Producer
{

    internal sealed class DemoModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {

            builder.RegisterProducer<DemoMessageProducer, DemoMessage>("logs").As<IProducer>().SingleInstance().AutoActivate()
                     .OnActivated(async (a) =>
                     {
                         var logger = a.Context.Resolve<ILogger<DemoMessageProducer>>();
                         var producer = a.Context.Resolve<IProducer>();
                         logger.LogInformation($"Activated Producer");
                         var cts = new CancellationTokenSource();
                         var backgroundTask = Task.Run(async () =>
                         {
                             while (!cts.Token.IsCancellationRequested)
                             {
                                 try
                                 {
                                     producer.SendMessage();
                                     logger.LogInformation("sent message..Press any key to continue");

                                     //await Task.Delay(TimeSpan.FromMilliseconds(100), cts.Token);

                                     //Console.ReadKey();
                                 }
                                 catch (TaskCanceledException)
                                 {
                                 }
                             }
                         });

                         //logger.LogInformation("Press any key to exit...");

                         //Console.ReadKey();

                         //cts.Cancel();

                         await backgroundTask;

                         logger.LogInformation("Exiting..");

                         Environment.Exit(0);
                     });
        }
    }
}
