﻿using MessagePack;
using System;

namespace Sftp.EventHub.Demo.Message
{
    [MessagePackObject]
    public sealed class DemoMessage
    {
        [Key(0)]
        public int Integer { get; set; }

        [Key(1)]
        public double Double { get; set; }

        [Key(2)]
        public string String { get; set; }

        [Key(3)]
        public bool Bool { get; set; }


        [Key(4)]
        public DateTime DateTime{ get; set; }


        [Key(5)]
        public Guid Guid  {get; set; }

        [Key(6)]
        public Decimal Decimal { get; set; }



    }
}