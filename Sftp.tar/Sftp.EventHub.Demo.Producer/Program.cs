﻿using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace Sftp.EventHub.Demo.Producer
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            try
            {
                Host.CreateDefaultBuilder(args)
                .UseServiceProviderFactory(
                    new AutofacServiceProviderFactory(b => b.RegisterModule<DemoModule>()))
                .Build()
                .Run();               
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}