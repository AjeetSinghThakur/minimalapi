﻿namespace Sftp.EventHub.Demo.Producer
{
    internal interface IProducer
    {
        void SendMessage();
    }
}