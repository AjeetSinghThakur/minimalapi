﻿using System;
using MessagePack;
using Sftp.EventHub.Demo.Message;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub.Demo.Producer
{
    internal sealed class DemoMessageProducer : IProducer
    {
        private readonly Random _random = new Random();
        private readonly IEventHubProducer<DemoMessage> _producer;
        private readonly ILogger<DemoMessageProducer> _logger; 

        public DemoMessageProducer(IEventHubProducer<DemoMessage> producer, ILogger<DemoMessageProducer> logger)
        {
            _producer = producer;
            _logger = logger;
        }

        public void SendMessage()
        {
            Console.WriteLine("do something");
        }
    }
}