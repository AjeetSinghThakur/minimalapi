﻿using System.Text;
using MessagePack;
using Sftp.EventHub.Demo.Message;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub.Demo.Consumer
{
    internal sealed class Consumer : IEventHubConsumer
    {
        private readonly ILogger<Consumer> _logger;
        
        public Consumer(ILogger<Consumer> logger)
        {
            _logger = logger;
        }

        public void ProcessMessage(Context context, byte[] bytes)
        {
            var message = MessagePackSerializer.Deserialize<DemoMessage>(bytes);

            var sb = new StringBuilder("Received message:").AppendLine();
            sb.Append("  Integer: ").Append(message.Integer).AppendLine();
            sb.Append("  Double: ").Append(message.Double).AppendLine();
            sb.Append("  Decimal: ").Append(message.Decimal).AppendLine();
            sb.Append("  String: ").Append(message.String).AppendLine();
            sb.Append("  DateTime: ").Append(message.DateTime).AppendLine();
            sb.Append("  Guid: ").Append(message.Guid).AppendLine();
            sb.Append("  Bool: ").Append(message.Bool);
            
            _logger.LogInformation(context.EventId(), sb.ToString());
        }
    }
}