﻿using Autofac;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Threading;
using System;

namespace Sftp.EventHub.Demo.Consumer
{
    internal sealed class DemoModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterConsumer<Consumer>("logs")
                    .OnActivated(async (a) => { 
                        var logger = a.Context.Resolve<ILogger<Consumer>>();
                        logger.LogInformation($"Activated Consumer");
                        var cts = new CancellationTokenSource();
                        var backgroundTask = Task.Run(async () =>
                        {
                            while (!cts.Token.IsCancellationRequested)
                            {
                                try
                                {
                                    await Task.Delay(TimeSpan.FromSeconds(10), cts.Token);
                                }
                                catch (TaskCanceledException)
                                {
                                }
                            }
                        });

                        logger.LogInformation("Press any key to exit...");

                        Console.ReadKey();

                        cts.Cancel();

                        await backgroundTask;

                        logger.LogInformation("Exiting..");

                        Environment.Exit(0);
                    });
        }
    }
}
