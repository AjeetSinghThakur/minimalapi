﻿using System;
using System.Threading;
using Confluent.Kafka;
using Microsoft.Azure.Data.SchemaRegistry.ApacheAvro;
using Azure.Messaging;
using Microsoft.Extensions.Logging;


namespace Sftp.EventHub.Convertors
{
    public class MessageSerializer<T> : ISerializer<T>
    {
        private readonly SchemaRegistryAvroSerializer _serializer;
        private readonly ILogger<MessageSerializer<T>> _logger;

        public MessageSerializer(SchemaRegistryAvroSerializer serializer,
            ILogger<MessageSerializer<T>> logger)
        {
            _serializer = serializer;
            _logger = logger; 
        }

        public byte[] Serialize(T o, SerializationContext context)
        {
            
            if (o == null)
            {
                return null;
            }
            var messageContent = _serializer.Serialize(data: o, dataType: typeof(T), cancellationToken: CancellationToken.None);
            _logger.LogDebug("Packet Size={size} bytes, Topic={topic}", messageContent.Data.ToArray().Length, context.Topic);
            return messageContent.Data.ToArray();
        }
    }

    public class MessageDeSerializer<T> : IDeserializer<T>
    {
        private readonly SchemaRegistryAvroSerializer _serializer;
        private readonly ILogger<MessageDeSerializer<T>> _logger;
        public MessageDeSerializer(SchemaRegistryAvroSerializer serializer,
            ILogger<MessageDeSerializer<T>> logger)
        {
            _serializer = serializer;
            _logger = logger;
        }

        public T Deserialize(ReadOnlySpan<byte> data, bool isNull, SerializationContext context)
        {
            _logger.LogDebug("Packet Size={size} bytes, Topic={topic}", data.Length,context.Topic);
            if (data.IsEmpty)
            {
                return default(T);
            }

            var messageContent = new MessageContent
            {
                Data = new BinaryData(data.ToArray()),
            };

            return _serializer.Deserialize<T>(content: messageContent, cancellationToken:  CancellationToken.None);
        }

        
    }

}
