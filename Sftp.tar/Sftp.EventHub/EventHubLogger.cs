﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub
{
    internal class EventHubLogger
    {
        private readonly ILogger<EventHubLogger> _logger;
        public EventHubLogger(ILogger<EventHubLogger> logger)
        {
            _logger = logger;
        }

        public void LogMessage(LogMessage message)
        {
            var logLevel = (LogLevel)message.LevelAs(LogLevelType.MicrosoftExtensionsLogging);
            _logger.Log(logLevel, message.Message);
        }
    }
}