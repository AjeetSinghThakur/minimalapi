﻿using System;
using System.Linq;
using Autofac;
using Autofac.Builder;
using Autofac.Core;
using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sftp.EventHub.Configuration;

using System.Text.Json;
using System.Text.Json.Serialization;
using Azure.Data.SchemaRegistry;
using Microsoft.Azure.Data.SchemaRegistry.ApacheAvro;
using Azure.Identity;
using System.Configuration;
using Sftp.EventHub.Convertors;


namespace Sftp.EventHub
{
    public static partial class Extensions
    {
        private static EventId EventId(this Guid guid) => new EventId(0, guid.ToString());

        internal static string ToMaskedString(this ClientConfig config)
        {
            if (string.IsNullOrEmpty(config.SaslPassword))
            {
                return JsonSerializer.Serialize(config);
            }

            var password = config.SaslPassword;
            config.SaslPassword = "***";
            var options = new JsonSerializerOptions { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull };
            var dump = JsonSerializer.Serialize(config, options);
            config.SaslPassword = password;
            return dump;
        }

        /// <summary>
        /// Register a component to be created with IEventHubProducer param injected.
        /// </summary>
        /// <typeparam name="TImplementer">The type of the component implementation.</typeparam>
        /// <param name="builder">Container builder.</param>
        /// <param name="configuration">configuration</param>
        /// <param name="topic">EventHub topic</param>
        /// <returns>Registration builder allowing the registration to be configured.</returns>
        public static IRegistrationBuilder<TImplementer, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterProducer<TImplementer, TMessageType>(this ContainerBuilder builder, IConfiguration configuration,
                string topic, bool autoRegisterSchemas = true)
            where TImplementer : notnull
            where TMessageType : notnull
        {
            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            var rb = RegistrationBuilder.ForType<TImplementer>();
            rb.RegistrationData.DeferredCallback =
                builder.RegisterCallback(cr => RegistrationBuilder.RegisterSingleComponent(cr, rb));

            var config = new EventHubConfiguration(configuration).GetProducerConfig(topic);
            builder.RegisterType<EventHubLogger>().AsSelf().SingleInstance();

            builder.Register(ctx =>
                {
                    var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                    var eventhubLogger = ctx.Resolve<EventHubLogger>();

                    var eventId = Guid.NewGuid().EventId();
                    logger.LogInformation(eventId, $"Create EventHub producer with config: {config}");

                    try
                    {
                        return new ProducerBuilder<byte[], byte[]>(config)
                            .SetLogHandler((_, message) => eventhubLogger.LogMessage(message))
                            .Build();
                    }
                    catch (Exception e)
                    {
                        logger.LogError(eventId, e, $"Cannot create EventHub producer for config: {config}");
                        throw;
                    }
            })
            .Named<IProducer<byte[], byte[]>>(topic)
            .SingleInstance();

            builder.Register(ctx =>
            {
                var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                var eventHubLogger = ctx.Resolve<EventHubLogger>();
                var configuration = ctx.Resolve<IConfiguration>();
                var serviceNameSection = configuration.GetSection("ServiceConfiguration:ServiceName");

                if (!serviceNameSection.Exists())
                {
                    throw new ConfigurationErrorsException("Missing application config ServiceConfiguration:ServiceName ");
                }

                var config =
                    new EventHubConfiguration(configuration.GetSection("EventHubOptions")).GetProducerConfig(topic);

                var eventId = Guid.NewGuid().EventId();
                logger.LogInformation(eventId, $"Create EventHub Schema Registry Client For Producer with config: {config}");

                try
                {
                    var messageSerializerLogger = ctx.Resolve<ILogger<MessageSerializer<TMessageType>>>();
                    return new MessageSerializer<TMessageType>(new SchemaRegistryAvroSerializer(
                                new SchemaRegistryClient(
                                    config.SchemaRegistryServers,
                                    new DefaultAzureCredential(),
                                    new SchemaRegistryClientOptions
                                    {
                                        Diagnostics =
                                        {
                                            ApplicationId = serviceNameSection.Value
                                        }
                                    }),
                                    config.SchemaRegistryGroup,
                                    new SchemaRegistryAvroSerializerOptions()
                                    {
                                        AutoRegisterSchemas = autoRegisterSchemas
                                    }
                   ), messageSerializerLogger);
                }
                catch (Exception e)
                {
                    logger.LogError(eventId, e, $"Cannot create EventHub Schema Registry Client For Producer with config: {config}");
                    throw;
                }
            })
                        .Named<ISerializer<TMessageType>>($"{topic}")
                        .SingleInstance();


            builder.RegisterType<EventHubProducer<TMessageType>>()
                .WithParameter(new NamedParameter("topic", topic))
                .WithParameter(new NamedParameter("topicPrefix", config.TopicPrefix))
                .WithParameter(ResolvedParameter.ForNamed<IProducer<byte[], byte[]>>(topic))
                .WithParameter(ResolvedParameter.ForNamed<ISerializer<TMessageType>>(topic))
                .Named<IEventHubProducer<TMessageType>>(topic)
                .SingleInstance();

            return rb.WithParameter(ResolvedParameter.ForNamed<IEventHubProducer<TMessageType>>(topic));
        }

        /// <summary>
        /// Register a component to be created with IEventHubProducer param injected.
        /// This method assumes that Eventhub configuration is present in 'EventHubOptions' section of config file
        /// </summary>
        /// <typeparam name="TImplementer">The type of the component implementation.</typeparam>
        /// <param name="builder">Container builder.</param>
        /// <param name="topic">Eventhub topic</param>
        /// <returns>Registration builder allowing the registration to be configured.</returns>
        public static IRegistrationBuilder<TImplementer, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterProducer<TImplementer, TMessageType>(this ContainerBuilder builder, string topic,
                                                        bool autoRegisterSchemas = true)
            where TImplementer : notnull
            where TMessageType : notnull
        {

            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            var rb = RegistrationBuilder.ForType<TImplementer>();
            rb.RegistrationData.DeferredCallback =
                builder.RegisterCallback(cr => RegistrationBuilder.RegisterSingleComponent(cr, rb));

            builder.RegisterType<EventHubLogger>().AsSelf().SingleInstance();

            builder.Register(ctx =>
                {
                    var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                    var eventHubLogger = ctx.Resolve<EventHubLogger>();
                    var configuration = ctx.Resolve<IConfiguration>();
                    var config =
                        new EventHubConfiguration(configuration.GetSection("EventHubOptions")).GetProducerConfig(topic);

                    var eventId = Guid.NewGuid().EventId();
                    logger.LogInformation(eventId, $"Create EventHub producer with config: {config}");

                    try
                    {
                        return new ProducerBuilder<byte[], byte[]>(config)
                            .SetLogHandler((_, message) => eventHubLogger.LogMessage(message))
                            .Build();
                    }
                    catch (Exception e)
                    {
                        logger.LogError(eventId, e, $"Cannot create EventHub producer for config: {config}");
                        throw;
                    }
                })
                .Named<IProducer<byte[], byte[]>>(topic)
                .SingleInstance();


            builder.Register(ctx =>
            {
                var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                var eventHubLogger = ctx.Resolve<EventHubLogger>();
                var configuration = ctx.Resolve<IConfiguration>();
                var serviceNameSection = configuration.GetSection("ServiceConfiguration:ServiceName");

                if (!serviceNameSection.Exists())
                {
                    throw new ConfigurationErrorsException("Missing application config ServiceConfiguration:ServiceName ");
                }

                var config =
                    new EventHubConfiguration(configuration.GetSection("EventHubOptions")).GetProducerConfig(topic);

                var eventId = Guid.NewGuid().EventId();
                logger.LogInformation(eventId, $"Create EventHub Schema Registry Client For Producer with config: {config}");

                try
                {
                    var messageSerializerLogger = ctx.Resolve<ILogger<MessageSerializer<TMessageType>>>();
                    return new MessageSerializer<TMessageType>(new SchemaRegistryAvroSerializer(
                                new SchemaRegistryClient(
                                    config.SchemaRegistryServers,
                                    new DefaultAzureCredential(),
                                    new SchemaRegistryClientOptions
                                    {
                                        Diagnostics =
                                        {
                                            ApplicationId = serviceNameSection.Value
                                        }
                                    }),
                                    config.SchemaRegistryGroup,
                                    new SchemaRegistryAvroSerializerOptions()
                                    {
                                        AutoRegisterSchemas = autoRegisterSchemas
                                    }
                   ), messageSerializerLogger);
                }
                catch (Exception e)
                {
                    logger.LogError(eventId, e, $"Cannot create EventHub Schema Registry Client For Producer with config: {config}");
                    throw;
                }
            })
        .Named<ISerializer<TMessageType>>(topic)
        .SingleInstance();

            builder.RegisterType<EventHubProducer<TMessageType>>()
                .WithParameter(new NamedParameter("topic", topic))
                .WithParameter(new ResolvedParameter((p, ctx) => p.Name == "topicPrefix",
                    (p, ctx) =>
                    {
                        var configuration = ctx.Resolve<IConfiguration>();
                        var config =
                            new EventHubConfiguration(configuration.GetSection("EventHubOptions")).GetProducerConfig(topic);
                        return config.TopicPrefix;
                    }))
                .WithParameter(ResolvedParameter.ForNamed<IProducer<byte[], byte[]>>(topic))
                .WithParameter(ResolvedParameter.ForNamed<ISerializer<TMessageType>>(topic))
                .Named<IEventHubProducer<TMessageType>>(topic)
                .SingleInstance();
            return rb.WithParameter(ResolvedParameter.ForNamed<IEventHubProducer<TMessageType>>(topic));
        }

        
    }
}