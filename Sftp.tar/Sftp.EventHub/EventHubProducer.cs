﻿using System;
using System.Diagnostics;
using Azure.Data.SchemaRegistry;
using Microsoft.Azure.Data.SchemaRegistry.ApacheAvro;
using Azure.Identity;
using Confluent.Kafka;
using MessagePack;
using Sftp.EventHub.Demo.DataContracts;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub
{

    [DebuggerDisplay("Producer: {_defaultTopic}")]
    internal sealed class EventHubProducer<T> : IEventHubProducer<T>, IDisposable
    {

        private readonly ILogger<EventHubProducer<T>> _logger;
        private readonly IProducer<byte[], byte[]> _producer;
        private readonly string _defaultTopic;
        private readonly string _topicPrefix;
        private readonly ISerializer<T> _serializer;

        public EventHubProducer(ILogger<EventHubProducer<T>> logger, 
            string topic, string topicPrefix,
            IProducer<byte[], byte[]> producer,
            ISerializer<T> serializer)
        {
            _defaultTopic = !string.IsNullOrEmpty(topic) ? topic : throw new ArgumentNullException(nameof(topic));
            _topicPrefix = topicPrefix;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _producer = producer ?? throw new ArgumentNullException(nameof(producer));
            _serializer = serializer;
        }

        public void Send(T payload, string topic = null)
        {
            int x = 10;   
        }

        public void Send(byte[] bytes, string topic = null) => Send(new Context(), bytes, topic);

        public void Send(EventId eventId, byte[] bytes, string topic = null) => Send(new Context(eventId), bytes, topic);

        public async void Send(Context context, byte[] bytes, string topic = null)
        {


            if (context == null) throw new ArgumentNullException(nameof(context));

            var eventId = context.EventId();

            var topicName = !string.IsNullOrEmpty(topic) ? topic : _defaultTopic;
            var targetTopic = !string.IsNullOrEmpty(_topicPrefix) ? $"{_topicPrefix}{topicName}" : topicName;
            try
            {
                _logger.LogTrace(eventId, "Send message to topic '{0}'", targetTopic);


                _producer.Produce(targetTopic, new Message<byte[], byte[]>
                {
                    Key = MessagePackSerializer.Serialize(context),
                    Value = bytes
                });


                _logger.LogTrace(eventId, "Message successfully sent to topic '{0}'", targetTopic);
            }
            catch (Exception e)
            {
                _logger.LogError(eventId, e, "Cannot send message '{0}' to topic '{1}'", context, targetTopic);
            }
        }

        public void Dispose()
        {
            _producer?.Flush();
            _producer?.Dispose();
        }

 
    }
}
