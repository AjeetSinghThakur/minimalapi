﻿using System;
using System.Collections.Generic;
using System.Text;
using MessagePack;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub
{
    [MessagePackObject]
    public sealed class Context
    {
        
        [SerializationConstructor]
        public Context(DateTime timestamp, IDictionary<string, string> headers)
        {
            Timestamp = timestamp;
            Headers = headers ?? throw new ArgumentNullException(nameof(headers));
        }

        public Context(EventId? eventId = null, string key = null, string contentType = null)
            : this(DateTime.UtcNow, new Dictionary<string, string>())
        {
            if (eventId.HasValue) Headers["EventId"] = eventId.Value.Name;
            if (!string.IsNullOrEmpty(key)) Headers["Key"] = key;
            if (!string.IsNullOrEmpty(contentType)) Headers["ContentType"] = contentType;
        }

        [Key(0)]
        public DateTime Timestamp { get; }

        [Key(1)]
        public IDictionary<string, string> Headers { get; }

        public string GetHeader(string key, string defaultValue = "")
        {
            if(key != "EventId")
            {

            }
            if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));

            return Headers.TryGetValue(key, out var value) ? value : defaultValue;
        }

        public EventId EventId() => new EventId(0, GetHeader("EventId", Guid.NewGuid().ToString()));

        public string Key() => GetHeader("Key");
        
        public string ContentType() => GetHeader("ContentType");
        
        public string Topic() => GetHeader("Topic");

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append("Timestamp: ").Append(Timestamp.ToString("O"));
            foreach (var (key, value) in Headers)
            {
                sb.Append(", ").Append(key).Append(": ").Append(value);
            }
            
            return sb.ToString();
        }
    }
}