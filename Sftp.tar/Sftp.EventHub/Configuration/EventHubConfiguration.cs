﻿using System;
using Microsoft.Extensions.Configuration;

namespace Sftp.EventHub.Configuration
{
    internal sealed class EventHubConfiguration
    {
        private readonly IConfiguration _configuration;

        public EventHubConfiguration(IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public EventHubProducerConfig GetProducerConfig(string topic)
        {
            var result = new EventHubProducerConfig();

            _configuration.GetSection("Default").Bind(result);

            var producerTopicSection = _configuration.GetSection($"Producers:{topic}");

            if (producerTopicSection.Exists())
            {
                producerTopicSection.Bind(result);
            }
            else
            {
                throw new ArgumentNullException($"Producers:{topic}");
            }
            return result;
        }

        public EventHubConsumerConfig GetConsumerConfig(string topic)
        {
            var result = new EventHubConsumerConfig();

            _configuration.GetSection("Default").Bind(result);

            var consumerTopicSection = _configuration.GetSection($"Consumers:{topic}");

            if (consumerTopicSection.Exists())
            {
                consumerTopicSection.Bind(result);
            }
            else
            {
                throw new ArgumentNullException($"Consumers:{topic}");
            }
            return result;
        }
    }
}