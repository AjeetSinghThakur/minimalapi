﻿using Confluent.Kafka;

namespace Sftp.EventHub.Configuration
{
    public sealed class EventHubConsumerConfig : ConsumerConfig
    {
        public string SchemaRegistryServers { get; set; }
        public string SchemaRegistryGroup { get; set; }
        public bool Enabled { get; set; } = true;
        
        public string[] SubscribeTopics { get; set; }
        
        public string TopicPrefix { get; set; }

        public override string ToString()
        {
            return this.ToMaskedString();
        }
    }
}