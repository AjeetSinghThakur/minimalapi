﻿using Confluent.Kafka;

namespace Sftp.EventHub.Configuration
{
    public sealed class EventHubProducerConfig : ProducerConfig
    {
        public string SchemaRegistryServers { get; set; }
        public string SchemaRegistryGroup { get; set; }
        public string TopicPrefix { get; set; }
        public override string ToString()
        {
            return this.ToMaskedString();
        }
    }
}