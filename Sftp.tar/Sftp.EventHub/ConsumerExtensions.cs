﻿using Autofac.Builder;
using Autofac;
using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Sftp.EventHub.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Autofac.Core;

namespace Sftp.EventHub
{
    public static partial class Extensions
    {
        /// <summary>
        /// Register a component to be created with IEventHubConsumer param injected.
        /// </summary>
        /// <typeparam name="TImplementer">The type of the component implementation.</typeparam>
        /// <param name="builder">Container builder.</param>
        /// <param name="configuration">configuration</param>
        /// <param name="topic">EventHub topic</param>
        /// <returns>Registration builder allowing the registration to be configured.</returns>
        public static IRegistrationBuilder<TImplementer, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterConsumer<TImplementer>(this ContainerBuilder builder, IConfiguration configuration,
                string topic)
            where TImplementer : IEventHubConsumer
        {
            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            // Basic implementation from Autofac's RegisterType<> extension method
            var rb = RegistrationBuilder.ForType<TImplementer>();
            rb.RegistrationData.DeferredCallback =
                builder.RegisterCallback(cr => RegistrationBuilder.RegisterSingleComponent(cr, rb));

            builder.RegisterType<EventHubLogger>().AsSelf().SingleInstance();

            var config = new EventHubConfiguration(configuration).GetConsumerConfig(topic);

            builder.Register(ctx =>
            {
                var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                var eventHubLogger = ctx.Resolve<EventHubLogger>();

                var eventId = Guid.NewGuid().EventId();
                logger.LogInformation(eventId, $"Create EventHub consumer with config: {config}");

                try
                {
                    return new ConsumerBuilder<byte[], byte[]>(config)
                        .SetLogHandler((_, message) => eventHubLogger.LogMessage(message))
                        .Build();
                }
                catch (Exception e)
                {
                    logger.LogError(eventId, e, $"Cannot create EventHub consumer for config: {config}");
                    throw;
                }
            })
                .Named<IConsumer<byte[], byte[]>>(topic)
                .SingleInstance();

            builder.RegisterType<EventHubTopicConsumer>()
                .WithParameter(new NamedParameter("topics", ConsumerTopics(config, topic)))
                .WithParameter(new NamedParameter("enabled", config.Enabled))
                .WithParameter(ResolvedParameter.ForNamed<IConsumer<byte[], byte[]>>(topic))
                .WithParameter(ResolvedParameter.ForNamed<IEventHubConsumer>(topic))
                .As<IStartable>()
                .SingleInstance();

            return rb.Named<IEventHubConsumer>(topic).SingleInstance();
        }

        /// <summary>
        /// Register a component to be created with IEventHubProducer param injected.
        /// This method assumes that EventHub configuration is present in 'EventHubOptions' section of config file   
        /// </summary>
        /// <typeparam name="TImplementer">The type of the component implementation.</typeparam>
        /// <param name="builder">Container builder.</param>
        /// <param name="topic">EventHub topic</param>
        /// <returns>Registration builder allowing the registration to be configured.</returns>
        public static IRegistrationBuilder<TImplementer, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterConsumer<TImplementer>(this ContainerBuilder builder, string topic)
            where TImplementer : IEventHubConsumer
        {
            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            var rb = RegistrationBuilder.ForType<TImplementer>();
            rb.RegistrationData.DeferredCallback =
                builder.RegisterCallback(cr => RegistrationBuilder.RegisterSingleComponent(cr, rb));

            builder.RegisterType<EventHubLogger>().AsSelf().SingleInstance();

            builder.Register(ctx =>
            {
                var logger = ctx.Resolve<ILogger<EventHubConfiguration>>();
                var eventHubLogger = ctx.Resolve<EventHubLogger>();
                var configuration = ctx.Resolve<IConfiguration>();
                var config = ConsumerConfig(configuration, topic);

                var eventId = Guid.NewGuid().EventId();
                logger.LogInformation(eventId, $"Create EventHub consumer with config: {config}");

                try
                {
                    return new ConsumerBuilder<byte[], byte[]>(config)
                        .SetLogHandler((_, message) => eventHubLogger.LogMessage(message))
                        .Build();
                }
                catch (Exception e)
                {
                    logger.LogError(eventId, e, $"Cannot create EventHub consumer for config: {config}");
                    throw;
                }
            })
                .Named<IConsumer<byte[], byte[]>>(topic)
                .SingleInstance();

            builder.RegisterType<EventHubTopicConsumer>()
                .WithParameter(new ResolvedParameter((p, ctx) => p.Name == "topics",
                    (p, ctx) =>
                    {
                        var configuration = ctx.Resolve<IConfiguration>();
                        var config = ConsumerConfig(configuration, topic);
                        return ConsumerTopics(config, topic);
                    }))
                .WithParameter(new ResolvedParameter((p, ctx) => p.Name == "enabled",
                    (p, ctx) =>
                    {
                        var configuration = ctx.Resolve<IConfiguration>();
                        var config = ConsumerConfig(configuration, topic);
                        return config.Enabled;
                    }))
                .WithParameter(ResolvedParameter.ForNamed<IConsumer<byte[], byte[]>>(topic))
                .WithParameter(ResolvedParameter.ForNamed<IEventHubConsumer>(topic))
                .As<IStartable>()
                .SingleInstance();

            return rb.Named<IEventHubConsumer>(topic).SingleInstance();
        }

        private static EventHubConsumerConfig ConsumerConfig(IConfiguration configuration, string topic)
        {
            return new EventHubConfiguration(configuration.GetSection("EventHubOptions")).GetConsumerConfig(topic);
        }

        private static string[] ConsumerTopics(EventHubConsumerConfig config, string topic)
        {
            var topics = config.SubscribeTopics?.Length > 0
                ? config.SubscribeTopics
                : new[] { topic };

            if (string.IsNullOrEmpty(config.TopicPrefix)) return topics;

            return topics.Select(t => $"{config.TopicPrefix}{t}").ToArray();
        }
    }
}
