﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Autofac;
using Confluent.Kafka;
using MessagePack;
using Microsoft.Extensions.Logging;

namespace Sftp.EventHub
{
    internal sealed class User
    {
        public string Name;
    }
    internal sealed class EventHubTopicConsumer : IDisposable, IStartable
    {
        
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private readonly ILogger<EventHubTopicConsumer> _logger;
        private readonly IConsumer<byte[], byte[]> _consumer;
        private readonly IEventHubConsumer _eventHubConsumer;
        private readonly string[] _topics;
        private readonly bool _enabled;
        private bool _disposed;

        public EventHubTopicConsumer(ILogger<EventHubTopicConsumer> logger, IEventHubConsumer eventHubConsumer,
            IConsumer<byte[], byte[]> consumer, string[] topics, bool enabled)
        {
            _topics = topics ?? throw new ArgumentNullException(nameof(topics));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _eventHubConsumer = eventHubConsumer ?? throw new ArgumentNullException(nameof(eventHubConsumer));
            _consumer = consumer ?? throw new ArgumentNullException(nameof(consumer));
            _enabled = enabled;


        }

        public void Start()
        {
            if (!_enabled)
            {
                var eventId = new EventId(0, Guid.NewGuid().ToString());
                _logger.LogInformation(eventId,
                    "Topic(s) {0} disabled in configuration. Messages will not be consumed",
                    string.Join(", ", _topics));
                return;
            }

            _consumer.Subscribe(_topics);
            Task.Factory.StartNew(Consume, TaskCreationOptions.LongRunning);
        }

        public void Dispose()
        {
            if (_disposed) return;

            _cts.Cancel();
            _consumer.Close();
            _disposed = true;
        }

        private void Consume()
        {
            try
            {
                while (!_cts.IsCancellationRequested)
                {
                    try
                    {
                        var result = _consumer.Consume(_cts.Token);

                        var context = MessagePackSerializer.Deserialize<Context>(result.Message.Key);
                        var bytes = result.Message.Value;

                        var eventId = context.EventId();
                        var topic = result.Topic;
                        context.Headers["Topic"] = topic;
                        _logger.LogDebug(eventId, "Received message from topic '{0}'", topic);

                        try
                        {
                            _eventHubConsumer.ProcessMessage(context, bytes);
                        }
                        catch (Exception e)
                        {
                            _logger.LogError(eventId, e, "Error in processing message in IEventHubConsumer. " +
                                                         "Make sure to not throw exceptions from this place, " +
                                                         "as they cannot be returned back to the queue");
                        }
                    }
                    catch (ConsumeException e)
                    {
                        _logger.LogError(e, "eventhub consume error occured: {0}", e.Error.Reason);
                    }
                }
            }
            catch (OperationCanceledException e)
            {
                if (_disposed) return;

                _logger.LogError(e, "Unexpected cancellation in {0}", nameof(EventHubTopicConsumer));
            }
        }
    }
}