﻿namespace Sftp.EventHub
{
    public interface IEventHubConsumer
    {
        void ProcessMessage(Context context, byte[] bytes);
    }
}