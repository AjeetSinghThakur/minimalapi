﻿using Microsoft.Extensions.Logging;

namespace Sftp.EventHub
{
    public interface IEventHubProducer<T>
    {
        void Send(T payload, string topic = null);
        void Send(byte[] bytes, string topic = null);
        void Send(EventId eventId, byte[] bytes, string topic = null);
        void Send(Context context, byte[] bytes, string topic = null);
    }
}